// File: ausw.h
// $Id: ausw.h,v 1.1 2001/10/08 15:00:22 xausw Exp xausw $
// $Log: ausw.h,v $
// Revision 1.1  2001/10/08 15:00:22  xausw
// Initial revision
//

#ifndef AUSW_H
#define AUSW_H 1

#include "stdinc.h"
#include "stdfunc.h"

//#define LINUX

#define PARAMETER_FILE "ausw.conf"
//#define LOG_FILE "ausw.log"
#define HISTORY_FILE "XAusw.history"
#define      VERSION "1.0"
#define        MAXUSER 20
#define      FILE_ID "File from XAUSW %s %s"

#endif //AUSW_H





