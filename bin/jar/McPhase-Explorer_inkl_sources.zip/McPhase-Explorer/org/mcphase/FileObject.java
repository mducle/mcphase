package org.mcphase;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.net.URL;
import java.util.Collections;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;
import java.util.MissingResourceException;
import java.util.ResourceBundle;
import java.util.StringTokenizer;
import java.util.Vector;

import javax.swing.event.EventListenerList;
import javax.swing.event.TreeModelEvent;
import javax.swing.event.TreeModelListener;
import javax.swing.tree.DefaultMutableTreeNode;
import javax.swing.tree.MutableTreeNode;


/*
 * Created on 14.03.2005
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */

/**
 * @author Stefan
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */

public class FileObject extends DefaultMutableTreeNode implements Comparable, TreeModelListener
{
    private File f;
    private String m_Type = "";
    private long m_lastChangeDt;
    private static ResourceBundle resources;
    private static Map m_Types;
//    private final static String iconLeafSuffix = "IconLeaf";
//    private final static String iconOpenSuffix = "IconOpen";
//    private final static String iconCloseSuffix = "IconClose";
    private final static String keySuffix = "Key";
//    private final static String colorSuffix = "Color";
    static final long serialVersionUID = -2727901940574972909L;
    private boolean selected;
	
    private boolean isroot = false;
    
    /** Listeners. */
	protected EventListenerList listenerList = new EventListenerList();
	
    static 
    {
        try 
        {
            resources = ResourceBundle.getBundle("org.mcphase.resources.FileSystemTree", Locale.getDefault());
            m_Types = new HashMap();
            String[] szTypes = tokenize(resources.getString("mcphase"));
            for(int i = 0; i < szTypes.length; ++i)
            {
                m_Types.put(szTypes[i], resources.getString(szTypes[i] + keySuffix) + "\t" + szTypes[i]);
            }
        } 
        catch (MissingResourceException mre) 
        {
            System.err.println("org/mcphase/resources/FileSystemTree.properties not found");
            System.exit(1);
        }
    }
    
    public boolean isRoot()
    {
        return(isroot);
    }
   
    public FileObject(boolean bVirtual)
    {
        super("root", true);
        isroot = true;
        InitChildren();
    }
    
    public FileObject(String s, boolean sel) 
    { 
        this(new File(s), sel);
    }
    
    public FileObject (File m_File, boolean sel)
    {
        super(m_File.getName(), m_File.isDirectory());
        f = m_File;
        if (f.isDirectory() && sel)
        {
            InitChildren();
        }        
    }

    private synchronized void InitChildren()
    {
        File[] ch = null;
        if(!isroot)
        {
           ch = f.listFiles();
        }
        else
        {
 	       ch = File.listRoots();
        }
            
        if(ch != null)
        {
	        for (int i = 0; i < ch.length; ++i)
	        { 
                add(new FileObject(ch[i], false));
	        }
        }	        
    }
    
    public boolean isSelected()
    {
        return(selected);
    }

    public void setSelected(boolean b)
    {
        selected = b;
        if(selected)
        {
            InitChildren();
        }
    }
    public File getFile() 
    { 
        return f; 
    }
   
    public boolean isFile()
    {
        return (f.isFile());
    }
    
    public boolean isDirectory()
    {
        if(!isroot)
        {
            return (f.isDirectory());
        }
        return(true);
    }
    
    public String toString() 
    {        
        if(!isroot)
        {
            String szRet = f.getName();
            if(szRet.length() == 0)
            {
                szRet = f.getAbsolutePath();
            }
            return szRet;
        }
        return("root");
    }

    public synchronized int compareTo(Object o) 
    {
        int iRet = 0;
        if(((FileObject)o).isDirectory() && ! f.isDirectory() )
        {
            iRet = 1;
        }
        else if(!((FileObject)o).isDirectory() && f.isDirectory() )
        {
            iRet = -1;
        }
        else
        {
            iRet =  f.getName().compareToIgnoreCase(((FileObject)o).getFile().getName());
        }
        return(iRet);
      } 
    
    private synchronized String ReadFirstChars(int iLen)
    {
        try
        {
            char ch[] = new char[iLen];
            FileReader fr = new FileReader(f);
            fr.read(ch);
            fr.close();
            return String.valueOf(ch).toUpperCase();
        }
        catch(FileNotFoundException fnf)
        {
            return("EXC: File not found");
        }
        catch(IOException e)
        {
            FileSystemTree.LogExc("FileObject", "ReadFirstChars", "", e);
            return("EXC:" + e.getClass().getName() + ", " + e.getMessage());
        }
    }

    public synchronized String GetFileType()
    {
        if(isroot 
           || f.isDirectory())
        {
            return("default");
        }
        if(m_Type.length() == 0
                || f.lastModified() != m_lastChangeDt)
        {
        	String n = f.getName(); 
        	if(n.equalsIgnoreCase("mcdisp.ini"))
        	{
        		m_Type = "mcdisp_ini";
        	}
        	else if(n.equalsIgnoreCase("mcdisp.mf"))
        	{
        		m_Type = "mcdisp_mf";
        	}
        	else if(n.equalsIgnoreCase("mcdisp.mf"))
        	{
        		m_Type = "mcdisp_mf";
        	}
        	else if (
        			/*
        			n.endsWith(".fst")
        			||n.endsWith(".gnu")
        			||n.endsWith(".xyt")
        			||n.endsWith(".qom")

        			||n.endsWith(".jvx")
        			||n.endsWith(".ps")
        			||n.endsWith(".eps")
*/        			
        			n.endsWith(".jpg")
        			||n.endsWith(".gif")
        			||n.endsWith(".cvt")
        			||n.endsWith(".hst")
        			||n.endsWith("cp.clc")
        			||n.endsWith(".rtplot")
        			||n.endsWith(".fum")
        			||n.endsWith(".dsigma.tot")
        			||n.endsWith(".qei")
        	)
        	{
        		m_Type = "viewfile";
        	}
        	else
        	{
		        String szRet = "default";
		        String szTmp = ReadFirstChars(100);
		        Object types[] = m_Types.values().toArray();
		        
		        for(int i = 0; i < types.length; ++i)
		        {
		            
		            String szKey = types[i].toString().substring(0, types[i].toString().indexOf("\t")); 
		            if(szTmp.indexOf(szKey) >= 0)
		            {
		                szRet = types[i].toString().substring(types[i].toString().indexOf("\t") + 1);
		                break;
		            }
		        }	        
		        m_Type = szRet;
        	}
	        m_lastChangeDt = f.lastModified();
        }
	    return(m_Type);
    }
    
    protected String getResourceString(String nm) 
    {
    	String str;
    	try 
    	{
    	    str = resources.getString(nm);
    	}
    	catch (MissingResourceException mre) 
    	{
    	    str = null;
    	}
    	return str;
    }

   
    protected URL getResource(String key) 
    {
    	String name = getResourceString(key);
    	if (name != null) 
    	{
    	    URL url = this.getClass().getResource(name);
    	    return url;
    	}
    	return null;      
    }
    protected static String[] tokenize(String input) 
    {
        Vector v = new Vector();
        StringTokenizer t = new StringTokenizer(input);
        String cmd[];

        while (t.hasMoreTokens())
        {
            v.addElement(t.nextToken());
        }
        cmd = new String[v.size()];
        for (int i = 0; i < cmd.length; i++)
	    {
            cmd[i] = (String) v.elementAt(i);
	    }

        return cmd;
    }

    public synchronized void insert(final MutableTreeNode newChild, final int childIndex) 
    {
		super.insert(newChild, childIndex);
		int[] newIndexs = new int[1];
		newIndexs[0] = childIndex;
		nodesWereInserted(newIndexs);
		((FileObject) newChild).addTreeModelListener(this);
	}
	public synchronized void remove(final int childIndex) 
	{
		Object[] removedArray = new Object[1];
		FileObject node = (FileObject) getChildAt(childIndex);
		node.removeTreeModelListener(this);
		removedArray[0] = node;
		super.remove(childIndex);
		nodesWereRemoved(new int[] { childIndex }, removedArray);
	}
	public synchronized void treeNodesChanged(TreeModelEvent e) 
	{
		fireTreeNodesChanged(e.getSource(), e.getPath(), e.getChildIndices(), e.getChildren());
		if (e.getTreePath().getLastPathComponent() == this) {
			sortChildren(e.getChildren());
		}
	}
	public synchronized void treeNodesInserted(TreeModelEvent e) 
	{
		fireTreeNodesInserted(e.getSource(), e.getPath(), e.getChildIndices(), e.getChildren());
	}
	public void treeNodesRemoved(TreeModelEvent e) 
	{
		fireTreeNodesRemoved(e.getSource(), e.getPath(), e.getChildIndices(), e.getChildren());
	}
	public void treeStructureChanged(TreeModelEvent e) 
	{
		fireTreeStructureChanged(e.getSource(), e.getPath(), e.getChildIndices(), e.getChildren());
		if (e.getTreePath().getLastPathComponent() == this) 
		{
			sortChildren(children.toArray());
		}
	}
	protected void nodeChanged() 
	{
		if (listenerList != null) 
		{
		    FileObject parent = (FileObject) getParent();
			if (parent != null) 
			{
				int anIndex = parent.getIndex(this);
				if (anIndex != -1) 
				{
					int[] cIndexs = new int[1];
					cIndexs[0] = anIndex;
					//parent.nodesChanged(cIndexs);
					Object[] cChildren = new Object[1];
					cChildren[0] = this;
					fireTreeNodesChanged(parent.getPath(), cIndexs, cChildren);
				}
			} 
			else if (this == getRoot()) 
			{
				fireTreeNodesChanged(getPath(), null, null);
			}
		}
	}
	protected void nodesWereInserted(int[] childIndices) 
	{
		if (listenerList != null && childIndices != null
				&& childIndices.length > 0) 
		{
			int cCount = childIndices.length;
			Object[] newChildren = new Object[cCount];
			for (int counter = 0; counter < cCount; counter++)
				newChildren[counter] = getChildAt(childIndices[counter]);
			fireTreeNodesInserted(childIndices, newChildren);
		}
	}
	protected void nodesWereRemoved(int[] childIndices, Object[] removedChildren) 
	{
		if (childIndices != null) 
		{
			fireTreeNodesRemoved(childIndices, removedChildren);
		}
	}
	protected void nodeStructureChanged() 
	{
		fireTreeStructureChanged();
	}
	public void addTreeModelListener(TreeModelListener l) 
	{
		listenerList.add(TreeModelListener.class, l);
	}
	public void removeTreeModelListener(TreeModelListener l) 
	{
		listenerList.remove(TreeModelListener.class, l);		
	}
	protected void fireTreeNodesChanged(int[] childIndices, Object[] children) 
	{
		fireTreeNodesChanged(getPath(), childIndices, children);
	}
	protected void fireTreeNodesChanged(Object[] path, int[] childIndices, Object[] children) 
	{
		fireTreeNodesChanged(this, path, childIndices, children);
	}
	protected void fireTreeNodesChanged(Object source, Object[] path,
			int[] childIndices, Object[] children) 
	{
		// Guaranteed to return a non-null array
		Object[] listeners = listenerList.getListenerList();
		TreeModelEvent e = null;
		// Process the listeners last to first, notifying
		// those that are interested in this event
		for (int i = listeners.length - 2; i >= 0; i -= 2) 
		{
			if (listeners[i] == TreeModelListener.class) 
			{
				// Lazily create the event:
				if (e == null)
					e = new TreeModelEvent(source, path, childIndices, children);
				((TreeModelListener) listeners[i + 1]).treeNodesChanged(e);
			}
		}
	}
	protected void fireTreeNodesInserted(int[] childIndices, Object[] children) 
	{
		fireTreeNodesInserted(this, getPath(), childIndices, children);
	}
	protected void fireTreeNodesRemoved(int[] childIndices, Object[] children) 
	{
		fireTreeNodesRemoved(this, getPath(), childIndices, children);
	}
	protected void fireTreeNodesRemoved(Object source, Object[] path,
			int[] childIndices, Object[] children) 
	{
		// Guaranteed to return a non-null array
		Object[] listeners = listenerList.getListenerList();
		TreeModelEvent e = null;
		// Process the listeners last to first, notifying
		// those that are interested in this event
		for (int i = listeners.length - 2; i >= 0; i -= 2) 
		{
			if (listeners[i] == TreeModelListener.class) 
			{
				// Lazily create the event:
				if (e == null)
					e = new TreeModelEvent(source, path, childIndices, children);
				((TreeModelListener) listeners[i + 1]).treeNodesRemoved(e);
			}
		}
	}
	protected void fireTreeStructureChanged() 
	{
		fireTreeStructureChanged(new int[0], null);
	}
	protected void fireTreeStructureChanged(int[] childIndices,
			Object[] children) 
	{
		fireTreeStructureChanged(this, getPath(), childIndices, children);
	}
	protected void fireTreeStructureChanged(Object source, Object[] path,
			int[] childIndices, Object[] children) 
	{
		// Guaranteed to return a non-null array
		Object[] listeners = listenerList.getListenerList();
		TreeModelEvent e = null;
		// Process the listeners last to first, notifying
		// those that are interested in this event
		for (int i = listeners.length - 2; i >= 0; i -= 2) 
		{
			if (listeners[i] == TreeModelListener.class) 
			{
				// Lazily create the event:
				if (e == null)
					e = new TreeModelEvent(source, path, childIndices, children);
				((TreeModelListener) listeners[i + 1]).treeStructureChanged(e);
			}
		}
	}

	protected void sortChildren(Object[] changedChildren) 
	{
		int cCount = changedChildren.length;
		if (cCount > 0) 
		{
			int counter;
			for (counter = 0; counter < cCount; counter++) 
			{
				remove((MutableTreeNode) (changedChildren[counter]));
			}
			for (counter = 0; counter < cCount; counter++) 
			{
				add((MutableTreeNode) (changedChildren[counter]));
			}
		}
	}

	public void add(final MutableTreeNode newChild) 
	{
		if (newChild != null && newChild.getParent() == this) 
		{
			remove(newChild);
		}
		int index;
		if (children == null) 
		{
			index = 0;
		} 
		else 
		{
			index = Collections.binarySearch(children, newChild, null);
		}
		if (index < 0) 
		{
			index = -index - 1;
		}
		insert(newChild, index);
	}

    protected void fireTreeNodesInserted(Object source, Object[] path,
    		int[] childIndices, Object[] children) 
    {
    	// Guaranteed to return a non-null array
    	Object[] listeners = listenerList.getListenerList();
    	TreeModelEvent e = null;
    	// Process the listeners last to first, notifying
    	// those that are interested in this event
    	for (int i = listeners.length - 2; i >= 0; i -= 2) 
    	{
    		if (listeners[i] == TreeModelListener.class) 
    		{
    			// Lazily create the event:
    			if (e == null)
    				e = new TreeModelEvent(source, path, childIndices, children);
    			((TreeModelListener) listeners[i + 1]).treeNodesInserted(e);
    		}
    	}
    }
    
    public String getStructure()
    {
        return(getStructure(0));
    }
    
    public String getStructure(int iLevel)
    {
        StringBuffer sb = new StringBuffer(20);
        sb.append("\n");
        for(int i=0; i < iLevel; ++i)
        {
            sb.append("   ");
        }
        sb.append(this.toString());
        int iChild = this.getChildCount();
        for(int j = 0; j < iChild; ++j)
        {
            sb.append(((FileObject)getChildAt(j)).getStructure(iLevel + 1));
        }
        return(sb.toString());
    }

    public void printStructure()
    {
        printStructure(0);
    }
    
    public void printStructure(int iLevel)
    {
        StringBuffer sb = new StringBuffer(20);
        for(int i=0; i < iLevel; ++i)
        {
            sb.append("   ");
        }
        sb.append(this.getFile());
        System.out.println(sb.toString());
        int iChild = this.getChildCount();
        for(int j = 0; j < iChild; ++j)
        {
            ((FileObject)getChildAt(j)).printStructure(iLevel + 1);
        }
    }    
    
    public boolean IsValidMcPhasDirectory()
    {        
        if(this.isDirectory())
        {
            boolean bMcpIni = false;
            boolean bMcpTst = false;
            boolean bMcpJ = false;
            boolean bMcpResults = false;
            String[] s = this.getFile().list();
            if (s != null)
            {
	            int c = s.length;
	            for (int i = 0; i < c; ++i)
	            {
                    if (s[i].equalsIgnoreCase("mcphas.ini"))
                    {
                        bMcpIni = true;
                    }
                    else if (s[i].equalsIgnoreCase("mcphas.j"))
                    {
                        bMcpJ = true;
                    }
                    else if (s[i].equalsIgnoreCase("mcphas.tst"))
                    {
                        bMcpTst = true;
                    }
                    else if (s[i].equalsIgnoreCase("results"))
                    {
                        bMcpResults = true;
                    }
                    else
                    {
                        
                    }
	            }
	            if(bMcpIni && bMcpJ && bMcpTst && bMcpResults)
	            {
	                return(true);
	            }
	        }
        }
        return(false);
    }
}

