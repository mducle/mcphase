/*
 * Created on 06.04.2005
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package org.mcphase;

import java.awt.AWTException;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.LayoutManager;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.FocusEvent;
import java.awt.event.FocusListener;
import java.net.URL;
import java.util.HashMap;
import java.util.Map;
import java.util.MissingResourceException;
import java.util.ResourceBundle;
import java.util.StringTokenizer;
import java.util.Vector;

import javax.swing.BorderFactory;
import javax.swing.Icon;
import javax.swing.ImageIcon;
import javax.swing.JComponent;
import javax.swing.JPanel;
import javax.swing.JTabbedPane;
import javax.swing.event.CaretEvent;
import javax.swing.event.CaretListener;
import javax.swing.text.Document;


/**
 * @author Stefan
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
    public abstract class McpForm extends JPanel
    {
        protected static ResourceBundle resources;

        protected McpEditor edit;
        
        protected Map mapTabs;    
        protected Map mapKeys;
        protected Map mapValues;
        protected Map mapDynTabs;
        protected Map mapTables;

        protected McpTextField activeField;
        
        private final String szMatch = "0123456789e-+.";
        protected String szType = "win";
        
        public McpForm(McpEditor ed)
        {
            super(true);
            edit = ed;
            setLayout(new GridBagLayout());
            CreateTabs();
            CreateFields();
            mapTables = new HashMap();
        }
        
        public void initFromEditor(McpEditor edit)
        {
            initFromDocument(edit.getDocument());        
        }
        
        public void initFromEditor()
        {
            initFromDocument(edit.getDocument());        
        }
        
        public void initFromDocument(Document doc)
        {
            try
            {
                initFromString(doc.getText(0, doc.getLength()));
            }
            catch(Exception ex)
            {
                // do nothing
            }
        }
        private boolean isValidKeyPos(String szSource, String szKey, int iPos)
        {
            if(iPos < 0)
            {
                return(false);
            }
            if(iPos == 0)
            {
                return(isValidAfterwards(szSource, szKey, iPos));
            }
            if(("# \t").indexOf(szSource.charAt(iPos - 1)) >= 0)                
            {
                return(isValidAfterwards(szSource, szKey, iPos));
            }
            return(false);
        }
        
        private boolean isValidAfterwards(String szSource, String szKey, int iPos)
        {
            int newPos = iPos + szKey.length();
            for(int i = newPos; i < szSource.length(); ++i)
            {
                char c = szSource.charAt(i);
                if((" \t=").indexOf(c) >= 0)
                {
                    if( c == '=')
                    {
                        return(true);
                    }
                }
                else
                {
                    return(false);
                }
            }
            return(true);
        }
                
        protected String extract(String szSource, String szKey, int iFormat)
        {
            StringBuffer szRet = new StringBuffer();
            String s = szSource;
            int iPos = s.indexOf(szKey);
            while (isValidKeyPos(s, szKey, iPos))
            {
                String szTmp = szSource.substring(iPos + szKey.length()).trim();
                if(szTmp.startsWith("="))
                {
                    szTmp = szTmp.substring(1).trim();
                    for(int j=0; j < szTmp.length(); ++j)
                    {
                        char c = szTmp.charAt(j);
                        if(iFormat != McpEditor.FORMAT_TEXT)
                        {
	                        if(szMatch.indexOf(c)>= 0)
	                        {
	                            szRet.append(c);
	                        }
	                        else
	                        {
	                            break;
	                        }
                        }
                        else
                        {
            	            if(c == ' '
            	                || c == '\n'
            	                || c == '\t'
            	                || c == '\r')
            	            {
            	                break;
            	            }                
            	            else
            	            {
	                            szRet.append(c);
            	            }
                        }
                    }
                }
                iPos = szSource.indexOf(s, iPos + 1);
            }
            return(szRet.toString());
        }
        
        
public abstract void initFromString(String szSource);
        
        private void CreateTabs()
        {
            String tabs[] = tokenize(getResourceString("tabs"));
            mapTabs = new HashMap();
            mapDynTabs = new HashMap();
            
            for(int i=0; i < tabs.length; ++i)
            {
                String szName = tabs[i];
                int gridx = Integer.valueOf(getResourceString(tabs[i] + "gridx")).intValue();
                int gridy = Integer.valueOf(getResourceString(tabs[i] + "gridy")).intValue();
                int gridwidth = Integer.valueOf(getResourceString(tabs[i] + "gridwidth")).intValue();
                int gridheight = Integer.valueOf(getResourceString(tabs[i] + "gridheight")).intValue();
                String szType = getResourceString(tabs[i] + "type");
                JTabbedPane tab = CreateTabPanel(tabs[i], szType);
                try
                {
                    addComponent(tab, this, gridx, gridy, gridwidth, gridheight, GridBagConstraints.BOTH, GridBagConstraints.CENTER);
                    mapDynTabs.put(szName, tab);
                }
                catch ( Exception ex)
                {}
            }
        }
        
        protected void RemoveAllDynTabPanels(String szParent)
        {
            JTabbedPane tab = null;
            try
            {
                tab = (JTabbedPane)mapDynTabs.get(szParent);
                tab.removeAll();
            }
            catch (Exception ex)
            {
                McpExplorer.LogExc("McpForm", "RemoveDynTabPanel", "JTabbedPane not found", ex);
            }            
        }
        
        protected void RemoveDynTabPanel(String szParent, String szName)
        {
            JTabbedPane tab = null;
            try
            {
                tab = (JTabbedPane)mapDynTabs.get(szParent);
                JPanel p = (JPanel)mapTabs.get(szName);
                tab.remove(p);
                mapTabs.remove(szName);
            }
            catch (Exception ex)
            {
                McpExplorer.LogExc("McpForm", "RemoveDynTabPanel", "JTabbedPane not found", ex);
            }                        
        }
        
        protected int getSelectedDynTabIndex(String szParent)
        {
            try
            {
                JTabbedPane tab = (JTabbedPane)mapDynTabs.get(szParent);    
                return(tab.getSelectedIndex() + 1);
            }
            catch (Exception ex)
            {
                McpExplorer.LogExc("McpForm", "getSelectedDynTabIndex", "JTabbedPane not found", ex);
                return(-1);
            }            
        }
        
        protected void AddDynTabPanel(String szParent, String szName, String szLabel, String szTemplate, ResourceBundle res)
        {
            JTabbedPane tab = null;
            try
            {
                tab = (JTabbedPane)mapDynTabs.get(szParent);                
            }
            catch (Exception ex)
            {
                McpExplorer.LogExc("McpForm", "AddDynTabPanel", "JTabbedPane not found", ex);
                return;
            }
            JPanel tmp = new JPanel();
            tmp.setBorder(BorderFactory.createEmptyBorder(20,20,20,20));
            tmp.setLayout(new GridBagLayout());
            tab.add(szLabel, tmp);
            tab.setTabLayoutPolicy(JTabbedPane.WRAP_TAB_LAYOUT);
            mapTabs.put(szName, tmp);
            CreateDynTabFields(szName, szTemplate, res);
        }
        
        private JTabbedPane CreateTabPanel(String szTab, String szType)
        {
            String tab[] = tokenize(getResourceString(szTab));
            JTabbedPane ret = null;
            int iNumTabs = tab.length;
            if(iNumTabs > 0)
            {
                ret = new JTabbedPane();
                if(!szType.equalsIgnoreCase("dyn"))
                {
	                for(int i=0; i < iNumTabs; ++i)
	                {
	                    String szLabel = getResourceString(tab[i] + "Label");
	                    JPanel tmp = new JPanel();
	                    tmp.setBorder(BorderFactory.createEmptyBorder(20,20,20,20));
	                    tmp.setLayout(new GridBagLayout());
	                    ret.add(szLabel, tmp);
	                    ret.setTabLayoutPolicy(JTabbedPane.WRAP_TAB_LAYOUT);
	                    mapTabs.put(tab[i], tmp);
	                }
                }
            }
            return(ret);
        }

        
        protected void CreateDynTabFields(String szPosition, String szTemplatePosition, ResourceBundle res)
        {
            McpExplorer.LogDebug("CreateDynTabFields: Template '" + szTemplatePosition + "', Position '" + szPosition + "'");
            String fields[] = tokenize(getResourceString("fields", res));
            for(int i=0; i < fields.length; ++i)
            {
                String s =  getResourceString(fields[i] + "Position", res);
                //McpExplorer.LogDebug("FIELD: " + fields[i] + ", Position: " + s);
                if(s.equalsIgnoreCase(szTemplatePosition))
                {
                    CreateField(fields[i], szPosition + fields[i], szPosition, res);
                }
            }        
        }
        
        
        private void CreateFields()
        {
            mapKeys = new HashMap();
            mapValues = new HashMap();
            String fields[] = tokenize(getResourceString("fields"));
            for(int i=0; i < fields.length; ++i)
            {
                CreateField(fields[i]);
            }        
        }
        
        protected void CreateField(String szField)
        {
            CreateField(szField, szField, "", resources);
        }
        
        protected void CreateField(String szField, String szKey, String pos, ResourceBundle res)
        {
            //McpExplorer.LogDebug("CreateField: Field '" + szField + "', Key: '" + szKey + "', Position '" + pos + "'");
            JComponent comp = null;
            String szFieldType = getResourceString(szField + "Type", res);
            String szPosition =  getResourceString(szField + "Position", res);
            if(pos.length() > 0)
            {
                szPosition = pos;
            }
            if (szFieldType == null
                    || szPosition == null)
            {
                System.out.println("CreateField '" + szField + "': Type: " + szFieldType + ", Position: " + szPosition);
                return;
            }
                
            if(szFieldType.equalsIgnoreCase("Checkbox"))
            {
                comp = CreateCheckbox(szField, szKey, res);
            }
            else if(szFieldType.equalsIgnoreCase("Label"))
            {
                comp = CreateLabel(szField, szKey, res);
            }
            else if(szFieldType.equalsIgnoreCase("Textfield"))
            {
                comp = CreateTextfield(szField, szKey, res);
            }
            else if(szFieldType.equalsIgnoreCase("Combobox"))
            {
                comp = CreateComboBox(szField, szKey, res);
            }
            else if(szFieldType.equalsIgnoreCase("Fileinput"))
            {
                comp = CreateFileInput(szField, szKey, res);
            }
            else if(szFieldType.equalsIgnoreCase("Button"))
            {
                comp = CreateButton(szField, szKey, res);
            }
            
            // Get Positions from Properties-File
            int gridx = Integer.valueOf(getResourceString(szField + "gridx", res)).intValue();
            int gridy = Integer.valueOf(getResourceString(szField + "gridy", res)).intValue();
            int gridwidth = Integer.valueOf(getResourceString(szField + "gridwidth", res)).intValue();
            int gridheight = Integer.valueOf(getResourceString(szField + "gridheight", res)).intValue();

            if (comp != null)
            {
                try
                {
                    if(szPosition.equalsIgnoreCase("Main"))
                    {
    	                addComponent(comp, this, gridx, gridy, gridwidth, gridheight, GridBagConstraints.BOTH, GridBagConstraints.CENTER);
    	            }
                    else
                    {
                        JPanel tmp = (JPanel)mapTabs.get(szPosition);
                        addComponent(comp, tmp, gridx, gridy, gridwidth, gridheight, GridBagConstraints.BOTH, GridBagConstraints.CENTER);
                    }
                    if(szFieldType.equalsIgnoreCase("Label"))
                    {
                        ((McpLabel)comp).setVisibility();
                    }       
                }
                catch ( Exception ex)
                {}
            }
        }

/*
        private McpCheckBox CreateCheckbox(String szField)
        {
            return(CreateCheckbox(szField, "", resources));
        }
*/        
        private McpCheckBox CreateCheckbox(String szField, String szKey, ResourceBundle res)
        {
            String szIniKey = getResourceString(szField, res);
            if(szKey.length() > 0)
            {
                szIniKey = szKey;
            }
            String szValue = getResourceString(szField + "Default", res);;
            String szValueChecked = getResourceString(szField + "ValueChecked", res);
            String szValueUnchecked = getResourceString(szField + "ValueUnchecked", res);
            String szLabel = getResourceString(szField + "Label", res);
            String szToolTip = getResourceString(szField + "ToolTip", res);
            String szBold = getResourceString(szField + "Bold", res);
            McpCheckBox ret = new McpCheckBox(szIniKey, szValue, szValueChecked, szValueUnchecked, szLabel, szToolTip, szBold);
            ret.addActionListener(new CheckActionChangedListener(ret));
            mapKeys.put(szIniKey, ret);
            mapValues.put(szIniKey, szValue);
            return(ret);
        }
/*       
        private McpComboBox CreateComboBox(String szField)
        {
            return(CreateComboBox(szField, "", resources));
        }
*/        
        private McpComboBox CreateComboBox(String szField, String szKey, ResourceBundle res)
        {
            String szIniKey = getResourceString(szField);
            if(szKey.length() > 0)
            {
                szIniKey = szKey;
            }
            String szDefaultValue = getResourceString(szField + "Default", res);
            String[] szValueList = tokenize(getResourceString(szField + "Values", res)); 
            for(int i = 0; i < szValueList.length; ++i)
            {
                szValueList[i] = szValueList[i].replace('|', ' ');
            }
            String szToolTip = getResourceString(szField + "ToolTip", res);
            String szFormat = getResourceString(szField + "Format", res);
            String szBold = getResourceString(szField + "Bold", res);

            McpComboBox ret = new McpComboBox(szIniKey, szDefaultValue, szValueList, szToolTip, szFormat, szBold);
            
            ret.addActionListener(new ComboActionChangedListener(ret));
            
            mapKeys.put(szIniKey, ret);
            mapValues.put(szIniKey, szDefaultValue);
            return(ret);
        }
/*        
        private McpLabel CreateLabel(String szField)
        {
            return(CreateLabel(szField, "", resources));
        }
*/        
        private McpLabel CreateLabel(String szField, String szKey, ResourceBundle res)
        {
            String szIniKey = getResourceString(szField, res);
            if(szKey.length() > 0)
            {
                szIniKey = szKey;
            }
            String szValue = getResourceString(szField + "Label", res);
            String szVisible = getResourceString(szField + "Visible", res);
            String szBold = getResourceString(szField + "Bold", res);
            McpLabel ret = new McpLabel(szValue, szVisible, szBold);
            mapKeys.put(szIniKey, ret);
            mapValues.put(szIniKey, szValue);
            return(ret);
        }
/*        
        private McpButton CreateButton(String szField)
        {
            return(CreateButton(szField, "", resources));
        }
*/        
        private McpButton CreateButton(String szField, String szKey, ResourceBundle res)
        {
            String szIniKey = getResourceString(szField, res);
            if(szKey.length() > 0)
            {
                szIniKey = szKey;
            }
            String szToolTip = getResourceString(szField + "ToolTip", res);
            String szLabel = getResourceString(szField + "Label", res);
            String szIcon = getResourceString(szField + "Icon", res);
            Icon icon = null;
            URL url = null;
            if(szIcon != null)
            {            
                url = getResource(szField + "Icon");
            }
            if(url != null)
            {
                icon = new ImageIcon(url);
            }
            McpButton ret = new McpButton(szIniKey,szLabel, icon, szToolTip);
            ret.addActionListener(new ButtonActionChangedListener(ret));
            mapKeys.put(szIniKey, ret);
            mapValues.put(szIniKey, szLabel);
            return(ret);
        }
/*        
        private McpTextField CreateTextfield(String szField)
        {
            return(CreateTextfield(szField, "", resources));
        }
*/        
        private McpTextField CreateTextfield(String szField, String szKey, ResourceBundle res)
        {
            String szIniKey = getResourceString(szField, res);
            if(szKey.length() > 0)
            {
                szIniKey = szKey;
            }
            String szValue = getResourceString(szField + "Default", res);
            String szToolTip = getResourceString(szField + "ToolTip", res);
            String szFormat = getResourceString(szField + "Format", res);
            String szEnabled = getResourceString(szField + "Enabled", res);
            String szBold = getResourceString(szField + "Bold", res);
            boolean bEnabled = true;
            if (szEnabled != null
                    && szEnabled.length() > 0)
            {
                bEnabled = "1".equals(szEnabled);
            }
             
            McpTextField ret = new McpTextField(szIniKey, szValue, szToolTip, szFormat, "", "", bEnabled, szBold);   
            ret.addFocusListener(createFieldChangeListener(ret));
            ret.addCaretListener(createFieldCaretListener(ret));
            mapKeys.put(szIniKey, ret);
            mapValues.put(szIniKey, szValue);
            return(ret);
        }
/*        
        private McpFileInput CreateFileInput(String szField)
        {
            return(CreateFileInput(szField, "", resources));
        }
*/        
        private McpFileInput CreateFileInput(String szField, String szKey, ResourceBundle res)
        {
            String szIniKey = getResourceString(szField, res);
            if(szKey.length() > 0)
            {
                szIniKey = szKey;
            }
            String szValue = getResourceString(szField + "Default", res);
            String szToolTip = getResourceString(szField + "ToolTip", res);
//            String szFormat = getResourceString(szField + "Format", res);
            McpFileInput ret = new McpFileInput(szIniKey, szValue, szToolTip);   
            ret.getTextfield().addFocusListener(createFieldChangeListener(ret.getTextfield()));
            ret.getTextfield().addCaretListener(createFieldCaretListener(ret.getTextfield()));
            mapKeys.put(szIniKey, ret);
            mapValues.put(szIniKey, szValue);
            return(ret);
        }
        
        /**
         * Take the given string and chop it up into a series
         * of strings on whitespace boundaries.  This is useful
         * for trying to get an array of strings out of the
         * resource file.
         */
        protected String[] tokenize(String input) 
        {
            Vector v = new Vector();
            StringTokenizer t = new StringTokenizer(input);
            String cmd[];

            while (t.hasMoreTokens())
            {
                v.addElement(t.nextToken());
            }
            cmd = new String[v.size()];
            for (int i = 0; i < cmd.length; i++)
    	    {
                cmd[i] = (String) v.elementAt(i);
    	    }

            return cmd;
        }
        
        protected String getResourceString(String nm) 
        {
        	return getResourceString(nm, resources);
          
        }

        protected URL getResource(String key) 
        {
            return getResource(key, resources);
        }

        protected URL getResource(String key, ResourceBundle res) 
        {
        	String name = getResourceString(key);
        	if (name != null) 
        	{
        	    URL url = McpExplorer.class.getResource(name);
        	    return url;
        	}
        	return null;      
        }

        
        protected String getResourceString(String nm, ResourceBundle res) 
        {
        	String str;
        	try 
        	{
        	    str = res.getString(nm);
        	}
        	catch (MissingResourceException mre) 
        	{
        	    str = null;
        	}
        	return str;
          
        }
        
        protected void addComponent (JComponent component, JPanel cont,        
                int gridx, int gridy, int gridwidth, int gridheight, int fill, int anchor) 
        	throws AWTException 
            
    	{
            if(cont == null)
            {
                return;
            }
            
            LayoutManager lm = cont.getLayout();
            if (!(lm instanceof GridBagLayout)) 
            {
                throw new AWTException ("Invalid layout" + lm);
            } 
            else 
            {
	            GridBagConstraints gbc = new GridBagConstraints ();
	            gbc.gridx = gridx;
	            gbc.gridy = gridy;
	            gbc.gridwidth = gridwidth;
	            gbc.gridheight = gridheight;
	            gbc.fill = fill;
	            gbc.anchor = anchor;
	            ((GridBagLayout)lm).setConstraints(component, gbc);
	            cont.add (component);
            }
        }
    	
        private class FieldCaretListener implements CaretListener
        {
            McpTextField txtField;
            
            FieldCaretListener(McpTextField txt) 
            {
                super();
                this.txtField = txt;
            }
            
            public void caretUpdate(CaretEvent e) 
            {     
                if (e instanceof MutableCaretEvent)
                {
	                String szIniKey = txtField.getIniKey();
	                Object old = mapValues.get(szIniKey);
	                
	                if(old != null)
	                {
	                    String szOldVal = old.toString();
		                if(!szOldVal.equals(this.txtField.getText()))
		                {
		                    mapValues.put(szIniKey, this.txtField.getText());
		                    // Find Position in Document and replace Value
		                    edit.replaceIniValue(szIniKey, txtField.getText(), szType, txtField.getFormat());
		                    FieldChanged(szIniKey, szOldVal, this.txtField.getText());
		                }
	                }
	                else
	                {
	                    mapValues.put(szIniKey, this.txtField.getText());
	                }
                }
            }
        }

        
        private class FieldChangedListener implements FocusListener
        {
            McpTextField txtField;
            
            FieldChangedListener(McpTextField txt) 
            {
                super();
                this.txtField = txt;
            }
            
            public void focusGained(FocusEvent e) 
            {     
                activeField = this.txtField;
            }
            
            public void focusLost(FocusEvent e) 
            {     
                String szIniKey = txtField.getIniKey();
                Object old = mapValues.get(szIniKey);
                
                if(old != null)
                {
                    String szOldVal = old.toString();
                    if(!szOldVal.equals(this.txtField.getText()))
                    {
                        mapValues.put(szIniKey, this.txtField.getText());
                        // Find Position in Document and replace Value
                        edit.replaceIniValue(szIniKey, txtField.getText(), szType, txtField.getFormat());
	                    FieldChanged(szIniKey, szOldVal, this.txtField.getText());
                    }
                }
                else
                {
                    mapValues.put(szIniKey, this.txtField.getText());
                }
            }
        }
        
        private class CheckActionChangedListener implements ActionListener
        {
            McpCheckBox b;
            
            CheckActionChangedListener(McpCheckBox box) 
            {
                super();
                this.b = box;
            }
            
            public void actionPerformed(ActionEvent e) 
            {     
                String szIniKey = b.getIniKey();
                Object old = mapValues.get(szIniKey);
                
                if(old != null)
                {
                    String szOldVal = old.toString();
	                if(!szOldVal.equals(b.getCheckBoxValue()))
	                {
	                    mapValues.put(szIniKey, b.getCheckBoxValue());
	                    // Find Position in Document and replace Value
	                    edit.replaceIniValue(szIniKey, b.getCheckBoxValue(), szType, McpEditor.FORMAT_INTEGER);
	                    FieldChanged(szIniKey, szOldVal, b.getCheckBoxValue());
	                }
                }
                else
                {
                    mapValues.put(szIniKey, b.getCheckBoxValue());
                }
            }
        }
        
        private class ButtonActionChangedListener implements ActionListener
        {
            McpButton b;
            
            ButtonActionChangedListener(McpButton btn) 
            {
                super();
                this.b = btn;
            }
            
            public void actionPerformed(ActionEvent e) 
            {     
                String szIniKey = b.getIniKey();
                FieldChanged(szIniKey, "0", "1");
            }
        }
        
        private class ComboActionChangedListener implements ActionListener
        {
            McpComboBox b;
            
            ComboActionChangedListener(McpComboBox combo) 
            {
                super();
                this.b = combo;
            }
            
            public void actionPerformed(ActionEvent e) 
            {     
                String szIniKey = b.getIniKey();
                Object old = mapValues.get(szIniKey);
                
                if(old != null)
                {
                    String szOldVal = old.toString();
	                if(!szOldVal.equals(b.getComboBoxValue()))
	                {
	                    mapValues.put(szIniKey, b.getComboBoxValue());
	                    // Find Position in Document and replace Value
	                    edit.replaceIniValue(szIniKey, b.getComboBoxValue(), szType, b.getFormat());
	                    FieldChanged(szIniKey, szOldVal, b.getComboBoxValue());
	                }
                }
                else
                {
                    mapValues.put(szIniKey, b.getComboBoxValue());
                }
            }
        }
        
      
        protected FocusListener createFieldChangeListener(McpTextField txt)
        {
            return (new FieldChangedListener(txt));
        }

        protected CaretListener createFieldCaretListener(McpTextField txt)
        {
            return (new FieldCaretListener(txt));
        }

        public void RefreshEditor()
        {
            McpExplorer.LogDebug("Refresh Editor");
            if(activeField != null)
            {
                edit.replaceIniValue(activeField.getIniKey(), activeField.getText(), szType, activeField.getFormat());
                activeField = null;
            }
        }
        
        protected void clearControls()
        {
            Object o[] = mapKeys.values().toArray();
            for(int i = 0; i < o.length; ++i)
            {
                if(o[i] instanceof McpTextField)
                {
                    ((McpTextField)o[i]).resetDefaultValue();
                    //mapValues.put(((McpTextField)o[i]).getIniKey())
                }
                else if(o[i] instanceof McpFileInput)
                {
                    ((McpFileInput)o[i]).resetDefaultValue();
                }
                else if(o[i] instanceof McpComboBox)
                {
                    ((McpComboBox)o[i]).resetDefaultValue();
                }
                else if(o[i] instanceof McpCheckBox)
                {
                    ((McpCheckBox)o[i]).resetDefaultValue();
                }
            }
        }
        
        protected abstract void FieldChanged(String Key, String valueOld, String valueNew);
    }
