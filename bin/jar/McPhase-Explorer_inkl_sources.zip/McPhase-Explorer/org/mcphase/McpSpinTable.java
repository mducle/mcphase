/*
 * Created on 29.09.2005
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package org.mcphase;


/**
 * @author Stefan
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
public class McpSpinTable
{
    private McpSpinRow[] rows;
    private int iNumRows;
    
    public McpSpinTable(int i)
    {
        iNumRows = i;
        rows = new McpSpinRow[i];
    }
    
    public McpSpinTable(int NumRows, int iNumCols, int iNumAtoms, int iNumComps)
    {
        iNumRows = NumRows;
        rows = new McpSpinRow[iNumRows];
        for(int i = 0; i < iNumRows; ++i)
        {
            McpSpinRow r = new McpSpinRow(iNumCols, iNumAtoms, iNumComps);
            rows[i] = r;
        }
    }
    
    public McpSpinTable(McpSpinRow [] r)
    {
        System.arraycopy(r, 0, rows, 0, r.length);
        iNumRows = rows.length;
    }
    
    public McpSpinRow getRow(int i)
    {
        return (rows[i]);
    }

    public void addRows(int iNum)
    {
        for(int i = 0; i < iNum; ++i)
        {
            McpSpinRow r = new McpSpinRow(rows[0].getNumCols(), rows[0].getValAt(0).getNumAtoms(), rows[0].getValAt(0).getNumComps());
            addRow(r);
        }
    }
    
    public void removeRows(int iNum)
    {
        System.arraycopy(rows, 0, rows, 0, iNumRows - iNum);
        iNumRows -= iNum;        
    }
    
    public void addRow(McpSpinRow r)
    {
        McpSpinRow[] rn = rows;
        ++iNumRows;
        rows = new McpSpinRow[iNumRows];
        if(rn != null)
        {
            System.arraycopy(rn, 0 , rows, 0, iNumRows - 1);
        }
        rows[iNumRows - 1] = r;
    }
    
    public void setSpinValueAt(int iRow, int iCol, int iSpinPos, String f)
    {
        rows[iRow].setSpinValAt(iCol, iSpinPos, f);
    }
    
    public String toOutString()
    {
        StringBuffer sb = new StringBuffer();
        for(int i = 0; i < iNumRows; ++i)
        {
            sb.append(rows[i].toOutString());
        }
        return(sb.toString());
    }
    
    public int getNumRows()
    {
        return(iNumRows);
    }

    public void addCols(int iNum)
    {
        for(int i = 0; i < iNumRows; ++i)
        {
            rows[i].addCols(iNum);
        }
    }
    
    public void removeCols(int iNum)
    {
        for(int i = 0; i < iNumRows; ++i)
        {
            rows[i].removeCols(iNum);
        }
    }

    public void addNumAtoms(int iNum)
    {
        for(int i = 0; i < iNumRows; ++i)
        {
            rows[i].addNumAtoms(iNum);
        }
        
    }

    public void removeNumAtoms(int iNum)
    {
        for(int i = 0; i < iNumRows; ++i)
        {
            rows[i].removeNumAtoms(iNum);
        }        
    }

    public void addNumComps(int iNum)
    {
        for(int i = 0; i < iNumRows; ++i)
        {
            rows[i].addNumComps(iNum);
        }
        
    }

    public void removeNumComps(int iNum)
    {
        for(int i = 0; i < iNumRows; ++i)
        {
            rows[i].removeNumComps(iNum);
        }        
    }
}
