/*
 * Created on 22.04.2005
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package org.mcphase;

import javax.swing.event.CaretEvent;
import javax.swing.text.JTextComponent;

/**
 * @author Stefan
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
class MutableCaretEvent extends CaretEvent
{
    static final long serialVersionUID = -6142283929374243417L;
    
    JTextComponent tc;
    
    MutableCaretEvent(JTextComponent t)
    {
        super(t);
        tc = t;
    }
    
    public int getDot()
    {
        return tc.getCaretPosition();
    }

    public int getMark()
    {
        return getMark();
    }        
}


