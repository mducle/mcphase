/*
 * Created on 06.04.2005
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package org.mcphase;

import java.text.ParseException;

import javax.swing.text.DefaultFormatter;

/**
 * @author Stefan
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
public class McpNumberFormatter extends DefaultFormatter
{
    static final long serialVersionUID = -1562405354984738604L;
    
    private final String szMatchFloat = "0123456789e-+.";
    private final String szMatchInteger = "0123456789-+";

    
    private String szMatch = "";
    public McpNumberFormatter(String szFormat)
    {
        setOverwriteMode(true);
        setAllowsInvalid(false);
        if(szFormat != null)
        {
	        if(szFormat.equalsIgnoreCase("Float"))
	        {
	            szMatch = szMatchFloat;
	        }
	        else if (szFormat.equalsIgnoreCase("Integer"))
	        {
	            szMatch = szMatchInteger;
	        }
	        else
	        {
	            szMatch = "";
	        }
        }
    }
    
    public Object stringToValue(String string)
    	throws ParseException
    {
        if(string == null)
        {
            return (null);
        }
        if(!isValid(string))
        {
            throw new ParseException("does not match regex", 0);
        }
        return(super.stringToValue(string));
    }
    
    private boolean isValid(String s)
		throws ParseException
    {
        if(szMatch.length() == 0)
        {
            return(true);
        }
        int iNumE = 0;
        int iNumKomma = 0;
        int iNumSigned = 0;
        for(int i=0; i < s.length();++i)
        {
            char ch = s.charAt(i);
            if (ch == 'e')
            {
                ++iNumE;
            }
            if (ch == '.')
            {
                ++iNumKomma;
                if(iNumKomma == 2 && iNumE < 1)
                {
                    return(false);
                }
            }
            if (ch == '+'
                || ch == '-')
            {
                ++iNumSigned;
                if(i > 0)
                {
                    if (s.charAt( i - 1) != 'e')
                    {
                        return(false);
                    }
                }
            }
            if(szMatch.indexOf(ch) < 0
                    ||iNumE > 1
                    || iNumKomma > 2
                    || iNumSigned > 2)
	        {
                return(false);
	        }
        }
        return true;
    }
}
