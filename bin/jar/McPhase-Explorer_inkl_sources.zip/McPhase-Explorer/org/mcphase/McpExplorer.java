/*
 * Created on 28.01.2005
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package org.mcphase;


import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.Container;
import java.awt.Event;
import java.awt.FileDialog;
import java.awt.Frame;
import java.awt.Graphics;
import java.awt.Insets;
import java.awt.event.ActionEvent;
import java.awt.event.KeyEvent;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.beans.PropertyChangeEvent;
import java.beans.PropertyChangeListener;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.Reader;
import java.io.Writer;
import java.net.URL;
import java.util.Hashtable;
import java.util.LinkedList;
import java.util.List;
import java.util.Locale;
import java.util.MissingResourceException;
import java.util.ResourceBundle;
import java.util.StringTokenizer;
import java.util.Vector;
import java.util.logging.ConsoleHandler;
import java.util.logging.FileHandler;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.logging.SimpleFormatter;
import java.util.prefs.PreferenceChangeEvent;
import java.util.prefs.PreferenceChangeListener;
import java.util.prefs.Preferences;

import javax.swing.AbstractAction;
import javax.swing.Action;
import javax.swing.BorderFactory;
import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JComponent;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JProgressBar;
import javax.swing.JScrollPane;
import javax.swing.JSplitPane;
import javax.swing.JTabbedPane;
import javax.swing.JToolBar;
import javax.swing.JTree;
import javax.swing.JViewport;
import javax.swing.KeyStroke;
import javax.swing.SwingUtilities;
import javax.swing.UIManager;
import javax.swing.event.TreeSelectionEvent;
import javax.swing.event.TreeSelectionListener;
import javax.swing.event.UndoableEditEvent;
import javax.swing.event.UndoableEditListener;
import javax.swing.text.BadLocationException;
import javax.swing.text.Document;
import javax.swing.text.JTextComponent;
import javax.swing.text.PlainDocument;
import javax.swing.text.Segment;
import javax.swing.text.TextAction;
import javax.swing.tree.TreePath;
import javax.swing.undo.CannotRedoException;
import javax.swing.undo.CannotUndoException;
import javax.swing.undo.UndoManager;

import org.mcphase.display.McpViewer;
import org.mcphase.display.display;
import org.mcphase.display.displaybubbles;
import org.mcphase.display.displaycontour;
import org.mcphase.display.displaymag;
import org.mcphase.forms.McpMcPhaseIni;
import org.mcphase.forms.McpMcphasJ;
import org.mcphase.forms.McpMcphasTst;
import org.mcphase.forms.McpSipf;




/**
 * @author Stefan
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
public class McpExplorer extends JPanel
{
    static final long serialVersionUID = -7338581797909886851L;
    
    public static ResourceBundle resources;
    private static Logger log;
    public static String szMainPath;
 
    public static List processes;
    
//    private JMenuBar menubar;
    private JSplitPane splitPaneMain;
    private JSplitPane splitPaneEdit;
    
    private JToolBar toolbar;
    private JComponent status;
    private FileSystemTree tree;

    private JTabbedPane MainTab;
    
    private JPanel panelEditor;

    private McpEditor editor;
    private JScrollPane scrollerEditor;
    
    private JScrollPane scrollermcphaseini;    
    private McpMcPhaseIni mcphaseini;
    
    private JScrollPane scrollermcphasj;
    private McpMcphasJ mcphasj;
    
    private JScrollPane scrollermcphastst;
    private McpMcphasTst mcphastst;

    private JScrollPane scrollersipf;
    private McpSipf sipf;
    
    private McpOutput out;
    
    private McpHelpFrame help;
    
    protected FileDialog fileDialog;
    /**
     * Listener for the edits on the current document.
     */
    protected UndoableEditListener undoHandler = new UndoHandler();

    /** UndoManager that we add edits to. */
    protected UndoManager undo = new UndoManager();
    
   
    public static boolean bIsRunning = false; 

    private Hashtable commands;
    private Hashtable menuItems;

    /**
     * Suffix applied to the key used in resource file
     * lookups for an image.
     */
    public static final String imageSuffix = "Image";

    /**
     * Suffix applied to the key used in resource file
     * lookups for a label.
     */
    public static final String labelSuffix = "Label";

    /**
     * Suffix applied to the key used in resource file
     * lookups for an action.
     */
    public static final String actionSuffix = "Action";

    /**
     * Suffix applied to the key used in resource file
     * lookups for tooltip text.
     */
    public static final String tipSuffix = "Tooltip";

    public static final String newAction  = "new";
    public static final String saveAction = "save";
    public static final String exitAction = "exit";
    public static final String deleteAction = "fdelete";
    public static final String runAction = "run";
    public static final String stopAction = "stop";
    public static final String newdirAction = "newdir";
    public static final String showhelpAction = "showhelp";
    public static final String showaboutAction = "showabout";
    public static final String showprefsAction = "prefs";
    
    public static final String nameEditor = "Editor";
    public static final String nameDirectory = "Directory";
    public static final String nameMcPhasIni = "McpIni";
    public static final String nameMcPhasJ = "McpJ";
    public static final String nameMcPhasTst = "McpTst";
    public static final String nameSipf = "Sipf";

    private String activePane = nameDirectory;
    
    public static Preferences userPrefs;
    
    public static boolean bDocumentChanged = false;
    
    static 
    {
        log = Logger.getLogger("org.mcphase.McpExplorer");
        
        try
        {
            FileHandler fh = new FileHandler("C:\\temp\\mcp.log");
            fh.setFormatter(new SimpleFormatter());            
            log.addHandler(fh);
            ConsoleHandler ch = new ConsoleHandler();
            log.addHandler(ch);
        }
        catch(IOException ioex)
        {
            // Logging only to Console
        }
        
        try 
        {
            resources = ResourceBundle.getBundle("org.mcphase.resources.McpExplorer", Locale.getDefault());
        } 
        catch (MissingResourceException mre) 
        {
            System.err.println("org/mcphase/resources/McpExlorer.properties not found");
            System.exit(1);
        }
        userPrefs = Preferences.userNodeForPackage(McpExplorer.class);

        if(userPrefs.getBoolean("LogDebug", false))
        {
            log.setLevel(Level.ALL);
        }
        else
        {
            log.setLevel(Level.INFO);
        }
        
        processes = new LinkedList();
        
        userPrefs.addPreferenceChangeListener(new PreferenceChangeListener()                
                {
            		public void preferenceChange(PreferenceChangeEvent ev)
            		{
            		    String szKey = ev.getKey();
            		    if(szKey.equalsIgnoreCase("LogDebug"))
            		    {
            		        if(ev.getNewValue().equalsIgnoreCase("true"))
            		        {
            		            log.setLevel(Level.ALL);
            		        }
            		        else
            		        {
            		            log.setLevel(Level.INFO);
            		        }
            		    }
            		}
                });
    }

    public static synchronized void LogDebug(String szMsg)
    {
        Log(Level.FINE, szMsg);
    }

    public static synchronized void LogInfo(String szMsg)
    {
        Log(Level.INFO, szMsg);
    }

    public static synchronized void LogWarning(String szMsg)
    {
        Log(Level.WARNING, szMsg);
    }

    public static synchronized void LogError(String szMsg)
    {
        Log(Level.SEVERE, szMsg);
    }

    public static synchronized void LogExc(String szClass, String szMethod, String szMsg, Exception ex)
    {
        log.logp(Level.SEVERE, szClass, szMethod, szMsg, ex);
    }

    public static synchronized void Log(Level l, String szMsg)
    {
        log.log(l, szMsg);
    }

    public McpExplorer()
    {
        this("");
    }	
    
    public McpExplorer(String szPath) 
    {
    	super(true);
    	LogInfo("Starting in Directory '" + szPath + "'");
    	szMainPath = szPath;

    	// Force SwingSet to come up in the Cross Platform L&F
    	try 
    	{
    	    //UIManager.setLookAndFeel(UIManager.getCrossPlatformLookAndFeelClassName());
    	    // If you want the System L&F instead, comment out the above line and
    	    // uncomment the following:
    	    LogDebug("Set Look And Feel");
    	    UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
    	} 
    	catch (Exception exc) 
    	{
    	    System.err.println("Error loading L&F: " + exc);
    	    LogExc(this.getName(), "Constructor", "Error loading L&F", exc);
    	}

    	// Create Help Frame
    	LogDebug("Create Help Frame");
        URL url = getResource("helpIcon");
        ImageIcon icon = new ImageIcon(url);
    	help = new McpHelpFrame(getResourceString("HelpFrameTitle"), icon);

    	setBorder(BorderFactory.createEtchedBorder());
    	setLayout(new BorderLayout());

    	// create the embedded JTextComponent
    	LogDebug("Create Editor - Component");
    	editor = createEditor();
    	// Add this as a listener for undoable edits.
    	editor.getDocument().addUndoableEditListener(undoHandler);
    	scrollerEditor = new JScrollPane();
    	JViewport port = scrollerEditor.getViewport();   	    	
    	port.add(editor);  	
    	
    	// create Form components    	
    	LogDebug("Create McPhasIni - Component");
    	mcphaseini = new McpMcPhaseIni(editor);
    	scrollermcphaseini = new JScrollPane();
    	JViewport portmcphaseini = scrollermcphaseini.getViewport();   	    	
    	portmcphaseini.add(mcphaseini);

    	LogDebug("Create McPhasJ - Component");
    	mcphasj = new McpMcphasJ(editor);
    	scrollermcphasj = new JScrollPane();
    	JViewport portmcphasj = scrollermcphasj.getViewport();  
    	portmcphasj.add(mcphasj);

    	LogDebug("Create McPhasTst - Component");
    	mcphastst = new McpMcphasTst(editor);
    	scrollermcphastst = new JScrollPane();
    	JViewport portmcphastst = scrollermcphastst.getViewport();
    	portmcphastst.add(mcphastst);

    	LogDebug("Create Sipf - Component");
    	sipf = new McpSipf(editor);
    	scrollersipf = new JScrollPane();
    	JViewport portsipf = scrollersipf.getViewport();
    	portsipf.add(sipf);
    	
    	
    	LogDebug("Create Main Tab");
    	MainTab = new JTabbedPane();
    	
    	
    	// install the command table
    	LogDebug("Install Command Table");
    	commands = new Hashtable();
    	Action[] actions = getActions();
    	for (int i = 0; i < actions.length; i++) 
    	{
    	    Action a = actions[i];
    	    commands.put(a.getValue(Action.NAME), a);
    	}
    	
    	menuItems = new Hashtable();
    	panelEditor = new JPanel();
    	panelEditor.setLayout(new BorderLayout());	
    	panelEditor.add("Center", scrollerEditor);

    	LogDebug("Create Filesystem Tree");
    	tree = new FileSystemTree(szMainPath);
    	tree.getTree().addMouseListener( new MouseListener()
    	        {
    	    		public void mouseEntered(MouseEvent ev)
    	    		{
    	    		    //System.out.println("mouseEntered");
    	    		}
    	    		public void mouseReleased(MouseEvent ev)
    	    		{
    	    		    //System.out.println("mouseReleased");
    	    		}
    	    		public void mouseExited(MouseEvent ev)
    	    		{
    	    		    //System.out.println("mouseExited");
    	    		}
    	    		public void mousePressed(MouseEvent ev)
    	    		{
    	    		    //System.out.println("mousePressed");
    	    		}
    	    		public void mouseClicked(MouseEvent ev)
    	    		{
    	    		    if(ev.getClickCount() > 1)
    	    		    {
    	    		    	LogDebug("Mouse-Double-Clicked Event");
            		        TreePath tp = tree.getTree().getSelectionPath();
                		    if(tp != null)
                		    {
    	            		    FileObject fo = (FileObject)tp.getLastPathComponent();
    	            		    if(!fo.isDirectory())
    	            		    {
                                    if (bDocumentChanged)
                                    {
                                        int i = JOptionPane.showConfirmDialog(null, "Do You want to save the Changes ?", "McpExplorer", JOptionPane.YES_NO_CANCEL_OPTION);
                                        if(i == JOptionPane.YES_OPTION)
                                        {
                                            Frame frame = getFrame();            
                                            FileObject f = editor.getFileObject();
                                            
                                            if(f == null)
                                            {
                                                JFileChooser chooser = new JFileChooser(szMainPath);
                                                int ret = chooser.showSaveDialog(frame);
                                    
                                                if (ret != JFileChooser.APPROVE_OPTION) 
                                                {
                                                    return;
                                                }
                                    
                                                f = new FileObject(chooser.getSelectedFile(), true);
                                            }
                                            mcphaseini.RefreshEditor();
                                            mcphasj.RefreshEditor();
                                            sipf.RefreshEditor();
                                            mcphastst.RefreshEditor();
                                           
                                            frame.setTitle(resources.getString("Title") + " - " + f.getFile().getName());
                                            
                                            Thread saver = new FileSaver(f.getFile(), editor.getDocument());
                                            saver.start();
                                            try
                                            {
                                                saver.join();
                                            }
                                            catch(Exception ex)
                                            {
                                                // do nothing
                                            }
//                                            OpenDoc(f);
                                            
                                        }
                                        else if(i == JOptionPane.NO_OPTION)
                                        {
                                            // do nothing
                                        }
                                        else if(i == JOptionPane.CANCEL_OPTION)
                                        {
                                            return;
                                        }
                                    }                                    
    	            		        OpenDoc(fo);
    	            		    }
                		    }    	    		        
    	    		    }
    	    		}    	    		    	    
    	        });
    	
    	tree.getTree().addTreeSelectionListener(new TreeSelectionListener()
                {
            		public void valueChanged(TreeSelectionEvent tse)
            		{            		    
            		    TreePath tp = tse.getNewLeadSelectionPath();
            		    //LogDebug("Tree-Selection Event: " + tp.toString());
            		    if(tp != null)
            		    {
//            		        Frame frame = getFrame();
	            		    FileObject fo = (FileObject)tp.getLastPathComponent();
	            		    if(fo.isDirectory() && !McpExplorer.bIsRunning)
	            		    {
	            		        getAction(newdirAction).setEnabled(true);
	            		        if(fo.IsValidMcPhasDirectory())
	            		        {
	            		            getAction(runAction).setEnabled(true);
	            		        }
	            		        else
	            		        {
	            		            getAction(runAction).setEnabled(false);
	            		        }
	            		    }
	            		    else
	            		    {
	            		        getAction(newdirAction).setEnabled(false);	            		        
	            		        getAction(runAction).setEnabled(false);
	            		    }
            		        toolbar.revalidate();	            		        
            		    }
            		}          		
                }
        );
    	
    	LogDebug("Create Output-Component");
    	out = new McpOutput();
    	JPanel panelOutput = new JPanel();
    	panelOutput.setLayout(new BorderLayout());    	
    	JScrollPane scrollerOut = new JScrollPane();
    	JViewport portOut = scrollerOut.getViewport();   	    	
    	portOut.add(out);

    	panelOutput.add(scrollerOut, BorderLayout.CENTER);
    	splitPaneEdit = new JSplitPane(JSplitPane.VERTICAL_SPLIT, panelEditor, panelOutput);
    	splitPaneEdit.setContinuousLayout(true); 
    	splitPaneEdit.setOneTouchExpandable(true); 
    	splitPaneEdit.setDividerLocation(500); 
    	
    	
    	splitPaneMain = new JSplitPane(JSplitPane.HORIZONTAL_SPLIT, tree, splitPaneEdit);    	
    	splitPaneMain.setContinuousLayout(true); 
    	splitPaneMain.setOneTouchExpandable(true); 
    	splitPaneMain.setDividerLocation(200); 
        this.add(splitPaneMain, BorderLayout.CENTER);     	
        
        LogDebug("Create Toolbar");
        toolbar = (JToolBar)createToolbar("");
    	add("North",toolbar);
    	add("Center", splitPaneMain);
    	add("South", createStatusbar());
        getAction(newdirAction).setEnabled(false);	            		        
        getAction(runAction).setEnabled(false);
        
        
    }
    
    
    public static void main(String[] args)
    {
        try 
        {
            String szPath = "";
            
            if (args.length > 0)
            {
                szPath = args[0];
            }
            String vers = System.getProperty("java.version");
            if (vers.compareTo("1.5.0") < 0) 
            {
                System.out.println("!!!WARNING: This Application must be run with a 1.5.0 or higher version VM!!!");
            }
            
            JFrame frame = new JFrame();
            frame.setTitle(resources.getString("Title"));
            frame.setBackground(Color.lightGray);
            frame.getContentPane().setLayout(new BorderLayout());
            McpExplorer expl = new McpExplorer(szPath);
            frame.getContentPane().add("Center", expl);
            frame.setJMenuBar(expl.createMenubar());
            frame.addWindowListener(new AppCloser());
            frame.pack();
            frame.setSize(1024, 768);
            URL url = expl.getResource("TitleIcon");
            frame.setIconImage(new ImageIcon(url).getImage());
            frame.setVisible(true);

            boolean bShowSplashScreen = userPrefs.getBoolean("ShowSplashScreen", true);
            if(bShowSplashScreen)
            {
                new McpSplashScreen(frame, "Introduction", new ImageIcon(url), new URL("file:" + szPath + expl.getResourceString("SplahScreenContent")));
            }
         
        } 
        catch (Exception t) 
        {        
    	    LogExc(McpExplorer.class.getName(), "MAIN", "uncaught exception", t);
            t.printStackTrace();       
        }
        
    }


    /**
     * To shutdown when run as an application.  This is a
     * fairly lame implementation.   A more self-respecting
     * implementation would at least check to see if a save
     * was needed.
     */
    protected static final class AppCloser extends WindowAdapter 
    {
        public void windowClosing(WindowEvent e) 
        {
            if(McpExplorer.bIsRunning)
            {
                Object o[] = McpExplorer.processes.toArray();
                if(o != null)
                {
                    for(int i = 0; i < o.length; ++i)
                    {
                        if(o[i] instanceof Process)
                        {
                            try
                            {
                                ((Process)o[i]).destroy();
                            }
                            catch(Exception ex)
                            {
                                
                            }
                        }
                    }
                }
            }
            System.exit(0);
        }
    }

    
    
    protected String getResourceString(String nm) 
    {
    	String str;
    	try 
    	{
    	    str = resources.getString(nm);
    	}
    	catch (MissingResourceException mre) 
    	{
    	    str = null;
    	}
    	return str;
    }

   
    protected URL getResource(String key) 
    {
    	String name = getResourceString(key);
    	if (name != null) 
    	{
    	    URL url = this.getClass().getResource(name);
    	    return url;
    	}
    	return null;      
    }

    /**
     * Create the toolbar.  By default this reads the 
     * resource file for the definition of the toolbar.
     */
    private Component createToolbar(String szType) 
    {
        JToolBar tmp = new JToolBar();
        String[] toolKeys = tokenize(getResourceString("toolbar" + szType));
        for (int i = 0; i < toolKeys.length; i++) 
        {
            if (toolKeys[i].equals("-")) 
            {
                tmp.add(Box.createHorizontalStrut(5));
            } 
            else 
            {
                tmp.add(createTool(toolKeys[i]));
            }
        }
        tmp.add(Box.createHorizontalGlue());
        return tmp;
    }

    /**
     * Hook through which every toolbar item is created.
     */
    protected Component createTool(String key) 
    {
        return createToolbarButton(key);
    }

    /**
     * Create a button to go inside of the toolbar.  By default this
     * will load an image resource.  The image filename is relative to
     * the classpath (including the '.' directory if its a part of the
     * classpath), and may either be in a JAR file or a separate file.
     * 
     * @param key The key in the resource file to serve as the basis
     *  of lookups.
     */
    protected JButton createToolbarButton(String key) 
    {
        //System.out.println("Create-TollbarButton: " + key);

        URL url = getResource(key + imageSuffix);
        String astr = getResourceString(key + actionSuffix);
        if (astr == null) 
        {
            astr = key;
        }
        JButton b = new JButton(new ImageIcon(url))         
        {
            static final long serialVersionUID = 1L;
            public float getAlignmentY() { return 0.5f; }
        };
        
        Action a = getAction(astr);
        if (a != null) 
        {
            b.setAction(a);
            b.setIcon(new ImageIcon(url));
            b.setText("");
        } 
        else 
        {
            b.setEnabled(false);
        }
        b.setRequestFocusEnabled(false);
        b.setMargin(new Insets(1,1,1,1));

        String tip = getResourceString(key + tipSuffix);
        if (tip != null) 
        {
            b.setToolTipText(tip);
        }

        return b;
    }

    /**
     * Create a status bar
     */
    protected Component createStatusbar() 
    {
        // need to do something reasonable here
        status = new StatusBar();
        return status;
    }

    
    
    /**
     * Create the menubar for the app.  By default this pulls the
     * definition of the menu from the associated resource file. 
     */
    protected JMenuBar createMenubar() 
    {
        //JMenuItem mi;
        JMenuBar mb = new JMenuBar();

        String[] menuKeys = tokenize(getResourceString("menubar"));
        for (int i = 0; i < menuKeys.length; i++) 
        {
            JMenu m = createMenu(menuKeys[i]);
            if (m != null) 
            {
                mb.add(m);
            }
        }
//        this.menubar = mb;
        return mb;
    }

    /**
     * Create a menu for the app.  By default this pulls the
     * definition of the menu from the associated resource file.
     */
    protected JMenu createMenu(String key) 
    {
        String[] itemKeys = tokenize(getResourceString(key));
        JMenu menu = new JMenu(getResourceString(key + "Label"));
        for (int i = 0; i < itemKeys.length; i++) 
        {
            if (itemKeys[i].equals("-")) 
            {                
                menu.addSeparator();
            } 
            else 
            {
                JMenuItem mi = createMenuItem(itemKeys[i]);
                menu.add(mi);
            }
        }
        return menu;
    }


    /**
     * This is the hook through which all menu items are
     * created.  It registers the result with the menuitem
     * hashtable so that it can be fetched with getMenuItem().
     * @see #getMenuItem
     */
    protected JMenuItem createMenuItem(String cmd) 
    {
        JMenuItem mi;
        if(cmd.equalsIgnoreCase("save"))
        {
            // Save button = ctrl-s.
            mi = new JMenuItem(getResourceString(cmd + labelSuffix), KeyEvent.VK_S);
            mi.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_S, Event.CTRL_MASK));
        }
        else
        {
            mi = new JMenuItem(getResourceString(cmd + labelSuffix));
        }
        URL url = getResource(cmd + imageSuffix);
        if (url != null) 
        {
            mi.setHorizontalTextPosition(JButton.RIGHT);
            mi.setIcon(new ImageIcon(url));
        }
        String astr = getResourceString(cmd + actionSuffix);
        if (astr == null) 
        {
            astr = cmd;
        }
        mi.setActionCommand(astr);
        Action a = getAction(astr);
        if (a != null) 
        {
            mi.addActionListener(a);
            a.addPropertyChangeListener(createActionChangeListener(mi));
            mi.setEnabled(a.isEnabled());
        } 
        else 
        {
            mi.setEnabled(false);
        }
        menuItems.put(cmd, mi);
        return mi;
    }

    /**
     * Fetch the menu item that was created for the given
     * command.
     * @param cmd  Name of the action.
     * @returns item created for the given command or null
     *  if one wasn't created.
     */
    protected JMenuItem getMenuItem(String cmd) 
    {
        return (JMenuItem) menuItems.get(cmd);
    }

    protected Action getAction(String cmd) 
    {
    	return (Action) commands.get(cmd);    
    }

    /**
     * Fetch the list of actions supported by this
     * editor.  It is implemented to return the list
     * of actions supported by the embedded JTextComponent
     * augmented with the actions defined locally.
     */
    public Action[] getActions() 
    {
        return TextAction.augmentList(editor.getActions(), defaultActions);
    }

    /**
     * Find the hosting frame, for the file-chooser dialog.
     */
    protected Frame getFrame() 
    {
        for (Container p = getParent(); p != null; p = p.getParent()) 
        {
            if (p instanceof Frame)             
            {
                return (Frame) p;
            }
        }
        return null;
    }

    
    
    /**
     * Take the given string and chop it up into a series
     * of strings on whitespace boundaries.  This is useful
     * for trying to get an array of strings out of the
     * resource file.
     */
    protected String[] tokenize(String input) 
    {
        Vector v = new Vector();
        StringTokenizer t = new StringTokenizer(input);
        String cmd[];

        while (t.hasMoreTokens())
        {
            v.addElement(t.nextToken());
        }
        cmd = new String[v.size()];
        for (int i = 0; i < cmd.length; i++)
	    {
            cmd[i] = (String) v.elementAt(i);
	    }

        return cmd;
    }

    // Yarked from JMenu, ideally this would be public.
    protected PropertyChangeListener createActionChangeListener(JMenuItem b) 
    {
        return new ActionChangedListener(b);
    }

    // Yarked from JMenu, ideally this would be public.
    private class ActionChangedListener implements PropertyChangeListener 
    {
        JMenuItem menuItem;
        
        ActionChangedListener(JMenuItem mi) 
        {
            super();
            this.menuItem = mi;
        }
        
        public void propertyChange(PropertyChangeEvent e) 
        {
            String propertyName = e.getPropertyName();
            if (e.getPropertyName().equals(Action.NAME)) 
            {
                String text = (String) e.getNewValue();
                menuItem.setText(text);
            } 
            else if (propertyName.equals("enabled")) 
            {
                Boolean enabledState = (Boolean) e.getNewValue();
                menuItem.setEnabled(enabledState.booleanValue());
            }
        }
    }


    // Yarked from JMenu, ideally this would be public.
    protected PropertyChangeListener createActionChangeListener(JTree b) 
    {
        return new ActionChangedListenerTree(b);
    }

    // Yarked from JMenu, ideally this would be public.
    private class ActionChangedListenerTree implements PropertyChangeListener 
    {
        JTree treeItem;
        
        ActionChangedListenerTree(JTree b) 
        {
            super();
            this.treeItem = b;
        }
        
        public void propertyChange(PropertyChangeEvent e) 
        {
            String propertyName = e.getPropertyName();
            System.out.println("PROP-Change: " + propertyName);
            if (e.getPropertyName().equals(Action.NAME)) 
            {
//                String text = (String) e.getNewValue();
//                menuItem.setText(text);
            } 
            else if (propertyName.equals("anchorSelectionPath")) 
            {
 //               Boolean enabledState = (Boolean) e.getNewValue();
  //              menuItem.setEnabled(enabledState.booleanValue());
            }
        }
    }

    
    // --- action implementations -----------------------------------

    private UndoAction undoAction = new UndoAction();
    private RedoAction redoAction = new RedoAction();

    /**
     * Actions defined by the McpExplorer class
     */
    private Action[] defaultActions = 
    {
            new NewAction(),
            new SaveAction(),
            new ExitAction(),
            new NewdirAction(),
            new RunAction(),
            new StopAction(),
            new DeleteAction(),
            new ShowHelpAction(),
            new ShowAboutAction(),
            new ShowPrefsAction(),
            undoAction,
            redoAction
    };

    class UndoAction extends AbstractAction 
    {
        static final long serialVersionUID = 4583893766805389460L;
        public UndoAction() 
        {
            super("Undo");
            setEnabled(false);
        }

        public void actionPerformed(ActionEvent e) 
        {
            try 
            {
                undo.undo();
            } 
            catch (CannotUndoException ex) 
            {
                System.out.println("Unable to undo: " + ex);
                ex.printStackTrace();
            }
            update();
            redoAction.update();
        }

		protected void update() 
		{
		    if(undo.canUndo()) 
		    {
		        setEnabled(true);
		        putValue(Action.NAME, undo.getUndoPresentationName());
		    }
		    else 
		    {
		        setEnabled(false);
		        putValue(Action.NAME, "Undo");
		    }
		}
    }

    class RedoAction extends AbstractAction 
    {
        static final long serialVersionUID = 8986286913418331476L;
        
        public RedoAction() 
        {
            super("Redo");
            setEnabled(false);
        }

        public void actionPerformed(ActionEvent e) 
        {
            try 
            {
                undo.redo();
            } 
            catch (CannotRedoException ex) 
            {
                System.out.println("Unable to redo: " + ex);
                ex.printStackTrace();
            }
            update();
            undoAction.update();
        }

        protected void update() 
        {
            if(undo.canRedo()) 
            {
                setEnabled(true);
                putValue(Action.NAME, undo.getRedoPresentationName());
            }
            else 
            {
                setEnabled(false);
                putValue(Action.NAME, "Redo");
            }
        }
    }

    
    class NewdirAction extends AbstractAction 
    {
        static final long serialVersionUID = -7800100587954081286L;
        
        NewdirAction() 	
        {	    
            super(newdirAction);	
        }

        public void actionPerformed(ActionEvent e) 
        {
            Object o = JOptionPane.showInputDialog(null, getResourceString("dlgNewdirText"), getResourceString("dlgNewdirTitle"), 
                    JOptionPane.QUESTION_MESSAGE, null, null, getResourceString("dlgNewdirDefault"));
            if (o != null)
            {
                String szName = o.toString();
    		    TreePath tp = tree.getTree().getSelectionPath();
    		    if(tp != null)
    		    {
        		    FileObject fo = (FileObject)tp.getLastPathComponent();
        		    if(fo.isDirectory())
        		    {
        		        // Create Directory with Name specified
        		        File f = new File(fo.getFile().getAbsolutePath() + File.separatorChar + szName);
        		        f.mkdir();
        		        File res = new File(f.getAbsolutePath() + File.separatorChar + "results");
        		        res.mkdir();
        		        // Copy Standard-Files
        		        CopyFiles(f);
        		    }
    		    }
            }
        }
    }

    void CopyFiles(File fRoot)
    {
        /*
        String[] files = tokenize(getResourceString("newfiles"));
        for (int i = 0; i < files.length; i++) 
        {
            try
            {
                String szName = getResourceString(files[i] + "File");
                szName = szName.substring(szName.lastIndexOf('/') + 1);
                File fNew = new File(fRoot.getAbsolutePath() + File.separatorChar + szName);
                fNew.createNewFile();
                
                URL url = getResource(files[i] + "File");
                InputStream in = url.openConnection().getInputStream();
                OutputStream out = new FileOutputStream(fNew);

                // Transfer bytes from in to out
                byte[] buf = new byte[1024];
                int len;
                while ((len = in.read(buf)) > 0) 
                {
                    out.write(buf, 0, len);
                }
                in.close();
                out.close();
                
            }
            catch(IOException ex)
            {
                ShowErrorMsg("Copy New File", ex);
            }
        } 
        */
        McpUnzip u = new McpUnzip(fRoot);
        u.unZip(szMainPath + File.separator + "jar" + File.separator + "default_files.zip");
    }    
    // Copies src file to dst file.
    // If the dst file does not exist, it is created
    void copy(File src, File dst) throws IOException 
    {
        InputStream in = new FileInputStream(src);
        OutputStream out = new FileOutputStream(dst);
    
        // Transfer bytes from in to out
        byte[] buf = new byte[1024];
        int len;
        while ((len = in.read(buf)) > 0) 
        {
            out.write(buf, 0, len);
        }
        in.close();
        out.close();
    }
    
    private synchronized void deleteFile(File f)
    {
        if (f.isDirectory())
        {
            File [] childs = f.listFiles();
            for(int i = 0; i < childs.length; ++i)
            {
                deleteFile(childs[i]);
            }
        }
        if(!f.delete())
        {
            ShowErrorMsg("Achtung !", "Konnte Datei " + f.getAbsolutePath() + " nicht l�schen !");
        }
    }
    
    class RunAction extends AbstractAction 
    {
        static final long serialVersionUID = 6336010170301257205L;
        RunAction() 	
        {	    
            super(runAction);	
        }

        public void actionPerformed(ActionEvent e) 
        {
 //           Frame frame = getFrame();
		    TreePath tp = tree.getTree().getSelectionPath();
		    if(tp != null)
		    {
    		    FileObject fo = (FileObject)tp.getLastPathComponent();
    		    if(fo.isDirectory())
    		    {
    		        int i = JOptionPane.showConfirmDialog(null, "Are you sure you want to start mcphas in the directory " + 
    		                fo.getFile().getAbsolutePath(), "McpExplorer", JOptionPane.YES_NO_CANCEL_OPTION);
    		        if(i == JOptionPane.YES_OPTION)
    		        {
	    		        try
	    		        {
	    		            String[] params = new String[3];
	    		            if(File.separator.equalsIgnoreCase("\\"))
                            {
                                params[0] = szMainPath + File.separator + "bin" + File.separator + "mcphasit.exe -v";
    	    		            params[1] = szMainPath + File.separator + "bin" + File.separator + "mcphasgraphics.bat";
                            }
                            else
                            {
                                params[0] = szMainPath + File.separator + "bin" + File.separator + "mcphas -v";
                                //params[1] = szMainPath + File.separator + "bin" + File.separator + "mcphasgraphics";
                                params[1] = "";
                            }
                            
/*	    		            params[1] = szMainPath + "\\jre1.5.0_03\\bin\\java -cp " 
	    		            	+ szMainPath + "\\jar\\MCPHAS.JAR;" 
	    		            	+ szMainPath + "\\jar\\jgl3.1.0.JAR;" 
	    		            	+ szMainPath + "\\jar\\kcServlet.JAR;" 
	    		            	+ szMainPath + "\\jar\\javaview.JAR;" 
	    		            	+ szMainPath + "\\jar\\sgt_v30.JAR;" 
	    		            	+ " displaymag 2 11 .\\results\\.mcphas.fum 2 12 .\\results\\.mcphas.fum 2 13 .\\results\\.mcphas.fum";	    		            
*/	
	    		            out.start(params, fo.getFile());
	    		        }
	    		        catch (Exception ex)
	    		        {
	    		            System.out.println("EXC in Run: " + ex.getClass().getName() + ": " + ex.getMessage());
	    		            ShowErrorMsg("Start", ex);
	    		        }
    		        }
    		    }
		    }
        }
    }

    class StopAction extends AbstractAction 
    {
        static final long serialVersionUID = -7002437158716329105L;
        
        StopAction() 	
        {	    
            super(stopAction);	
        }

        public void actionPerformed(ActionEvent e) 
        {
//            Frame frame = getFrame();
	        int i = JOptionPane.showConfirmDialog(null, "Are you sure you want to stop mcphas ?", "McpExplorer", JOptionPane.YES_NO_CANCEL_OPTION);
	        if(i == JOptionPane.YES_OPTION)
	        {
		        try
		        {
		            out.stop();    		           
		        }
		        catch (Exception ex)
		        {
		            System.out.println("EXC in Stop: " + ex.getClass().getName() + ": " + ex.getMessage());
		            ShowErrorMsg("Stop", ex);
		        }
	        }
        }
    }

    class SaveAction extends AbstractAction 
    {
        static final long serialVersionUID = 5407646502871820900L;
        
        SaveAction() 
        {
            super(saveAction);
        }

        public void actionPerformed(ActionEvent e) 
        {
            
            Frame frame = getFrame();            
            FileObject f = editor.getFileObject();
            
            if(f == null)
            {
	            JFileChooser chooser = new JFileChooser(szMainPath);
	            int ret = chooser.showSaveDialog(frame);
	
	            if (ret != JFileChooser.APPROVE_OPTION) 
	            {
	                return;
	            }
	
	            f = new FileObject(chooser.getSelectedFile(), true);
            }
            mcphaseini.RefreshEditor();
            mcphasj.RefreshEditor();
            sipf.RefreshEditor();
            mcphastst.RefreshEditor();
           
            frame.setTitle(resources.getString("Title") + " - " + f.getFile().getName());
            
            Thread saver = new FileSaver(f.getFile(), editor.getDocument());
            saver.start();
            try
            {
                saver.join();
            }
            catch(Exception ex)
            {
                // do nothing
            }
            OpenDoc(f);
        }
    }

    class DeleteAction extends AbstractAction 
    {
        static final long serialVersionUID = -6359459811532792128L;
        
    	DeleteAction() 
        {
            super(deleteAction);
        }

        public void actionPerformed(ActionEvent e) 
        {
		    TreePath tp = tree.getTree().getSelectionPath();
		    if(tp != null)
		    {
    		    FileObject fo = (FileObject)tp.getLastPathComponent();
	            int iRet = JOptionPane.showConfirmDialog(getFrame(), "Do you really want to delete " + fo.getFile().getName() + " ?");
	            if (iRet == JOptionPane.OK_OPTION)
	            {
	                deleteFile(fo.getFile());
	            }
		    }		    
        }
    }

    class ShowHelpAction extends AbstractAction 
    {
        static final long serialVersionUID = 6050433791150151276L;
        ShowHelpAction() 
        {
            super(showhelpAction);
        }

        public void actionPerformed(ActionEvent e) 
        {
            try
            {
                URL url = new URL("file:" + szMainPath +  getResourceString("HelpUrl" + activePane));
                help.showHelp(url);
            }
            catch(Exception ex)
            {
                
            }
        }
    }

    class ShowAboutAction extends AbstractAction 
    {
        static final long serialVersionUID = -8481637603361494525L;
        ShowAboutAction() 
        {
            super(showaboutAction);
        }

        public void actionPerformed(ActionEvent e) 
        {
            JOptionPane.showMessageDialog(getFrame(), "<html><b>McPhase Explorer</b></html>\n\nVersion 1.0.0\n(c) 2005 by McPhase Developer Team\nWritten by Stefan Rotter\n\nVisit www.mcphase.de", "About", JOptionPane.INFORMATION_MESSAGE, new ImageIcon(getResource("AboutIcon")));        
        }
    }

    class ShowPrefsAction extends AbstractAction 
    {
        static final long serialVersionUID = 1997282177162324058L;
        
        ShowPrefsAction() 
        {
            super(showprefsAction);
        }

        public void actionPerformed(ActionEvent e) 
        {
            new McpPreferences(getFrame());
        }
    }

    class NewAction extends AbstractAction 
    {
        static final long serialVersionUID = 6866049396174532903L;
        
        NewAction() 
        {
            super(newAction);
        }

        NewAction(String nm) 
        {
            super(nm);
        }

        public void actionPerformed(ActionEvent e) 
        {
            Document oldDoc = getEditor().getDocument();
            if(oldDoc != null)
            {
                oldDoc.removeUndoableEditListener(undoHandler);
            }
            getEditor().setDocument(new PlainDocument());
            getEditor().getDocument().addUndoableEditListener(undoHandler);
            resetUndoManager();
            getFrame().setTitle(resources.getString("Title"));
            editor.setFileObject(null);
            revalidate();
        }
    }
    
    /**
     * Resets the undo manager.
     */
    protected void resetUndoManager() 
    {
        undo.discardAllEdits();
        undoAction.update();
        redoAction.update();
    }


    /**
     * Really lame implementation of an exit command
     */
    class ExitAction extends AbstractAction 
    {
        static final long serialVersionUID = 5202532961486953886L;
        
        ExitAction() 
        {
            super(exitAction);
        }

        public void actionPerformed(ActionEvent e) 
        {
            out.stop();
            System.exit(0);
        }
    }

    class UndoHandler implements UndoableEditListener 
    {
    	/**
    	 * Messaged when the Document has created an edit, the edit is
    	 * added to <code>undo</code>, an instance of UndoManager.
    	 */
        public void undoableEditHappened(UndoableEditEvent e) 
        {
            undo.addEdit(e.getEdit());
    	    undoAction.update();
    	    redoAction.update();
            bDocumentChanged = true;
    	}
    }

    /**
     * Create an editor to represent the given document.  
     */
    protected McpEditor createEditor() 
    {
        return new McpEditor();
    }

    protected FileSystemTree getTree()
    {
        return tree;
    }
    
    /** 
     * Fetch the editor contained in this panel
     */
    protected JTextComponent getEditor() 
    {
        return editor;
    }
    /**
     * Thread to load a file into the text storage model
     */
    class FileLoader extends Thread 
    {
		Document doc;
		File f;

        FileLoader(File f, Document doc) 
        {
            setPriority(4);
            this.f = f;
            this.doc = doc;
        }

        public void run() 
        {
            try 
            {
			// initialize the statusbar
            //	status.removeAll();
                 JProgressBar progress = new JProgressBar();
                 progress.setMinimum(0);
                 progress.setMaximum((int) f.length());
                 //status.add(progress);
                 //status.revalidate();
		
				// try to start reading
				Reader in = new FileReader(f);
				char[] buff = new char[4096];
				int nch;
				while ((nch = in.read(buff, 0, buff.length)) != -1) 
				{
				    doc.insertString(doc.getLength(), new String(buff, 0, nch), null);
				    progress.setValue(progress.getValue() + nch);
				}	    
		    }
		    catch (IOException e) 
		    {
		        ShowErrorMsg("Open File", e);
		    }
		    catch (BadLocationException e) 
		    {
		        System.err.println(e.getMessage());
		    }
		    doc.addUndoableEditListener(undoHandler);
	        
		    // we are done... get rid of progressbar
	//	    status.removeAll();
	//    	status.revalidate();
		    resetUndoManager();
        }
    }
	

    /**
     * Thread to save a document to file
     */
    class FileSaver extends Thread 
    {        
        Document doc;
        File f;

        FileSaver(File f, Document doc) 
        {
            setPriority(4);
            this.f = f;
            this.doc = doc;
        }

        public void run() 
        {
	    
            try 
            {

                // initialize the statusbar
//				status.removeAll();
				JProgressBar progress = new JProgressBar();
				progress.setMinimum(0);
				progress.setMaximum((int) doc.getLength());
//				status.add(progress);
//				status.revalidate();
	
				// start writing
				Writer out = new FileWriter(f);
				Segment text = new Segment();
				text.setPartialReturn(true);
				int charsLeft = doc.getLength();
				int offset = 0;
				while (charsLeft > 0) 
				{
				    doc.getText(offset, Math.min(4096, charsLeft), text);
				    out.write(text.array, text.offset, text.count);
				    charsLeft -= text.count;
				    offset += text.count;
				    progress.setValue(offset);
				    try 
				    {
				        Thread.sleep(10);
				    } 
				    catch (InterruptedException e) 
				    {
				        e.printStackTrace();
				    }
	                
				}
				out.flush();
				out.close();
		    }
		    catch (IOException e) 
		    {	        
		        ShowErrorMsg("Save File", e);
		    }
		    catch (BadLocationException e) 
		    {
		        System.err.println(e.getMessage());
		    }
		    // we are done... get rid of progressbar
		    //status.removeAll();
		    //status.revalidate();
        }
    }
    
    /**
     * FIXME - I'm not very useful yet
     */
    class StatusBar extends JComponent 
    {
        static final long serialVersionUID = 1974796483197092700L;
        
        public StatusBar() 
        {
            super();
            setLayout(new BoxLayout(this, BoxLayout.X_AXIS));
        }

        public void paint(Graphics g) 
        {	    
            super.paint(g);
        }
    }

    public void ShowErrorMsg(String szTitle, Exception ex)
    {
        ShowErrorMsg(szTitle, ex.getClass().getName() + ": " + ex.getMessage());
    }
    
    public void ShowErrorMsg(String szTitle, String szMsg)
    {
        final String msg = szMsg;
        final String title = szTitle;
        
        SwingUtilities.invokeLater(new Runnable() 
        {
        	public void run() 
        	{
        	    JOptionPane.showMessageDialog(getFrame(),
                    msg,
                    title,
                    JOptionPane.ERROR_MESSAGE);
        	}
        });
        
    }
    
    private void ViewFile(FileObject fo)
    {
    	String s = fo.getFile().getName();
    	String sPath = fo.getFile().getAbsolutePath();
    	String cmd[] = new String[0];
    	if(s.toUpperCase().endsWith(".JPG")||s.toUpperCase().endsWith(".GIF"))
    	{
    		new McpViewer(sPath);
    	}
    	else if(s.toUpperCase().endsWith(".CVT")||
    			s.toUpperCase().endsWith(".HST")||
    			s.toUpperCase().endsWith("CP.CLC")||
    			s.toUpperCase().endsWith(".RTPLOT"))
    	{	    		
    		String[] arg = {"1", "2", sPath};
    		display.main(arg);
    	}
    	else if(s.toUpperCase().endsWith(".FUM"))
    	{	    		
    		String[] arg = {"1", "11", sPath, "1", "12", sPath, "1", "13", sPath};
    		displaymag.main(arg);
    		String[] arg1 = {"2", "11", sPath, "2", "12", sPath, "2", "13", sPath};
    		displaymag.main(arg1);
    	}
    	else if(s.toUpperCase().endsWith(".DSIGMA.TOT"))
    	{	    		
    		String[] arg = {"5", "6", "8", sPath};
    		displaycontour.main(arg);
    		String[] arg1 = {"5", "7", "8", sPath};
    		displaycontour.main(arg1);
    		String[] arg2 = {"6", "7", "8", sPath};
    		displaycontour.main(arg2);
    	}
    	else if(s.toUpperCase().endsWith(".QEI"))
    	{	    		
    		String[] arg = {"5", "8", "9", sPath};
    		displaybubbles.main(arg);
    		String[] arg1 = {"6", "8", "9", sPath};
    		displaybubbles.main(arg1);
    		String[] arg2 = {"7", "8", "9", sPath};
    		displaybubbles.main(arg2);
    	}    	
    	else if(s.toUpperCase().endsWith(".JVX"))
    	{	    		
    		cmd = new String [] {"cmd", "/c", "start", szMainPath + "\\bin\\phased.bat", sPath};
    	}
    	else if(s.toUpperCase().endsWith(".PS")||s.toUpperCase().endsWith(".EPS"))
    	{
    		cmd = new String [] {"cmd", "/c", "start", "phased", s};
    	}    	
    	else 
   		{
    		if(s.toUpperCase().endsWith(".FST"))
	    	{
	    		cmd = new String [] {"cmd", "/c", "start", szMainPath + "\\bin\\fp_studio.exe", s};
	    	}
	    	else if(s.toUpperCase().endsWith(".GNU"))
	    	{
	    		cmd = new String [] {"cmd", "/c", "start", szMainPath + "\\bin\\gnuplot", s};
	    	}
	    	else if(s.toUpperCase().endsWith(".XYT"))
	    	{
	    		cmd = new String [] {"cmd", "/c", "start", 
	    				szMainPath + "\\perl\\bin\\perl.exe", 
	    				szMainPath + "\\bin\\phased",
	    				sPath};
	    	}
	    	else if(s.toUpperCase().endsWith(".QOM"))
	    	{
	    		cmd = new String [] {"cmd", "/c", "start", szMainPath + "\\bin\\disp", "5", sPath};
	    	}
    		
    		
			/*
		    pJ.directory(new File(dir));
		    pJ.environment().put("MCPHASE_DIR", "C:\\mcphas");
		    */
		    try
		    {
		    	String dir = fo.getFile().getAbsolutePath();
		    	dir = dir.substring(0, dir.lastIndexOf("\\"));
		    	ProcessBuilder pJ = new ProcessBuilder (cmd);
		        pJ.directory(new File(dir));
		    	pJ.start();
		    	
		    }
		    catch(Exception ex)
		    {
		    	LogExc("McpExplorer", "View File", "Start Process", ex);
		    }
   		}
    }
    
    private synchronized void OpenDoc(FileObject fo)
    {
        Frame frame = getFrame();
	    String szFileType = fo.GetFileType();
	    if(fo.isFile() && fo.getFile().canRead())
	    {
	        
            Document oldDoc = getEditor().getDocument();
            if(oldDoc != null)
            {
                oldDoc.removeUndoableEditListener(undoHandler);
            }
            editor.setFileObject(fo);
            getEditor().setDocument(new PlainDocument());
            frame.setTitle(resources.getString("Title") + " - " + fo.getFile().getName());
            Thread loader = new FileLoader(fo.getFile(), editor.getDocument());
            loader.start();
            if(!szFileType.equals("default"))
            {
                try
                {
                    loader.join();
                }
                catch(Exception ex)
                {
                    // do nothing
                }
            }
	    }
        panelEditor.removeAll();
	    if(fo.isDirectory())
	    {
	        getAction(newdirAction).setEnabled(true);
	        getAction(runAction).setEnabled(true);
	        toolbar.revalidate();	
	        panelEditor.repaint();
	        activePane = McpExplorer.nameDirectory;
	    }
	    else
	    {
	    	if(szFileType.equals("viewfile"))
	    	{
	    		ViewFile(fo);
	    	}
	    	else
	    	{
		        getAction(newdirAction).setEnabled(false);	            		        
		        getAction(runAction).setEnabled(false);
		        toolbar.revalidate();	            		        
	
			    if(szFileType.equals("mcphas_ini"))
			    {
			        mcphaseini.initFromEditor();
			        
			        MainTab.removeAll();
			        MainTab.add(scrollermcphaseini, "McPhase-Ini");
			    	MainTab.add(scrollerEditor, "Editor");   
			        panelEditor.add(MainTab, BorderLayout.CENTER);
			        panelEditor.repaint();
			        activePane = McpExplorer.nameMcPhasIni;
			    }
			    else if(szFileType.equals("mcphas_j"))
			    {
			        mcphasj.initFromEditor();
			        
			        MainTab.removeAll();
			        MainTab.add(scrollermcphasj, "McPhas-J");
			    	MainTab.add(scrollerEditor, "Editor");   
			        panelEditor.add(MainTab, BorderLayout.CENTER);
			        panelEditor.repaint();
			        activePane = McpExplorer.nameMcPhasJ;
			    }
			    else if(szFileType.equals("sipf"))
			    {
			        sipf.initFromEditor();
			        
			        MainTab.removeAll();
			        MainTab.add(scrollersipf, "Sipf");
			    	MainTab.add(scrollerEditor, "Editor");   
			        panelEditor.add(MainTab, BorderLayout.CENTER);
			        panelEditor.repaint();
			        activePane = McpExplorer.nameSipf;
			    }
			    else if(szFileType.equals("mcphas_tst"))
			    {
			        mcphastst.initFromEditor();
			        
			        MainTab.removeAll();
			        MainTab.add(scrollermcphastst, "McPhas-Tst");
			    	MainTab.add(scrollerEditor, "Editor");   
			        panelEditor.add(MainTab, BorderLayout.CENTER);
			        panelEditor.repaint();
			        activePane = McpExplorer.nameMcPhasTst;
			    }
			    else
			    {
			        panelEditor.add(scrollerEditor, BorderLayout.CENTER);	            		        
			        activePane = McpExplorer.nameEditor;
			    }
	    	}
	    }        
        bDocumentChanged = false;
    }
    
    
}







