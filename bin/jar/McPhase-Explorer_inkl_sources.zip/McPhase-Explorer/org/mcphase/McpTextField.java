/*
 * Created on 28.01.2005
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package org.mcphase;

import java.awt.Font;

import javax.swing.JFormattedTextField;
import javax.swing.event.CaretListener;

/**
 * @author Stefan
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
public class McpTextField extends JFormattedTextField
{
    static final long serialVersionUID = -8196329304204109230L;
    
    private String m_IniKey;
    private String m_Value;
    private String m_ToolTip;
//    private double m_Minimum;
//    private double m_Maximum;
    private boolean m_Enabled;
    private boolean m_bBold;
    private int m_Format;
    protected MutableCaretEvent caretEvent;
    private String m_DefaultValue;

    public McpTextField(String szIniKey, String szValue, String szToolTip, String szFormat)
    {
        this(szIniKey, szValue, szToolTip, szFormat, "", "", true, "0");
    }
    
    public McpTextField(String szIniKey, String szValue, String szToolTip, String szFormat, String szMinimum, String szMaximum, boolean bEnabled, String szBold)
    {

        super(new McpNumberFormatter(szFormat));
        
        if(szIniKey != null)
        {
            m_IniKey = szIniKey;
        }
        m_Value = szValue;
        m_ToolTip = szToolTip;
        m_Enabled = bEnabled;
        m_DefaultValue = szValue;
        if(szFormat != null)
        {
            if(szFormat.equalsIgnoreCase("Text"))
            {
                m_Format = McpEditor.FORMAT_TEXT;
            }
            else if(szFormat.equalsIgnoreCase("Integer"))
            {
                m_Format = McpEditor.FORMAT_INTEGER;
            }
            else if(szFormat.equalsIgnoreCase("Float"))
            {
                m_Format = McpEditor.FORMAT_FLOAT;
            }            
        }
        if(szBold != null)
        {
            if (szBold.equals("0"))
            {
                m_bBold = false;
            }
            else
            {
                m_bBold = true;
            }
        }
        
        Init();
    }
    
    private void Init()
    {
        this.setText(m_Value);
        this.setName(m_IniKey); 
        this.setEditable(true);
        this.setEnabled(m_Enabled);
        this.setToolTipText(m_ToolTip);
        caretEvent = new MutableCaretEvent(this);
        if(m_bBold)
        {
            this.setFont(this.getFont().deriveFont(Font.BOLD));
        }

    }

    public String getIniKey()
    {
        return(m_IniKey);
    }
    
    public void setIniKey(String s)
    {
        m_IniKey = s;
    }
    
    public int getFormat()
    {
        return(m_Format);
    }
    

    public void setValue(String newVal)
    {
        super.setValue(newVal);
        fireCaretEvent();        
    }
    
    protected void fireCaretEvent()
    {
	    Object[] listeners = listenerList.getListenerList();
	    for(int i = listeners.length - 2; i >= 0; i--)
	    {
	    
	        if(listeners[i] == CaretListener.class)	    
	        {	        
	            ((CaretListener)listeners[i+1]).caretUpdate(caretEvent);	    
	        }
	    }
    }

    public void resetDefaultValue()
    {
        m_Value = m_DefaultValue;
        setText(m_DefaultValue);
    }
}