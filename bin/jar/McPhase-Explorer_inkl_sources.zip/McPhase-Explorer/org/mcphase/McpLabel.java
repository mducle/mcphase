/*
 * Created on 31.01.2005
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package org.mcphase;

import java.awt.Container;
import java.awt.Font;

import javax.swing.BorderFactory;
import javax.swing.JLabel;

/**
 * @author Stefan
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
public class McpLabel extends JLabel
{
    static final long serialVersionUID = -5879827027893783646L;
    
    private String m_Value;
    private boolean m_bVisible;
    private boolean m_bBold;
    
    public McpLabel(String szValue, String szVisible, String szBold)
    {
        super(szValue);
        m_Value = szValue;
        m_bVisible = true;
        if(szVisible != null)
        {
            if (szVisible.equals("0"))
            {
                m_bVisible = false;
            }
        }
        if(szBold != null)
        {
            if (szBold.equals("0"))
            {
                m_bBold = false;
            }
            else
            {
                m_bBold = true;
            }
        }
        Init();
    }
    
    private void Init()
    {
        this.setText(m_Value);
        this.setBorder(BorderFactory.createEmptyBorder(5,5,5,5));
        if(m_bBold)
        {
            this.setFont(this.getFont().deriveFont(Font.BOLD));
        }
    }

    public void setVisibility()
    {
        try
        {
	        if(!m_bVisible)
	        {
	            Container par = this.getParent();
	            if(par != null)
	            {
	                this.setForeground(par.getBackground());
	            }
	        }        
        }
        catch(Exception ex)
        {
            // do nothing
        }
    }
}
