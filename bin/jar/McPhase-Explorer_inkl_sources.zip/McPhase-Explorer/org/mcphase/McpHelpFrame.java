/*
 * Created on 21.04.2005
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package org.mcphase;

import java.awt.Container;
import java.awt.Cursor;
import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URL;

import javax.swing.ImageIcon;
import javax.swing.JEditorPane;
import javax.swing.JFrame;
import javax.swing.JScrollPane;
import javax.swing.JViewport;
import javax.swing.SwingUtilities;
import javax.swing.event.HyperlinkEvent;
import javax.swing.event.HyperlinkListener;
import javax.swing.text.Document;

/**
 * @author Stefan
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
public class McpHelpFrame
{
    private String m_Title;
    
    private JFrame frame;
    private HtmlPane pane;
    
    public McpHelpFrame(String szTitle, ImageIcon i)
    {
        m_Title = szTitle;
        frame = new JFrame(m_Title);
        frame.setIconImage(i.getImage());
        pane = new HtmlPane();
        frame.setContentPane(new JScrollPane(pane));
        frame.setSize(600, 768);
    }

/*    public void showHelp(String url)
    {
        showHelp(new URL(url));
    }
    */
    public void showHelp(URL url)
    {
        if(!frame.isVisible())
        {
            frame.setVisible(true);
        }
        try
        {
            pane.setUrl(url);
        }
        catch(Exception ex)
        {
            ex.printStackTrace();
        }
    }
    
    
    class HtmlPane extends JScrollPane implements HyperlinkListener 
    {
        static final long serialVersionUID = 5499145226995998212L;
        
        JEditorPane html;

        public HtmlPane() 
        {
    	    html = new JEditorPane();
    	    html.setEditable(false);
    	    html.addHyperlinkListener(this);

    	    JViewport vp = getViewport();
    	    vp.add(html);
        }

        public void setUrl(URL url)
        {
	    	try 
	    	{
            	html.setPage(url);
	    	}
	    	catch (MalformedURLException e) 
	    	{
	    	    System.out.println("Malformed URL: " + e);
	    	}
	    	catch (IOException e) 
	    	{
	    	    System.out.println("IOException: " + e);
	    	}	
        }
        /**
         * Notification of a change relative to a 
         * hyperlink.
         */
        public void hyperlinkUpdate(HyperlinkEvent e) 
        {
            if (e.getEventType() == HyperlinkEvent.EventType.ACTIVATED) 
            {
                linkActivated(e.getURL());
            }
        }

        /**
         * Follows the reference in an
         * link.  The given url is the requested reference.
         * By default this calls <a href="#setPage">setPage</a>,
         * and if an exception is thrown the original previous
         * document is restored and a beep sounded.  If an 
         * attempt was made to follow a link, but it represented
         * a malformed url, this method will be called with a
         * null argument.
         *
         * @param u the URL to follow
         */
        protected void linkActivated(URL u) 
        {
            Cursor c = html.getCursor();
            Cursor waitCursor = Cursor.getPredefinedCursor(Cursor.WAIT_CURSOR);
            html.setCursor(waitCursor);
            SwingUtilities.invokeLater(new PageLoader(u, c));
        }

        /**
         * temporary class that loads synchronously (although
         * later than the request so that a cursor change
         * can be done).
         */
        class PageLoader implements Runnable 
        {
    	
            private URL url;
            private Cursor cursor;
            
            PageLoader(URL u, Cursor c) 
            {
                url = u;
                cursor = c;
            }

            public void run() 
            {
                if (url == null) 
                {
                    // restore the original cursor
                    html.setCursor(cursor);

		    		// PENDING(prinz) remove this hack when 
		    		// automatic validation is activated.
		    		Container parent = html.getParent();
		    		parent.repaint();

                } 
                else 
                {
		    		Document doc = html.getDocument();
		    		try 
		    		{
		    		    html.setPage(url);
		    		}
		    		catch (IOException ioe) 
		    		{
		    		    html.setDocument(doc);
		    		    getToolkit().beep();
		    		} 
		    		finally 
		    		{
		    		    // schedule the cursor to revert after
		    		    // the paint has happended.
		    		    url = null;
		    		    SwingUtilities.invokeLater(this);
		    		}
	    	    }
	    	}
        }
    }
}
