/*
 * Created on 30.08.2005
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package org.mcphase;

import java.awt.Color;
import java.awt.Component;

import javax.swing.JLabel;
import javax.swing.JTable;
import javax.swing.SwingConstants;
import javax.swing.table.DefaultTableCellRenderer;

/**
 * @author Stefan
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
public class McpTableCellRenderer extends DefaultTableCellRenderer
{
    static final long serialVersionUID = -843772852214306759L;
    
    public McpTableCellRenderer()
    {
        setHorizontalAlignment(JLabel.RIGHT);
        setHorizontalTextPosition(SwingConstants.RIGHT);       
    }
    
    public Component getTableCellRendererComponent(JTable table, Object value, boolean isSelected, boolean hasFocus, int row, int col)
    {
        if(value == null || value.toString().length() == 0)
        {
            setBackground(Color.RED);            
        }
        else
        {
            setBackground(Color.WHITE);
        }
        return super.getTableCellRendererComponent(table, value, isSelected, hasFocus, row, col);
    }
}
