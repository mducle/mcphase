/*
 * Created on 28.01.2005
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package org.mcphase;

import java.awt.Font;

import javax.swing.DefaultComboBoxModel;
import javax.swing.JComboBox;

/**
 * @author Stefan
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
public class McpComboBox extends JComboBox
{
    static final long serialVersionUID = 2803941549404197437L;
    
    private String m_IniKey;
    private boolean m_bBold;
    private String m_DefaultValue;
   
    private int m_Format = McpEditor.FORMAT_TEXT;
    
    public McpComboBox(String szIniKey, String szDefaultValue, String[] szValueList, String szToolTip, String szFormat, String szBold)
    {
        super(new DefaultComboBoxModel(szValueList));
        m_IniKey = szIniKey;        
        this.setName(szIniKey);
        this.setToolTipText(szToolTip);
        this.setSelectedItem(szDefaultValue);
        m_DefaultValue = szDefaultValue;

        if(szFormat != null)
        {
            if(szFormat.equalsIgnoreCase("Text"))
            {
                m_Format = McpEditor.FORMAT_TEXT;
            }
            else if(szFormat.equalsIgnoreCase("Integer"))
            {
                m_Format = McpEditor.FORMAT_INTEGER;
            }
            else if(szFormat.equalsIgnoreCase("Float"))
            {
                m_Format = McpEditor.FORMAT_FLOAT;
            }            
        }
        if(szBold != null)
        {
            if (szBold.equals("0"))
            {
                m_bBold = false;
            }
            else
            {
                m_bBold = true;
            }
        }
        if(m_bBold)
        {
            this.setFont(this.getFont().deriveFont(Font.BOLD));
        }

    }

    public int getFormat()
    {
        return(m_Format);
    }
    
    public String getComboBoxValue()
    {
        Object o = this.getSelectedItem();
        if(o != null)
        {
            return(o.toString());
        }
        return(null);
    }
    
    public void setComboBoxValue(String szValue)
    {
        this.setSelectedItem(szValue);
        this.revalidate();
    }
    
    public String getIniKey()
    {
        return(m_IniKey);
    }

    public void resetDefaultValue()
    {
        setSelectedItem(m_DefaultValue);
    }
    
    public void FillWithIntList(int iMax)
    {
        DefaultComboBoxModel m = (DefaultComboBoxModel)this.getModel();
        if(m.getSize() > 0)
        {
            try
            {
                m.removeAllElements();
            }
            catch(Exception ex)
            {
                McpExplorer.LogExc("McpComboBox", "FillWithIntList", "EXC", ex);
            }
        }
        for(int i = 1; i <= iMax; ++i)
        {
            m.addElement(String.valueOf(i));
        }
    }
}
