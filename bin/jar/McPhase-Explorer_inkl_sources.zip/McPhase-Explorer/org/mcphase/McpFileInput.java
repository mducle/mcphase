/*
 * Created on 23.05.2005
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package org.mcphase;

import java.awt.Container;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.net.URL;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFileChooser;
import javax.swing.JPanel;
import javax.swing.event.CaretListener;

/**
 * @author Stefan
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
public class McpFileInput extends JPanel
{
    static final long serialVersionUID = 3558673194045522317L;
    
    private McpTextField text;
    private JButton btnChoose;

/*    
    private String m_IniKey;
    private String m_Value;

    private String m_ToolTip;
    private int m_Format;
*/    
    protected MutableCaretEvent caretEvent;
    
    public McpFileInput(String szIniKey, String szValue, String szToolTip)
    {
        text = new McpTextField(szIniKey, szValue, szToolTip, "Text");
        text.setEnabled(false);
        URL url = this.getClass().getResource(McpExplorer.resources.getString("filechooserIcon"));
        ImageIcon ic = new ImageIcon(url);
        btnChoose = new JButton(ic);
        btnChoose.setIcon(ic);
        btnChoose.setSize(ic.getIconWidth(), ic.getIconHeight());
        btnChoose.addActionListener(new ActionListener()
                {
            		public void actionPerformed(ActionEvent ev)
            		{
            		    McpExplorer expl = getExplorer();
            		    String p = McpExplorer.szMainPath;
            		    if(expl != null)
            		    {
            		        p = ((FileObject)expl.getTree().getTree().getSelectionPath().getLastPathComponent()).getFile().getAbsolutePath();
            		    }
            		    JFileChooser chooser = new JFileChooser(p);
            		    chooser.setMultiSelectionEnabled(false);            		
            		    chooser.setFileSelectionMode(JFileChooser.FILES_ONLY);
            		    int option = chooser.showOpenDialog(McpFileInput.this);
            		    if(option == JFileChooser.APPROVE_OPTION)
            		    {
            		        String s = chooser.getSelectedFile().getName();
            		        text.setValue(s);
            		        text.revalidate();
            		    }            		    
            		}
                }
        );
        GridLayout gl = new  GridLayout(1,1);
        this.setLayout(gl);
        
        this.add(text);
        this.add(btnChoose);
    }
    
    public String getIniKey()
    {
        return(text.getIniKey());
    }
    
    public void setIniKey(String s)
    {
        text.setIniKey(s);
    } 
    
    public int getFormat()
    {
        return(text.getFormat());
    }
    

    public void setValue(String newVal)
    {
        text.setValue(newVal);
    }
    
    public McpTextField getTextfield()
    {
        return(text);
    }
    
    protected McpExplorer getExplorer() 
    {
        for (Container p = getParent(); p != null; p = p.getParent()) 
        {
            if (p instanceof McpExplorer)             
            {
                return (McpExplorer) p;
            }
        }
        return null;
    }

    protected void fireCaretEvent()
    {
	    Object[] listeners = listenerList.getListenerList();
	    for(int i = listeners.length - 2; i >= 0; i--)
	    {
	    
	        if(listeners[i] == CaretListener.class)	    
	        {	        
	            ((CaretListener)listeners[i+1]).caretUpdate(caretEvent);	    
	        }
	    }
    }

    public void resetDefaultValue()
    {
        text.resetDefaultValue();
    }

}
