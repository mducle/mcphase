/*
 * Created on 22.03.2005
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package org.mcphase;

import java.awt.Font;
import java.util.Scanner;

import javax.swing.JTextArea;

/**
 * @author Stefan
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
public class McpEditor extends JTextArea
{
    static final long serialVersionUID = -7435339209128809105L;
    
    private FileObject f;
    private final String szMatch = "0123456789Ee-+.";
    
    public final static int FORMAT_INTEGER = 0;
    public final static int FORMAT_FLOAT = 1;
    public final static int FORMAT_TEXT = 2;
    
    
    public McpEditor()
    {
        super();
        setDragEnabled(true);
        setFont(new Font("monospaced", Font.PLAIN, 12));
    }
    
    public void setFileObject(FileObject fi)
    {
        f = fi;
    }
    
    public FileObject getFileObject()
    {
        return(f);
    }

    private boolean isValidKeyPos(String szSource, String szKey, int iPos)
    {
        if(iPos < 0)
        {
            return(false);
        }
        if(iPos == 0)
        {
            return(isValidAfterwards(szSource, szKey, iPos));
        }
        if(("# \t").indexOf(szSource.charAt(iPos - 1)) >= 0)                
        {
            return(isValidAfterwards(szSource, szKey, iPos));
        }
        return(false);
    }
    
    private boolean isValidAfterwards(String szSource, String szKey, int iPos)
    {
        int newPos = iPos + szKey.length();
        for(int i = newPos; i < szSource.length(); ++i)
        {
            char c = szSource.charAt(i);
            if((" \t=").indexOf(c) >= 0)
            {
                if( c == '=')
                {
                    return(true);
                }
            }
            else
            {
                return(false);
            }
        }
        return(true);
    }
    
    private int GetStartPosValue(String szSource, int iPosStart)
    {
        boolean bStarted = false;
        int iPosAfterEqual = iPosStart;
        for(int i = iPosStart; i < szSource.length(); ++i)
        {
            char c = szSource.charAt(i);
            if((" \t=").indexOf(c) >= 0)
            {
                if( c == '=')
                {
                    bStarted = true;
                    iPosAfterEqual = i + 1;
                }
            }
            if (bStarted)
            {
                if(szMatch.indexOf(c) >= 0)
                {
                    return(i);
                }
                if((" \t=").indexOf(c) < 0)
                {
                    return(iPosAfterEqual);
                }
            }
        }
        return(iPosAfterEqual);
    }

    /*
    private int GetLenValue(String szSource, int iPosStart)
    {
        return(GetLenValue(szSource, iPosStart, McpEditor.FORMAT_FLOAT, false));
    }
    */
    
    private int GetLenValue(String szSource, int iPosStart, int iFormat, boolean bIgnoreBlank)
    {
        int i = iPosStart;
        for(i = iPosStart; i < szSource.length(); ++i)
        {
            char c = szSource.charAt(i);
            if(iFormat != McpEditor.FORMAT_TEXT)
            {
	            if(szMatch.indexOf(c) < 0)
	            {
	                break;
	            }
            }
            else
            {
	            if(c == '\n'
	                || c == '\t'
	                || c == '\r')
	            {
	                break;
	            }  
	            if(c == ' ' && !bIgnoreBlank)
	            {
	                break;
	            }
            }
        }   
        return(i - iPosStart);
    }
    
    private void replaceJIniValue(String szIniKey, String szValue, int iFormat)
    {
        McpExplorer.LogDebug("REPLACE (JINI): " + szIniKey + " WITH '" + szValue + "'");
        try
        {
            // We can get 
            // 1. Main Variables
            // 2. Atom Variables
            // 3. Table Variables
            
            // Get Format of Variable            
            
            if(!szIniKey.startsWith("tab1Pan"))
            {
                // 1. Main Part Variables
	            String szTxt = this.getDocument().getText(0, getDocument().getLength());
	            Scanner scan = new Scanner(szTxt);
	            scan.useDelimiter("\n");
	            int iDocPos = 0;
	            while (scan.hasNext()) 
	            {
	                String s = scan.next();
	                int iPos = s.indexOf(szIniKey);
	                while(isValidKeyPos(s, szIniKey, iPos))
	                {         
	                    int iPosStartValue = GetStartPosValue(s, iPos + szIniKey.length());
	                    int iLen = GetLenValue(s, iPosStartValue, iFormat, false);
	                    
	                    if (iLen > 0)
	                    {
	                        this.getDocument().remove(iDocPos + iPosStartValue, iLen);                        
	                    }		                                
	                    this.getDocument().insertString(iDocPos +iPosStartValue, szValue, null);
	                    iPos = s.indexOf(szIniKey, iPos+1);
	                }
	                iDocPos += s.length() + 1;
	            }
	            scan.close();
	            scan = null;
	        }
            else
            {
                // Magentic Atom-Variable
                int iNa = 0;
                try
                {
                    String atom = szIniKey.substring(7, szIniKey.indexOf("|"));
                    iNa = Integer.valueOf(atom).intValue();
                }
                catch(Exception e)
                {
                    McpExplorer.LogExc("McpEditor", "replaceJIniValue: GetAtomNumber", "EXC", e);
                    return;
                }
                McpExplorer.LogDebug("No of Atom: " + iNa);
                // Goto korrekt Position in Editor

                String szKey = szIniKey.substring(szIniKey.indexOf("|") + 1);
                String szTxt = this.getDocument().getText(0, getDocument().getLength());
	            Scanner scan = new Scanner(szTxt);
	            scan.useDelimiter("\n");
	            int iDocPos = 0;
	            while (scan.hasNext()) 
	            {
	                String s = scan.next();
	                int iPos = s.indexOf("**************");
	                if(iPos >= 0)
	                {
	                    --iNa;
	                }
	                if(iNa == 0)
	                {	                    	                    
	                    iPos = s.indexOf(szKey);
//	                    McpExplorer.LogDebug("Found: " + szKey);
		                while(isValidKeyPos(s, szKey, iPos))
		                {         
		                    int iPosStartValue = GetStartPosValue(s, iPos + szKey.length());
		                    int iLen = GetLenValue(s, iPosStartValue, iFormat, false);
		                    
		                    if (iLen > 0)
		                    {
		                        this.getDocument().remove(iDocPos + iPosStartValue, iLen);                        
		                    }		                                
		                    this.getDocument().insertString(iDocPos +iPosStartValue, szValue, null);
		                    iPos = s.indexOf(szKey, iPos+1);
		                }
	                }
	                iDocPos += s.length() + 1;
	            }
	            scan.close();
	            scan = null;
                
            }
        }
        catch(Exception ex)
        {
            McpExplorer.LogExc("McpEditor", "replaceJIniValue", "EXC", ex);
        }

        this.revalidate();
    }
    
    private void replaceWinIniValue(String szIniKey, String szValue, int iFormat)
    {
        //System.out.println("Value-Changed: '" + szIniKey + "'\t'" + szOldValue + "' -> '" + szNewValue + "'");
        McpExplorer.LogDebug("REPLACE (WIN-INI): " + szIniKey + " WITH '" + szValue + "' - Format: " + iFormat);
        boolean bFound = false;
        try
        {
            String szTxt = this.getDocument().getText(0, getDocument().getLength());
//            StringBuffer szNewTxt = new StringBuffer();
            Scanner scan = new Scanner(szTxt);
            scan.useDelimiter("\n");
            int iDocPos = 0;
            while (scan.hasNext()) 
            {
                String s = scan.next();
                if(szIniKey.equalsIgnoreCase("FILETYPE")
                        ||szIniKey.equalsIgnoreCase("MODULENAME"))
                {
                    this.getDocument().remove(0, s.length());
                    this.getDocument().insertString(0, "#!" + szValue, null);
                    bFound = true;
                    break;
                }
                else
                {
	                int iPos = s.indexOf(szIniKey);
	                while(!s.trim().startsWith("#") && isValidKeyPos(s, szIniKey, iPos))
	                {         
	                    int iPosStartValue = GetStartPosValue(s, iPos + szIniKey.length());
	                    int iLen = GetLenValue(s, iPosStartValue, iFormat, (szIniKey.equalsIgnoreCase("params") || szIniKey.equalsIgnoreCase("paramnames")));
	                    
	                    if (iLen > 0)
	                    {
	                        this.getDocument().remove(iDocPos + iPosStartValue, iLen);                        
	                    }		                                
	                    this.getDocument().insertString(iDocPos +iPosStartValue, szValue, null);
	                    bFound = true;
	                    iPos = s.indexOf(szIniKey, iPos+1);
	                }
	                iDocPos += s.length() + 1;
                }
            }                
            scan.close();
            scan = null;
            if(!bFound)
            {
                this.getDocument().insertString(this.getDocument().getLength(), "\n" + szIniKey + "=" + szValue, null);                
            }
        }
        catch(Exception ex)
        {
            McpExplorer.LogExc("McpEditor", "replaceWinIniValue", "EXC", ex);
        }
        this.revalidate();
    }
    
    public void replaceIniValue(String szIniKey, String szValue, String szIniType, int iFormat)
    {
        McpExplorer.LogDebug("ReplaceIniValue '" + szIniKey + "' with '" + szValue + "' INI-Type: " + szIniType);
        if(szIniType.equalsIgnoreCase("win"))
        {
            replaceWinIniValue(szIniKey, szValue, iFormat);
        }                
        else if(szIniType.equalsIgnoreCase("j"))
        {
            replaceJIniValue(szIniKey, szValue, iFormat);
        }                
        else
        {
            // do nothing
        }
    }
    
}
