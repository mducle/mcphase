 /*
 * Created on 25.04.2005
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package org.mcphase;

import java.awt.Container;
import java.awt.Frame;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.net.URL;
import java.util.Locale;
import java.util.MissingResourceException;
import java.util.ResourceBundle;
import java.util.StringTokenizer;
import java.util.Vector;

import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JDialog;
import javax.swing.JPanel;

/**
 * @author Stefan
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
public class McpPreferences extends JDialog
{
    static final long serialVersionUID = 7408773911785387494L;
    
    private static ResourceBundle resources;
    
    private JPanel pan;
    
    static 
    {
        try 
        {
            resources = ResourceBundle.getBundle("org.mcphase.resources.McpPreferences", Locale.getDefault());
        } 
        catch (MissingResourceException mre) 
        {
            System.err.println("org/mcphase/resources/McpExlorer.properties not found");
            System.exit(1);
        }
    }


    public McpPreferences(Frame f)
    {
        super(f, "Preferences", true);
        pan = new JPanel();
        String szPrefs = getResourceString("prefs");
        createElements(szPrefs);

        JPanel p = new JPanel();
        JButton btn = new JButton("OK");
        btn.addActionListener(new ActionListener()
                {
            		public void actionPerformed(ActionEvent ev)
            		{
            	        for (Container p = pan.getParent(); p != null; p = p.getParent()) 
            	        {
            	            if (p instanceof JDialog)             
            	            {
            	                ((JDialog)p).dispose();
            	            }
            	        }
            		}
                });
        p.add(btn);
        pan.add(p);
        this.getContentPane().add(pan);
        this.setVisible(true);
    }
    
    private void createElements(String s)
    {
        String[] elements = tokenize(s);
        pan.setLayout(new GridLayout(elements.length + 1, 1));
        this.setBounds(312, 184, 270, (elements.length + 1) * 50);        
        for(int i = 0; i < elements.length; ++i)
        {
            createElement(elements[i]);
        }
    }
    
    private void createElement(String s)
    {
        String szType = getResourceString(s + "Type");
        if(szType.equalsIgnoreCase("boolean"))
        {
            createCheckbox(s);
        }
    }
    
    private void createCheckbox(String s)
    {
        String szLabel = getResourceString(s + "Label");
        boolean bDefault = getResourceString(s + "Default").equalsIgnoreCase("true");
        final JCheckBox chk = new JCheckBox(szLabel);
        final String key = s;
        boolean val = McpExplorer.userPrefs.getBoolean(s, bDefault);
        chk.setSelected(val);
        chk.addActionListener(new ActionListener()
                {
            		public void actionPerformed(ActionEvent ev)
            		{
            		    McpExplorer.userPrefs.putBoolean(key, chk.isSelected());
            		}
                });
        
        pan.add(chk);
    }
    
    protected String getResourceString(String nm) 
    {
    	String str;
    	try 
    	{
    	    str = resources.getString(nm);
    	}
    	catch (MissingResourceException mre) 
    	{
    	    str = null;
    	}
    	return str;
    }

   
    protected URL getResource(String key) 
    {
    	String name = getResourceString(key);
    	if (name != null) 
    	{
    	    URL url = this.getClass().getResource(name);
    	    return url;
    	}
    	return null;      
    }

    protected String[] tokenize(String input) 
    {
        Vector v = new Vector();
        StringTokenizer t = new StringTokenizer(input);
        String cmd[];

        while (t.hasMoreTokens())
        {
            v.addElement(t.nextToken());
        }
        cmd = new String[v.size()];
        for (int i = 0; i < cmd.length; i++)
	    {
            cmd[i] = (String) v.elementAt(i);
	    }

        return cmd;
    }

    
}
