package org.mcphase.display;

import java.awt.Graphics;
import java.awt.Image;
import java.awt.MediaTracker;
import java.awt.Toolkit;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

import javax.swing.JFrame;

public class McpViewer extends JFrame 
{
	private Image image;
	
	public McpViewer(String fileName)
	{
		Toolkit toolkit = Toolkit.getDefaultToolkit();
		image = toolkit.getImage(fileName);
		MediaTracker mediaTracker = new MediaTracker(this);
		mediaTracker.addImage(image, 0);
		try
		{
			mediaTracker.waitForID(0);
		}
		catch (InterruptedException ie)
		{
			this.setVisible(false);
			System.err.println(ie);
		}
		addWindowListener(new WindowAdapter() {
      		public void windowClosing(WindowEvent e) {
    			setVisible(false);
      		}
		});
		setSize(image.getWidth(null), image.getHeight(null));
		setTitle(fileName);
		setVisible(true);
	}

	public void paint(Graphics graphics) 
	{
		graphics.drawImage(image, 0, 0, null);
	}


}
