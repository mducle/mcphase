/*
 * Created on 28.01.2005
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package org.mcphase;

import java.awt.Font;

import javax.swing.BorderFactory;
import javax.swing.JCheckBox;

/**
 * @author Stefan
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
public class McpCheckBox extends JCheckBox
{
    static final long serialVersionUID = 908778157140030570L;
    
    private String m_IniKey;
    private String m_Value;
    private String m_ValueChecked;
    private String m_ValueUnchecked;
    private String m_Label;
    private String m_ToolTip;
    private boolean m_bBold;
    
    private String m_DefaultValue;
    
    public McpCheckBox(String szIniKey, String szValue, String szValueChecked, String szValueUnchecked, String szLabel, String szToolTip, String szBold)
    {
        if(szIniKey != null)
        {
            m_IniKey = szIniKey;
        }
        m_Value = szValue;
        m_DefaultValue = szValue;
        m_ValueChecked = szValueChecked;
        m_ValueUnchecked = szValueUnchecked;
        m_Label = szLabel;
        m_ToolTip = szToolTip;
        if(szBold != null)
        {
            if (szBold.equals("0"))
            {
                m_bBold = false;
            }
            else
            {
                m_bBold = true;
            }
        }
        Init();
    }
    
    private void Init()
    {
        this.setText(m_Label);
        this.setName(m_IniKey);
        this.setBorder(BorderFactory.createEmptyBorder(5,5,5,5));
        if(m_Value.equals(m_ValueChecked))
        {
            this.setSelected(true);
        }
        else
        {
            this.setSelected(false);
        }
        this.setToolTipText(m_ToolTip);
        if(m_bBold)
        {
            this.setFont(this.getFont().deriveFont(Font.BOLD));
        }
        
   }
    
   public void setCheckBoxValue(String szValue)
   {
       m_Value = szValue;
       if(m_Value.equals(m_ValueChecked))
       {
           this.setSelected(true);
       }
       else
       {
           this.setSelected(false);
       }       
   }
   
   public String getCheckBoxValue()
   {
       if(this.getSelectedObjects() == null)
       {
           return(m_ValueUnchecked);
       }
       else
       {
           return(m_ValueChecked);
       }
   }

   
   public String getIniKey()
   {
       return(m_IniKey);
   }

   public void setIniKey(String s)
   {
       m_IniKey = s;
   }
   
   public void resetDefaultValue()
   {
       setCheckBoxValue(m_DefaultValue);
   }

}
