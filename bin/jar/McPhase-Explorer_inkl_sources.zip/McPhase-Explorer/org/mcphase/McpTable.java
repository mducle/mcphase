/*
 * Created on 09.04.2005
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package org.mcphase;

import javax.swing.DefaultCellEditor;
import javax.swing.JFormattedTextField;
import javax.swing.JTable;

/**
 * @author Stefan
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
public class McpTable extends JTable
{
    private String szName;
    static final long serialVersionUID = -2531453236549031535L;
    
    public McpTable(McpTableModel x, String Name)
    {
        super(x);       
        this.getTableHeader().setReorderingAllowed(false);
        this.getColumnModel().setColumnSelectionAllowed(true);
        this.setRowSelectionAllowed(true);
        this.setDefaultRenderer(String.class, new McpTableCellRenderer());
        this.setDefaultEditor(String.class, new DefaultCellEditor(new JFormattedTextField(new McpNumberFormatter(x.getFormat()))));
        szName = Name;
    }
    
    public String getTableContent()
    {
        int iCol = this.getModel().getColumnCount();
        int iRow = this.getModel().getRowCount();
        StringBuffer s = new StringBuffer();
        for(int r = 0; r < iRow; ++r)
        {
            for(int c = 0; c < iCol; ++c)
            {
                s.append(this.getModel().getValueAt(r, c).toString()).append("\t");
            }
            s.append("\n");
        }
        return(s.toString());
    }
    
    public String getName()
    {
        return(szName);
    }
    
    public void setName(String name)
    {
        szName = name;
    }
    
    public boolean isCellEditable(int r, int c)
    {
        return(true);
    }
    
    public void setValueAt(Object value, int r, int c)
    {
        McpExplorer.LogDebug("R: " + r + ", C: " + c + ", VAL: " + value);
        this.getModel().setValueAt(value, r, c);
    }
}
