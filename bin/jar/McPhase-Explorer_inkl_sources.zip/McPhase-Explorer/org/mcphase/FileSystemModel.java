package org.mcphase;
import java.io.File;
import java.util.HashMap;

import javax.swing.event.TreeModelEvent;
import javax.swing.event.TreeModelListener;
import javax.swing.tree.DefaultTreeModel;
import javax.swing.tree.TreeNode;

/*
 * Created on 14.03.2005
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */

/**
 * @author Stefan
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
public class FileSystemModel extends DefaultTreeModel implements TreeModelListener
{
    static final long serialVersionUID = 4566480825778050459L;
    
    private FileObject root;
    
    public FileSystemModel(FileObject node)
    {
        this(node,false);
    }

    public FileSystemModel(FileObject r, boolean asksAllowsChildren) 
    {
		super(r, asksAllowsChildren);
		root = r;
		if (root != null) 
		{
			root.addTreeModelListener(this);
		}
	}
    
    public int getChildCount( Object parent ) 
    {
        return((FileObject)parent).getChildCount();
    }

    public boolean isLeaf( Object node ) 
    {        
        return !((FileObject)node).isDirectory();
    }

    public Object getRoot() 
    {
        return ( root );
    }

    public void setRoot(TreeNode root) 
    {
		FileObject oldRoot = (FileObject) getRoot();
		if (oldRoot != null) 
		{
			oldRoot.removeTreeModelListener(this);
		}
		super.setRoot(root);
		if (root != null) 
		{
			((FileObject) root).addTreeModelListener(this);
		}
	}

    public synchronized Object getChild( Object parent, int index ) 
    {
        return(((FileObject)parent).getChildAt( index));
    }

	public synchronized void treeNodesChanged(TreeModelEvent e) 
	{
		fireTreeNodesChanged(e.getSource(), e.getPath(), e.getChildIndices(), e
				.getChildren());
	}

	public synchronized void treeNodesInserted(TreeModelEvent e) 
	{
		fireTreeNodesInserted(e.getSource(), e.getPath(), e.getChildIndices(),
				e.getChildren());
	}

	public synchronized void treeNodesRemoved(TreeModelEvent e) 
	{
		fireTreeNodesRemoved(e.getSource(), e.getPath(), e.getChildIndices(), e.getChildren());
	}

	public synchronized void treeStructureChanged(TreeModelEvent e) 
	{
		fireTreeStructureChanged(e.getSource(), e.getPath(), e.getChildIndices(), e.getChildren());
	}
    
	public synchronized void checkModel()
	{	       
	    checkModel(root);
	}
	
	private synchronized void checkModel(FileObject o)
	{
	    if(o != null)
	    {	        
//	        System.out.println("CHECK: " + o);
	        if((o.isDirectory() && o.isSelected())
	                || (o.getParent() == null))
	        {
//	            System.out.println("CHECK 1");
//	            int iCountMod = o.getChildCount();
	            HashMap map = new HashMap();
		        if (o.isRoot())
		        {
//		            System.out.println("CHECK is Root");
		            File[] dirs = File.listRoots();
		            for (int j = 0; j < dirs.length; ++j)
		            {
		                map.put(dirs[j].getAbsolutePath(), dirs[j].getAbsolutePath());
		            }
		        }
		        else
		        {
//		            System.out.println("CHECK not Root");
		            String[] s = o.getFile().list();		            
		            for (int j = 0; j < s.length; ++j)
		            {
		                map.put(s[j], s[j]);
		            }
		        }
		        
	            if (o.getChildCount() > 0)
	            {
//		            System.out.println("CHECK has Childs");
	                FileObject x = (FileObject)o.getFirstChild();
		            while(x != null)
		            {	 
		                String szName = x.getFile().getName();
		                if(szName.length() == 0)
		                {
		                    szName = x.getFile().getAbsolutePath();
		                }
		                if(map.containsKey(szName))
		                {
		                    map.remove(szName);
		                    if(x.isDirectory())
		                    {
		                        checkModel(x);
		                    }
		                    x = (FileObject)o.getChildAfter((TreeNode)x);
		                }
		                else
		                {
		                    FileObject y = (FileObject)o.getChildAfter(x);
		                    o.remove(x);
		                    x = y;
		                }
		            }
	            }	            
				if(!map.isEmpty())
	            {
	                Object[] obj = map.values().toArray();
	                for (int i = 0; i < obj.length ; ++i)
	                {
	                    o.add( new FileObject(o.getFile() + System.getProperty("file.separator") +  obj[i].toString(), true));
	                }
	            }	            
	        }
	    }
	}
}
