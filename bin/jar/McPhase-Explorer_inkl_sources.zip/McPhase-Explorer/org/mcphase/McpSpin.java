/*
 * Created on 29.09.2005
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package org.mcphase;

/**
 * @author Stefan
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
public class McpSpin
{
    int iNofComps;
    int iNofAtoms;
    int lenVector;
    
    String fVal[];
    
    public McpSpin(int iNumComps,int iNumAtoms)
    {
        iNofComps = iNumComps;
        iNofAtoms = iNumAtoms;
        lenVector = iNofComps * iNofAtoms;
        fVal = new String[lenVector];
        for(int i = 0; i < fVal.length; ++i)
        {
            fVal[i] = "0";
        }
    }
/*    
    public McpSpin(String[] f)
    {
        fVal = f;
        iNofComps = f.length;
    }
*/    
    public String getValAt(int iPos)
    {
        return fVal[iPos];
    }
    
    public void setValAt(int iPos, String val)
    {
        fVal[iPos] = val;
    }
    
    public int getVectLen()
    {
        return(lenVector);
    }
    
    public int getNumAtoms()
    {
        return(iNofAtoms);
    }
    
    public int getNumComps()
    {
        return(iNofComps);
    }
    
    public void addNumAtoms(int iNum)
    {
        iNofAtoms += iNum;
        lenVector = iNofAtoms * iNofComps;
        
        String[] rn = fVal;
        fVal = new String[lenVector];
        if(rn != null)
        {
            System.arraycopy(rn, 0 , fVal, 0, lenVector - (iNum * iNofComps));
        }
        for(int i = 0; i < (iNum * iNofComps); ++i)
        {
            fVal[lenVector - iNum * iNofComps + i] = "0";
        }        
    }

    public void removeNumAtoms(int iNum)
    {
        iNofAtoms -= iNum;
        lenVector = iNofAtoms * iNofComps;
        System.arraycopy(fVal, 0 , fVal, 0, lenVector);        
    }

    public void addNumComps(int iNum)
    {
        iNofComps += iNum;
        lenVector = iNofAtoms * iNofComps;
        
        String[] rn = fVal;
        fVal = new String[lenVector];
        
        if(rn != null)
        {
	        for (int i = 0; i < iNofAtoms; ++i)
	        {
	            for (int j = 0; j < iNofComps; ++j)
	            {
	                if(j >= iNofComps - iNum)
	                {
	                    fVal[i * (iNofComps) + j] = "0";
	                }
	                else
	                {
	                    fVal[i * (iNofComps) + j] = rn[i * (iNofComps - iNum) + j];
	                }
	            }
	        }
        }
    }

    public void removeNumComps(int iNum)
    {
        iNofComps -= iNum;
        lenVector = iNofAtoms * iNofComps;
        
        String[] rn = fVal;
        fVal = new String[lenVector];
        
        if(rn != null)
        {
	        for (int i = 0; i < iNofAtoms; ++i)
	        {
	            for (int j = 0; j < iNofComps; ++j)
	            {
                    fVal[i * (iNofComps) + j] = rn[i * (iNofComps + iNum) + j];
	            }
	        }
        }        
    }

}
