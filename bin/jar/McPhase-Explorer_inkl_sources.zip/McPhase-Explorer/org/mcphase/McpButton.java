/*
 * Created on 09.06.2005
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package org.mcphase;

import javax.swing.Icon;
import javax.swing.JButton;

/**
 * @author Stefan
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
public class McpButton extends JButton
{
    static final long serialVersionUID = 2624967067672577716L;
    
    private String m_IniKey;

    public McpButton(String iniKey, String szLabel, Icon icon, String szToolTip)
    {
        super(szLabel);
        if(icon != null)
        {
            this.setIcon(icon);
        }
        if(szToolTip != null)
        {
            this.setToolTipText(szToolTip);
        }
        m_IniKey = iniKey;
    }

    public String getIniKey()
    {
        return(m_IniKey);
    }

    public void setIniKey(String s)
    {
        m_IniKey = s;
    }
}
