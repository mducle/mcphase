package org.mcphase;
import java.awt.Color;
import java.awt.Component;
import java.net.URL;
import java.util.Locale;
import java.util.MissingResourceException;
import java.util.ResourceBundle;

import javax.swing.Icon;
import javax.swing.ImageIcon;
import javax.swing.JLabel;
import javax.swing.JTree;
import javax.swing.tree.DefaultTreeCellRenderer;
import javax.swing.tree.TreeCellRenderer;

/*
 * Created on 14.03.2005
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */

/**
 * @author Stefan
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
public class FileTreeCellRenderer extends JLabel implements TreeCellRenderer
{
    private static ResourceBundle resources;
//    private final static String iconLeafSuffix = "IconLeaf";
    
    static final long serialVersionUID = 1768172609045535363L;
    
    static 
    {
        try 
        {
            resources = ResourceBundle.getBundle("org.mcphase.resources.FileSystemTree", Locale.getDefault());
        } 
        catch (MissingResourceException mre) 
        {
            System.err.println("org/mcphase/resources/FileSystemTree.properties not found");
            System.exit(1);
        }
    }

//    private Color backColor = new Color(0xFF, 0xCC, 0xFF);
//    private DefaultTreeCellRenderer rend;    
//    private Color DefaultBackColor;
//    private Color DefaultForeColor;
    private Icon DefaultOpenIcon, DefaultClosedIcon, DefaultLeafIcon;
    private String tipText = " ";
    
    public FileTreeCellRenderer()
    {
        DefaultTreeCellRenderer rend = new DefaultTreeCellRenderer();
        DefaultOpenIcon = rend.getDefaultOpenIcon();
        DefaultClosedIcon = rend.getDefaultClosedIcon();
        DefaultLeafIcon = rend.getDefaultLeafIcon();
        setBackground(new Color(0xFF, 0xCC, 0xFF));
        setForeground(Color.black);
    }

    
    public Component getTreeCellRendererComponent(JTree tree, Object value, boolean selected,
            boolean expanded, boolean leaf, int row, boolean hasFocus)
    {
        setText(value.toString());
        
        if (selected)
        {
            setOpaque(true);
        }
        else
        {
            setOpaque(false);
        }
        
        FileObject f = (FileObject)value;
        String tmpFileType = f.GetFileType(); 
        
	    if(expanded)
	    {
	        setIcon(DefaultOpenIcon);            
	    }
        else if (leaf)
        {
            setIcon(DefaultLeafIcon);
        }
	    else
	    {
	        setIcon(DefaultClosedIcon);            
	    }

	    if(f.isDirectory())
        {
            setForeground(Color.blue);
        }
        else
        {
            if(!tmpFileType.equals("default"))
            {
                setIcon(new ImageIcon(getResource(tmpFileType + "IconLeaf")));
                setForeground(Color.red);
            }
            else
            {
                setForeground(Color.black);
            }
        }
        
        return (this);
    }
    
    public String getToolTipText()
    {
        return (tipText);
    }
    protected String getResourceString(String nm) 
    {
    	String str;
    	try 
    	{
    	    str = resources.getString(nm);
    	}
    	catch (MissingResourceException mre) 
    	{
    	    str = null;
    	}
    	return str;
    }

   
    protected URL getResource(String key) 
    {
    	String name = getResourceString(key);
    	if (name != null) 
    	{
    	    URL url = this.getClass().getResource(name);
    	    return url;
    	}
    	return null;      
    }

}
