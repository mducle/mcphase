/*
 * Created on 06.04.2005
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package org.mcphase.forms;

import java.awt.Dimension;
import java.awt.GridBagConstraints;
import java.util.Locale;
import java.util.MissingResourceException;
import java.util.ResourceBundle;
import java.util.Scanner;
import java.util.Vector;

import javax.swing.JScrollPane;
import javax.swing.event.TableModelEvent;
import javax.swing.event.TableModelListener;

import org.mcphase.McpCheckBox;
import org.mcphase.McpComboBox;
import org.mcphase.McpEditor;
import org.mcphase.McpExplorer;
import org.mcphase.McpForm;
import org.mcphase.McpLabel;
import org.mcphase.McpTable;
import org.mcphase.McpTableModel;
import org.mcphase.McpTextField;

/**
 * @author Stefan
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
public class McpSipf extends McpForm
{
    private static ResourceBundle ff;
    static final long serialVersionUID = 4394573700029597496L;
    private final static String[] ffKeys = 
    {
	    "FFj0A",
	    "FFj0a",
	    "FFj0B",
	    "FFj0b",
	    "FFj0C",
	    "FFj0c",
	    "FFj0D",
	    "FFj2A",
	    "FFj2a",
	    "FFj2B",
	    "FFj2b",
	    "FFj2C",
	    "FFj2c",
	    "FFj2D"	
    };

    private final static String[] cfparamFields =
    {
        "B20",
        "B21",
        "B22",
        "B21S",
        "B22S",
        "B40",
        "B41",
        "B42",
        "B43",
        "B44",
        "B41S",
        "B42S",
        "B43S",
        "B44S",
        "B60",
        "B61",
        "B62",
        "B63",
        "B64",
        "B65",
        "B66",
        "B61S",
        "B62S",
        "B63S",
        "B64S",
        "B65S",
        "B66S"       
    };
    private final static String[] cfparamLabels =
    {
        "B20Label",
        "B21Label",
        "B22Label",
        "B21SLabel",
        "B22SLabel",
        "B40Label",
        "B41Label",
        "B42Label",
        "B43Label",
        "B44Label",
        "B41SLabel",
        "B42SLabel",
        "B43SLabel",
        "B44SLabel",
        "B60Label",
        "B61Label",
        "B62Label",
        "B63Label",
        "B64Label",
        "B65Label",
        "B66Label",
        "B61SLabel",
        "B62SLabel",
        "B63SLabel",
        "B64SLabel",
        "B65SLabel",
        "B66SLabel",
        "helpLabel",
        "cfHeaderLabel"
    };
    
    private JScrollPane jspTable;
    
    static 
    {
        try 
        {
            resources = ResourceBundle.getBundle("org.mcphase.resources.forms.Sipf", Locale.getDefault());
        } 
        catch (MissingResourceException mre) 
        {
            System.err.println("org/mcphase/resources/forms/Sipf not found");
            System.exit(1);
        }

        try 
        {
            ff = ResourceBundle.getBundle("org.mcphase.resources.Formfactors", Locale.getDefault());
        } 
        catch (MissingResourceException mre) 
        {
            System.err.println("org/mcphase/resources/Formfactors not found");
            System.exit(1);
        }
    }

    public McpSipf(McpEditor ed)
    {
        super(ed);
    }

    public void initFromString(String szSource)
    {
        String szParamNames = "";
        String szParamValues = "";
        String szFileType = "";
        int iLine = 0;
        mapValues.clear();
        Object ob[] = mapKeys.keySet().toArray();

        for(int i = 0; i < ob.length; ++i)
        {
            mapValues.put(ob[i], "");
        }
        mapTables.clear();
        if(jspTable != null)
        {
            this.remove(jspTable);
        }
        //clearControls();
        
        Scanner scan = new Scanner(szSource);
        scan.useDelimiter("\n");        
        while (scan.hasNext()) 
        {
            String s = scan.next().trim();
            if (iLine == 0)
            {
                // Read the first-Line for filetype
                if(s.startsWith("#!"))
                {
                    String szKey = "FILETYPE";
                    String szValue = s.substring(2).trim();
                    
                    String szKeyMod = "MODULENAME";
                    String szValueMod ="";
                    if (!szValue.equalsIgnoreCase("kramer") && !szValue.equalsIgnoreCase("cfield"))
                    {
                        szValueMod = szValue;
                        szValue = "external module";
                    }
                    
                    szFileType = szValue;
                    
                    Object o = mapKeys.get(szKey);
                    if(mapValues.containsKey(szKey))
                    {
                        mapValues.remove(szKey);
                    }
                    if (o != null)
                    {
                        if(o instanceof McpTextField)
                        {
                            ((McpTextField)o).setText(szValue);
                            mapValues.put(szKey, szValue);
                        }
                        else if(o instanceof McpCheckBox)
                        {
                            ((McpCheckBox)o).setCheckBoxValue(szValue);
                            mapValues.put(szKey, szValue);
                        }
                        else if(o instanceof McpComboBox)
                        {
                            ((McpComboBox)o).setComboBoxValue(szValue);
                            mapValues.put(szKey, szValue);
                        }
                        else
                        {
                            System.out.println("KEY: '" + szKey + "'\tVALUE: '" + szValue + "'\t Unkown");                                                    
                        }
                    }
                    else
                    {
                        System.out.println("Key '" + szKey + "' not found");
                    }
                    
                    Object oMod = mapKeys.get(szKeyMod);
                    if (oMod != null)
                    {
                        if(oMod instanceof McpTextField)
                        {
                            ((McpTextField)oMod).setText(szValueMod);
                            mapValues.put(szKeyMod, szValueMod);
                        }
                        else if(oMod instanceof McpCheckBox)
                        {
                            ((McpCheckBox)oMod).setCheckBoxValue(szValueMod);
                            mapValues.put(szKeyMod, szValueMod);
                        }
                        else if(oMod instanceof McpComboBox)
                        {
                            ((McpComboBox)oMod).setComboBoxValue(szValueMod);
                            mapValues.put(szKeyMod, szValueMod);
                        }
                        else
                        {
                            System.out.println("KEY: '" + szKeyMod + "'\tVALUE: '" + szValueMod + "'\t Unkown");                                                    
                        }
                    }
                    else
                    {
                        System.out.println("Key '" + szKeyMod + "' not found");
                    }

                }
            }
            else
            {
	            if(!s.startsWith("#"))
	            {
	                if(s.startsWith("paramnames"))
	                {
	                    szParamNames = s.substring(11);
	                }
	                else if(s.startsWith("params"))
	                {
	                    szParamValues = s.substring(7);
	                }
	                else
	                {	                   
		                Object[] o = mapKeys.values().toArray();                    
		                for (int i = 0; i < o.length; ++i)
		                {
		                    String szKey = "";
		                    int iFormat = McpEditor.FORMAT_FLOAT;
		                    if(o[i] instanceof McpTextField)
		                    {
		                        szKey = ((McpTextField)o[i]).getIniKey();
		                        iFormat = ((McpTextField)o[i]).getFormat();
		                    }
		                    else if(o[i] instanceof McpCheckBox)
		                    {
		                        szKey = ((McpCheckBox)o[i]).getIniKey();
		                        iFormat = McpEditor.FORMAT_INTEGER;
		                    }
		                    else if(o[i] instanceof McpComboBox)
		                    {
		                        szKey = ((McpComboBox)o[i]).getIniKey();
		                        iFormat = ((McpComboBox)o[i]).getFormat();
		                    }
		                    else
		                    {
		                        
		                    }
		                    if(szKey.length() > 0)
		                    {
		                        String szValue = extract(s, szKey, iFormat);
		                        if(szValue.length() > 0)
		                        {
		                            if(o[i] instanceof McpTextField)
		                            {
		                                ((McpTextField)o[i]).setText(szValue);
		                                mapValues.put(szKey, szValue);
		                            }
		                            else if(o[i] instanceof McpCheckBox)
		                            {
		                                ((McpCheckBox)o[i]).setCheckBoxValue(szValue);
		                                mapValues.put(szKey, szValue);
		                            }
			                        else if(o[i] instanceof McpComboBox)
			                        {
			                            ((McpComboBox)o[i]).setComboBoxValue(szValue);
			                            mapValues.put(szKey, szValue);
			                        }
		                            else
		                            {
		                                System.out.println("Line " + i + ": " + s + "\tKEY: '" + szKey + "'\tVALUE: '" + szValue + "'\t Unkown");                                                    
		                            }                            
		                        }
		                    }
		                }
	                }
	            }
            }
            ++iLine;
        }
        scan.close();
        scan = null;
        McpExplorer.LogInfo("Paramnames: " + szParamNames);
        McpExplorer.LogInfo("Paramvalues: " + szParamValues);
        Vector v = getParamData(szParamNames, szParamValues);
        if(v == null)
        {
            v = new Vector();
        }
        if(v.size() == 0)
        {
            String[] tmp = new String[2];
            tmp[0] = "";
            tmp[1] = "";
            v.add(tmp);
        }
        McpTableModel m = new McpTableModel(v, "Text");

        String h[] = new String[2];
        h[0] = "Parameter";
        h[1] = "Value";
        m.setHeader(h);
        
        McpTable table = new McpTable(m, "Params");
        table.setPreferredScrollableViewportSize(new Dimension(50,100));
        table.getModel().addTableModelListener(new TableListener(table));
        jspTable = new JScrollPane(table);        
        mapTables.put("Params", table);
        try
        {
            this.addComponent(jspTable, this, 1, 13, 6, 1, GridBagConstraints.BOTH, GridBagConstraints.CENTER);
        }
        catch(Exception ex)
        {
            
        }
        checkVisibility(szFileType);        
        this.revalidate();
    }

    protected void FieldChanged(String Key, String valueOld, String valueNew)
    {
        McpExplorer.LogDebug("FieldChange: " + Key + " :'" + valueOld + "' -> '" + valueNew + "'");
        if(Key.equalsIgnoreCase("IONTYPE") && !valueOld.equals(valueNew))
        {
            FillFormFactors(valueNew);
        }
        if(Key.equalsIgnoreCase("FILETYPE"))
        {
            checkVisibility(valueNew);
            if(valueNew.equalsIgnoreCase("external module"))
            {
                edit.replaceIniValue("FILETYPE", mapValues.get("MODULENAME").toString(), "win", McpEditor.FORMAT_TEXT);
            }
        }
        if(Key.equalsIgnoreCase("MODULENAME"))
        {
            edit.replaceIniValue("FILETYPE", valueNew, "win", McpEditor.FORMAT_TEXT);
        }
        McpExplorer.bDocumentChanged = true;
    }
    
    private void FillFormFactors(String value)
    {
        for(int i=0; i < ffKeys.length; ++i)
        {
            McpTextField tf = (McpTextField)this.mapKeys.get(ffKeys[i]);
            String szValue = GetFormFactor(value + ffKeys[i]);
            tf.setValue(szValue);
        }
    }

    private String GetFormFactor(String key)
    {
    	String str;
    	try 
    	{
    	    str = ff.getString(key);
    	}
    	catch (MissingResourceException mre) 
    	{
    	    str = null;
    	}
    	return str;
      
        
    }
    
    private void checkVisibility(String type)
    {
        if(type.equalsIgnoreCase("external module"))
        {
            setCFieldParamsVisible(false);
            setParamTableVisible(true);
            setModuleNameVisible(true);
        }
        else if(type.equalsIgnoreCase("kramer"))
        {
            setCFieldParamsVisible(false);
            setParamTableVisible(true);
            setModuleNameVisible(false);
        }
        else if(type.equalsIgnoreCase("cfield"))
        {
            setCFieldParamsVisible(true);
            setParamTableVisible(false);
            setModuleNameVisible(false);
        }
        else
        {
            // Do nothing
        }
        this.revalidate();
    }
    
    private Vector getParamData(String szNames, String szValues)
    {
        String[] n = this.tokenize(szNames);
        String[] v = this.tokenize(szValues);
        if(n.length != v.length)
        {
            return null;            
        }
        Vector ret = new Vector(); 
        for(int i = 0; i < n.length; ++i)
        {
            String[] tmp = new String[2];
            tmp[0] = n[i];
            tmp[1] = v[i];
            ret.add(tmp);
        }
        return(ret);
    }
    
    private void setCFieldParamsVisible(boolean vis)
    {
        for(int i=0; i < McpSipf.cfparamFields.length; ++i)
        {
            McpTextField tf = (McpTextField)mapKeys.get(McpSipf.cfparamFields[i]);
            tf.setVisible(vis);
        }
        for(int i=0; i < McpSipf.cfparamLabels.length; ++i)
        {
            McpLabel l = (McpLabel)mapKeys.get(McpSipf.cfparamLabels[i]);
            l.setVisible(vis);
        }
    }
    
    private void setParamTableVisible(boolean vis)
    {
        McpTable t = (McpTable)mapTables.get("Params");
        if(t != null)
        {
            t.setVisible(vis);
        }
        if(jspTable != null)
        {
            jspTable.setVisible(vis);
        }
        McpLabel l = (McpLabel)mapKeys.get("paramLabel");
        if(l != null)
        {
            l.setVisible(vis);
        }
    }
    
    private void setModuleNameVisible(boolean vis)
    {
        ((McpTextField)mapKeys.get("MODULENAME")).setVisible(vis);
    }
    
    private class TableListener implements TableModelListener
    {
        McpTable t;
        
        TableListener(McpTable tab) 
        {
            super();
            this.t = tab;
        }
        
        public void tableChanged(TableModelEvent e) 
        {     
            McpExplorer.LogDebug("SIPF-TABLE Changed !\n" + ((McpTableModel)t.getModel()).getDataAsFileTable());
            String s [][] = ((McpTableModel)t.getModel()).getDataAsStringArray();
            StringBuffer newParam = new StringBuffer();
            StringBuffer newParamVal = new StringBuffer();
            
            for(int r = 0; r < ((McpTableModel)t.getModel()).getRowCount(); ++r)
            {
                newParam.append(s[r][0]);
                newParamVal.append(s[r][1]);
                if((r + 1) < ((McpTableModel)t.getModel()).getRowCount())             
                {
                    newParam.append(" ");
                    newParamVal.append(" ");
                }                
            }
            edit.replaceIniValue("paramnames", newParam.toString(), "win", McpEditor.FORMAT_TEXT);
            edit.replaceIniValue("params", newParamVal.toString(), "win", McpEditor.FORMAT_TEXT);
        }
    }    
}

