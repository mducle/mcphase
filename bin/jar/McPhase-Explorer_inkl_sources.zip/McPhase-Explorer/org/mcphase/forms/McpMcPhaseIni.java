/*
 * Created on 04.02.2005
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package org.mcphase.forms;

import java.awt.Color;
import java.util.Locale;
import java.util.MissingResourceException;
import java.util.ResourceBundle;
import java.util.Scanner;

import org.mcphase.McpCheckBox;
import org.mcphase.McpEditor;
import org.mcphase.McpExplorer;
import org.mcphase.McpForm;
import org.mcphase.McpTextField;

/**
 * @author Stefan
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
public class McpMcPhaseIni extends McpForm
{
    static final long serialVersionUID = -8114419985641470503L;
    
    static 
    {
        try 
        {
            resources = ResourceBundle.getBundle("org.mcphase.resources.forms.McPhaseIni", Locale.getDefault());
        } 
        catch (MissingResourceException mre) 
        {
            System.err.println("org/mcphase/resources/forms/McPhaseIni not found");
            System.exit(1);
        }
    }

    public McpMcPhaseIni(McpEditor ed)
    {
        super(ed);
    }

    public void initFromString(String szSource)
    {
        Scanner scan = new Scanner(szSource);
        mapValues.clear();
        scan.useDelimiter("\n");
        while (scan.hasNext()) 
        {
            String s = scan.next().trim();
            if(!s.startsWith("#"))
            {
                int i = s.indexOf("="); 
                if(i > 0)
                {
                    String szKey = s.substring(0, i).trim();
                    String szValue = s.substring(i+1).trim();
                    Object o = mapKeys.get(szKey);
                    if (o != null)
                    {
                        if(o instanceof McpTextField)
                        {
                            ((McpTextField)o).setText(szValue);
                            mapValues.put(szKey, szValue);
                        }
                        else if(o instanceof McpCheckBox)
                        {
                            ((McpCheckBox)o).setCheckBoxValue(szValue);
                            mapValues.put(szKey, szValue);
                        }
                        else
                        {
                            System.out.println("Line " + i + ": " + s + "\tKEY: '" + szKey + "'\tVALUE: '" + szValue + "'\t Unkown");                                                    
                        }
                    }
                    else
                    {
                        System.out.println("Key '" + szKey + "' not found");
                    }
                }
            }
        }
        scan.close();
        scan = null;
        this.repaint();
    }
    
    protected void FieldChanged(String Key, String valueOld, String valueNew)
    {
        if(Key.endsWith("min") ||Key.endsWith("max"))
        {
	        String KeyMin = "";
	        String KeyMax = "";
	        double min = 0;
	        double max = 0;
	        if(Key.endsWith("min"))
	        {
	            KeyMax = Key.substring(0, Key.length() - 3) + "max";
	            KeyMin = Key;
	            String valueOpposite = mapValues.get(KeyMax).toString();
	            min = Double.valueOf(valueNew).doubleValue();
	            max = Double.valueOf(valueOpposite).doubleValue();
	        }
	        
	        if(Key.endsWith("max"))
	        {
	            KeyMin = Key.substring(0, Key.length() - 3) + "min";
	            KeyMax = Key;
	            String valueOpposite = mapValues.get(KeyMin).toString();
	            max = Double.valueOf(valueNew).doubleValue();
	            min = Double.valueOf(valueOpposite).doubleValue();
	        }
            McpTextField tfMin = (McpTextField)mapKeys.get(KeyMin);
            McpTextField tfMax = (McpTextField)mapKeys.get(KeyMax);
	        if(max < min)
	        {
	            // Nicht OK !!!
	            tfMin.setBackground(Color.RED);
	            tfMax.setBackground(Color.RED);
	        }
	        else
	        {
	            // OK !!!
	            tfMin.setBackground(Color.WHITE);
	            tfMax.setBackground(Color.WHITE);
	        }
        }
        McpExplorer.bDocumentChanged = true;
    }
}
