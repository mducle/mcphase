/*
 * Created on 06.04.2005
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package org.mcphase.forms;

import java.awt.GridBagConstraints;
import java.util.Locale;
import java.util.MissingResourceException;
import java.util.ResourceBundle;
import java.util.Scanner;
import java.util.Vector;

import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTabbedPane;
import javax.swing.event.TableModelEvent;
import javax.swing.event.TableModelListener;

import org.mcphase.McpButton;
import org.mcphase.McpCheckBox;
import org.mcphase.McpComboBox;
import org.mcphase.McpEditor;
import org.mcphase.McpExplorer;
import org.mcphase.McpFileInput;
import org.mcphase.McpForm;
import org.mcphase.McpTable;
import org.mcphase.McpTableModel;
import org.mcphase.McpTextField;

/**
 * @author Stefan
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
public class McpMcphasJ extends McpForm
{
    protected static ResourceBundle m_resources;
    static final long serialVersionUID = -5018756844070163403L;
    
    static 
    {
        try 
        {
            m_resources = ResourceBundle.getBundle("org.mcphase.resources.forms.McPhasJ", Locale.getDefault());
            resources = ResourceBundle.getBundle("org.mcphase.resources.forms.McPhasJ", Locale.getDefault());
        } 
        catch (MissingResourceException mre) 
        {
            System.err.println("org/mcphase/resources/forms/McPhaseJ not found");
            System.exit(1);
        }
    }

//    private JTabbedPane tablePane;
    private int iNumAtoms = 0;
    private int iNumColumns = 0;
    
    
    public McpMcphasJ(McpEditor ed)
    {
        super(ed);
        szType = "j";
        for(int i = 0; i < this.getComponentCount(); ++i)
        {
            if(this.getComponent(i) instanceof JTabbedPane)
            {
//                tablePane = (JTabbedPane)this.getComponent(i);
            }
        }
    }
    
    
    
    public void initFromString(String szSource)
    {
        super.RemoveAllDynTabPanels("tab1");
        mapTables.clear();
        int iPart = 0;
        int iActivePart = 0;
        boolean bGotVars = false;
        String var_x = "";
        String var_y = "";
        String var_z = "";
        String non = "";
        String dex = "";
        String gJ = "";
        String cffile = "";
        
        
        
        iNumAtoms = 0;
        Scanner scan = new Scanner(szSource);
        mapValues.clear();
        
        scan.useDelimiter("\n");
        Vector tab = new Vector();
        while (scan.hasNext()) 
        {
            String s = scan.next().trim();
            if(s.indexOf("*******") > 0)
            {
                ++iPart;
            }
            if(iPart == 0)
            {
                //McpExplorer.LogDebug("FIRST PART: " + iPart);
                Object[] o = mapKeys.values().toArray();                    
                for (int i = 0; i < o.length; ++i)
                {
                    String szKey = "";
                    int iFormat = McpEditor.FORMAT_FLOAT;
                    if(o[i] instanceof McpTextField)
                    {
                        szKey = ((McpTextField)o[i]).getIniKey();
                        iFormat = ((McpTextField)o[i]).getFormat();
                    }
                    else if(o[i] instanceof McpCheckBox)
                    {
                        szKey = ((McpCheckBox)o[i]).getIniKey();
                        iFormat = McpEditor.FORMAT_INTEGER;
                    }
                    else if(o[i] instanceof McpComboBox)
                    {
                        szKey = ((McpComboBox)o[i]).getIniKey();
                        iFormat = ((McpComboBox)o[i]).getFormat();
                    }
                    else
                    {
                        
                    }
                    if(szKey.length() > 0)
                    {
                        String szValue = extract(s, szKey, iFormat);
                        if(szValue.length() > 0)
                        {
                            if(o[i] instanceof McpTextField)
                            {
                                ((McpTextField)o[i]).setText(szValue);
                                mapValues.put(szKey, szValue);
                            }
                            else if(o[i] instanceof McpCheckBox)
                            {
                                ((McpCheckBox)o[i]).setCheckBoxValue(szValue);
                                mapValues.put(szKey, szValue);
                            }
	                        else if(o[i] instanceof McpComboBox)
	                        {
	                            ((McpComboBox)o[i]).setComboBoxValue(szValue);
	                            mapValues.put(szKey, szValue);
	                        }
                            else
                            {
                                McpExplorer.LogError("Line " + i + ": " + s + "\tKEY: '" + szKey + "'\tVALUE: '" + szValue + "'\t Unkown");                                                    
                            }                            
                        }
                    }
                }
            }
            else
            // We reached the 1:n Part of the file
            {
                //McpExplorer.LogDebug("1:n PART: " + iPart);
                if (iActivePart != iPart)
                {
                    iActivePart = iPart;
                    McpExplorer.LogDebug("NEW PART: " + iPart);
                    bGotVars = false;
                    if(tab != null && !tab.isEmpty())
                    {
	                    McpTable table = new McpTable(new McpTableModel(tab, "Float"), "");
	                    JScrollPane jsp = new JScrollPane(table);
	                    try
	                    {
	                        if (iPart >= 2)
	                        {
	                            iNumAtoms = iPart - 1;
	                            // Create new Tab
	                            String szName = "tab1Pan" + String.valueOf(iPart - 1) + "|";
	                            String szLabel = "Magnetic Atom " + String.valueOf(iPart - 1);
	                            McpExplorer.LogDebug("AddDynTabPanel: " + szName + ", " + szLabel);
	                            super.AddDynTabPanel("tab1", szName, szLabel, "tab1Pan1", m_resources);
	                            // Fill In Header-Values
	                            ((McpTextField)mapKeys.get(szName + "x")).setText(var_x);
	                            mapValues.put(szName + "x", var_x);
	                            
	                            ((McpTextField)mapKeys.get(szName + "y")).setText(var_y);
	                            mapValues.put(szName + "y", var_y);

	                            ((McpTextField)mapKeys.get(szName + "z")).setText(var_z);
	                            mapValues.put(szName + "z", var_z);

	                            ((McpTextField)mapKeys.get(szName + "nofneighbours")).setText(non);
	                            mapValues.put(szName + "nofneighbours", non);

	                            ((McpCheckBox)mapKeys.get(szName + "diagonalexchange")).setCheckBoxValue(dex);
	                            mapValues.put(szName + "diagonalexchange", dex);
	                            
	                            ((McpTextField)mapKeys.get(szName + "gJ")).setText(gJ);
	                            mapValues.put(szName + "gJ", gJ);

	                            ((McpFileInput)mapKeys.get(szName + "cffilename")).setValue(cffile);
	                            mapValues.put(szName + "cffilename", cffile);
	                            
	                            table.setName(szName);
	                            table.getModel().addTableModelListener(new TableListener(table));
	    	                    mapTables.put(szName, table);

	    	                    this.addComponent(jsp, (JPanel)mapTabs.get(szName), 0, 3, 6, 1, GridBagConstraints.BOTH, GridBagConstraints.CENTER);
	                        }
	                    }
	                    catch(Exception ex)
	                    {
	                        
	                    }
                    }	                            
                    tab = new Vector();
                }
                if(s.trim().startsWith("#"))
                {
                    if(tab.isEmpty() && bGotVars == false && s.indexOf("*******") <= 0)
                    {
                        //McpExplorer.LogDebug(s);
                        //x=   0 [a] y=   0 [b] z=   0 [c] nofneighbours=1412 diagonalexchange=1 gJ=0.727273 cffilename=mcphas.cf1
                        
                        var_x = extract(s, "x", McpEditor.FORMAT_INTEGER);
                        var_y = extract(s, "y", McpEditor.FORMAT_INTEGER);
                        var_z = extract(s, "z", McpEditor.FORMAT_INTEGER);
                        non = extract(s, "nofneighbours", McpEditor.FORMAT_INTEGER);
                        dex = extract(s, "diagonalexchange", McpEditor.FORMAT_INTEGER);
                        gJ = extract(s, "gJ", McpEditor.FORMAT_FLOAT);
                        cffile = extract(s, "cffilename", McpEditor.FORMAT_TEXT);
                        
                        bGotVars = true;
                    }
                    //System.out.println("KOMMENTAR: " + s);
                }
                else if (s.trim().length() > 0)
                {
                    String x[] = tokenize(s);
                    iNumColumns = x.length;
                    tab.add(x);
                }
            }
        }

        if(tab != null && !tab.isEmpty())
        {
            McpTable table = new McpTable(new McpTableModel(tab, "Float"), "");
            JScrollPane jsp = new JScrollPane(table);
            try
            {
                if (iPart >= 1)
                {
                    iNumAtoms = iPart;
                    // Create new Tab
                    String szName = "tab1Pan" + String.valueOf(iPart) + "|";
                    String szLabel = "Magnetic Atom " + String.valueOf(iPart);
                    McpExplorer.LogDebug("AddDynTabPanel: " + szName + ", " + szLabel);
                    super.AddDynTabPanel("tab1", szName, szLabel, "tab1Pan1", m_resources);
                    // Fill In Header-Values
                    ((McpTextField)mapKeys.get(szName + "x")).setText(var_x);
                    mapValues.put(szName + "x", var_x);
                    
                    ((McpTextField)mapKeys.get(szName + "y")).setText(var_y);
                    mapValues.put(szName + "y", var_y);

                    ((McpTextField)mapKeys.get(szName + "z")).setText(var_z);
                    mapValues.put(szName + "z", var_z);

                    ((McpTextField)mapKeys.get(szName + "nofneighbours")).setText(non);
                    mapValues.put(szName + "nofneighbours", non);

                    ((McpCheckBox)mapKeys.get(szName + "diagonalexchange")).setCheckBoxValue(dex);
                    mapValues.put(szName + "diagonalexchange", dex);
                    
                    ((McpTextField)mapKeys.get(szName + "gJ")).setText(gJ);
                    mapValues.put(szName + "gJ", gJ);

                    ((McpFileInput)mapKeys.get(szName + "cffilename")).setValue(cffile);
                    mapValues.put(szName + "cffilename", cffile);

                    table.setName(szName);
                    table.getModel().addTableModelListener(new TableListener(table));
                    mapTables.put(szName, table);
                    
                    this.addComponent(jsp, (JPanel)mapTabs.get(szName), 0, 3, 6, 1, GridBagConstraints.BOTH, GridBagConstraints.CENTER);
                }
            }
            catch(Exception ex)
            {
                
            }
        }	                            

        
        scan.close();
        scan = null;
        this.repaint();
    }

    
    protected void FieldChanged(String Key, String valueOld, String valueNew)
    {
        McpExplorer.LogDebug("FieldChange: " + Key + " from '" + valueOld + "' to '" + valueNew + "'");
        if(Key.equalsIgnoreCase("addAtomBtn"))
        {
            McpExplorer.LogDebug("Add Atom");
            AddAtom();
        }
        else if(Key.equalsIgnoreCase("delAtomBtn"))
        {
            McpExplorer.LogDebug("Delete Atom");
            DeleteAtom(super.getSelectedDynTabIndex("tab1"));
        } 
        else if(Key.equalsIgnoreCase("addColBtn"))
        {
            McpExplorer.LogDebug("Add Column");
            AddColumn();
        } 
        else if(Key.equalsIgnoreCase("delColBtn"))
        {
            McpExplorer.LogDebug("Delete Column");
            DeleteColumn();
        } 
        else if(Key.endsWith("addRowBtn"))
        {
            String szTabKey = Key.substring(0, Key.indexOf("|") + 1);
            McpExplorer.LogDebug("Add Row: " + szTabKey);        
            AddRow(szTabKey);
        } 
        else if(Key.endsWith("delRowBtn"))
        {
            String szTabKey = Key.substring(0, Key.indexOf("|") + 1);
            McpExplorer.LogDebug("Delete Row: " + szTabKey);        
            DeleteRow(szTabKey);
        } 
        
        else
        {
            // do nothing
        }
        McpExplorer.bDocumentChanged = true;
    }

    protected void AddAtom()
    {
        McpExplorer.LogDebug("AddAtom: " + iNumAtoms + " -> " + (iNumAtoms + 1));
            
        // Get Default Values
        String var_x = "0";
        String var_y = "0";
        String var_z = "0";
        String non = "1";
        String dex = "0";
        String gJ = "0";
        String cffile = "";        
        
        // Make initial Empty Vector
        Vector tab = new Vector();
        String x[] = new String[iNumColumns];
        for(int i = 0; i < iNumColumns; ++i)
        {
            x[i] = "+0";
        }
        tab.add(x);

        // Increase Number of Atoms Variable
        ++iNumAtoms;

        // Create new Tab
        String szName = "tab1Pan" + String.valueOf(iNumAtoms) + "|";
        String szLabel = "Magnetic Atom " + String.valueOf(iNumAtoms);
        McpExplorer.LogDebug("AddDynTabPanel: " + szName + ", " + szLabel);

        McpTable table = new McpTable(new McpTableModel(tab, "Float"), szName);
        JScrollPane jsp = new JScrollPane(table);        
        
        super.AddDynTabPanel("tab1", szName, szLabel, "tab1Pan1", m_resources);
        // Fill In Header-Values
        ((McpTextField)mapKeys.get(szName + "x")).setText(var_x);
        mapValues.put(szName + "x", var_x);
        
        ((McpTextField)mapKeys.get(szName + "y")).setText(var_y);
        mapValues.put(szName + "y", var_y);

        ((McpTextField)mapKeys.get(szName + "z")).setText(var_z);
        mapValues.put(szName + "z", var_z);

        ((McpTextField)mapKeys.get(szName + "nofneighbours")).setText(non);
        mapValues.put(szName + "nofneighbours", non);

        ((McpCheckBox)mapKeys.get(szName + "diagonalexchange")).setCheckBoxValue(dex);
        mapValues.put(szName + "diagonalexchange", dex);
        
        ((McpTextField)mapKeys.get(szName + "gJ")).setText(gJ);
        mapValues.put(szName + "gJ", gJ);

        ((McpFileInput)mapKeys.get(szName + "cffilename")).setValue(cffile);
        mapValues.put(szName + "cffilename", cffile);
     
        table.getModel().addTableModelListener(new TableListener(table));
        mapTables.put(szName, table);
        
        try
        {
            this.addComponent(jsp, (JPanel)mapTabs.get(szName), 0, 3, 6, 1, GridBagConstraints.BOTH, GridBagConstraints.CENTER);
        }
        catch(Exception ex)
        {
            McpExplorer.LogExc("McpMcpasJ", "AddAtom", "EXC", ex);
        }
        
        // Increase Variable in Header
        McpTextField tf = (McpTextField)mapKeys.get("nofatoms"); 
        tf.setValue(String.valueOf(iNumAtoms));
        
        // Append Values in Editor
        StringBuffer sb = new StringBuffer(100);
        sb.append("# ****************************************************************************\n")
        	.append("# x=   ").append(var_x).append(" [a] y=   ").append(var_y).append(" [b] z=   ").append(var_z)
        	.append(" nofneighbours=").append(non).append(" diagonalexchange=").append(dex).append(" gJ=").append(gJ).append(" cffilename=").append(cffile).append("\n")
        	.append("# x[a]      y[b]      z[c]       Jaa[meV]  Jbb[meV]  Jcc[meV]  Jab[meV]  Jba[meV]  Jac[meV]  Jca[meV]  Jbc[meV]  Jcb[meV]\n");
//        # ****************************************************************************
//        # x=   2 [a] y=   0.32 [b] z=   0.1 [c] nofneighbours=1412 diagonalexchange=1 gJ=0.727273 cffilename=mcphas.cf1
//        # x[a]      y[b]      z[c]       Jaa[meV]  Jbb[meV]  Jcc[meV]  Jab[meV]  Jba[meV]  Jac[meV]  Jca[meV]  Jbc[meV]  Jcb[meV]
        edit.append(sb.toString());
        
        // Append Table
        edit.append(table.getTableContent());
        
    }
    
    protected void DeleteAtom(int iIndex)
    {
        McpExplorer.LogDebug("DeleteAtom " + iIndex + " : " + iNumAtoms + " -> " + (iNumAtoms - 1));
        
        if(iIndex <= 0)
        {
            McpExplorer.LogDebug("Wrong Index !");
            return;
        }
        
        if(iNumAtoms == 1)
        {
            McpExplorer.LogDebug("At least 1 Atom is required!");
            return;
        }
        
        // Decrease Number of Atoms Variable
        --iNumAtoms;

        // Decrease Variable in Header
        McpTextField tf = (McpTextField)mapKeys.get("nofatoms"); 
        tf.setValue(String.valueOf(iNumAtoms));
        
        // Remove Keys, Values und TabControl
        String szName = "tab1Pan" + String.valueOf(iIndex) + "|";
        super.RemoveDynTabPanel("tab1", szName);
        
        mapKeys.remove(szName + "x");
        mapValues.remove(szName + "x");
        
        mapKeys.remove(szName + "y");
        mapValues.remove(szName + "y");
        
        mapKeys.remove(szName + "z");
        mapValues.remove(szName + "z");
        
        mapKeys.remove(szName + "nofneighbours");
        mapValues.remove(szName + "nofneighbours");
        
        mapKeys.remove(szName + "diagonalexchange");
        mapValues.remove(szName + "diagonalexchange");
        
        mapKeys.remove(szName + "gJ");
        mapValues.remove(szName + "gJ");
        
        mapKeys.remove(szName + "cffilename");
        mapValues.remove(szName + "cffilename");
                 
        mapKeys.remove(szName + "addRowBtn");
        mapValues.remove(szName + "addRowBtn");
        
        mapKeys.remove(szName + "delRowBtn");
        mapValues.remove(szName + "delRowBtn");
        
        mapTables.remove(szName);
        
        reorganizeTabs();
        
        // Delete Values in Editor
        delEditorAtomValues(iIndex);
    }
    
    private void delEditorAtomValues(int iIndex)
    {
        boolean bFound = false;
        String szTxt = "";
        try
        {
            szTxt = edit.getDocument().getText(0, edit.getDocument().getLength());
        }
        catch(Exception ex)
        {
            
        }
        Scanner scan = new Scanner(szTxt);
        scan.useDelimiter("\n");
        int iDocPos = 0;
        int iPosStartValue = 0;
        int iLen = 0;
        while (scan.hasNext() && bFound == false) 
        {
            String s = scan.next();
            {
//                int iPos = s.indexOf("#");
                if(s.indexOf("*****") >= 0)
                {
                    // Abschnitt gefunden !!!
                    iIndex--;
                    if(iIndex == 0)
                    {   
                        // Das ist der Anfang
                        iPosStartValue = iDocPos;
                    }
                    else if(iIndex < 0)
                    {
                        // Das ist das Ende
                        iLen = iDocPos - iPosStartValue;
                        bFound = true;
                    }
                }
            }
            iDocPos += s.length() + 1;
        }   
        if (iPosStartValue > 0 && iLen == 0)
        {
            iLen = iDocPos - iPosStartValue;
        }
        try
        {
            if(iPosStartValue > 0 && iLen > 0)
            {
                edit.getDocument().remove(iPosStartValue, iLen);
            }
        }
        catch(Exception ex)
        {
            
        }
        scan.close();
        scan = null;
        edit.revalidate();        
    }
    public void RefreshEditor()
    {
        McpExplorer.LogDebug("Refresh Editor");
        if(activeField != null)
        {
            edit.replaceIniValue(activeField.getIniKey(), activeField.getText(), szType, activeField.getFormat());
            activeField = null;
        }
    }

    private void RefreshTable(int iIndex, String szData)
    {
        boolean bFound = false;
        String szTxt = "";
        try
        {
            szTxt = edit.getDocument().getText(0, edit.getDocument().getLength());
        }
        catch(Exception ex)
        {
            
        }
        Scanner scan = new Scanner(szTxt);
        scan.useDelimiter("\n");
        int iDocPos = 0;
        int iPosStartValue = 0;
        int iLen = 0;
        while (scan.hasNext() && bFound == false) 
        {
            String s = scan.next();
            {
                int iPos = s.indexOf("#");
                if(s.indexOf("*****") >= 0)
                {
                    // Abschnitt gefunden !!!
                    iIndex--;
                }
                if(iIndex == 0 && iPos < 0 && iPosStartValue == 0)
                {   
                    // Das ist der Anfang
                    iPosStartValue = iDocPos;
                }
                else if(iIndex < 0)
                {
                    // Das ist das Ende
                    iLen = iDocPos - iPosStartValue;
                    bFound = true;
                }
            }
            iDocPos += s.length() + 1;
        }   
        if (iPosStartValue > 0 && iLen == 0)
        {
            iLen = iDocPos - iPosStartValue;
        }
        try
        {
            if(iPosStartValue > 0 && iLen > 0)
            {
                edit.getDocument().remove(iPosStartValue, iLen);
                edit.getDocument().insertString(iPosStartValue, szData, null);
            }
        }
        catch(Exception ex)
        {
            
        }
        scan.close();
        scan = null;
        edit.revalidate();        
    }
    
    private void reorganizeTabs()
    {
        McpExplorer.LogDebug("reorganizeTabs");
        JTabbedPane tab = (JTabbedPane)mapDynTabs.get("tab1");
        
        // We should have iNumAtoms Tabs
        for (int i = 1; i <= iNumAtoms; ++i)
        {
            String szName = "tab1Pan" + String.valueOf(i) + "|";
            if(!mapTabs.containsKey(szName))
            {
                String szNameTabNext = "tab1Pan" + String.valueOf(i + 1) + "|";
                if(mapTabs.containsKey(szNameTabNext))
                {
                    tab.setTitleAt(i - 1, "Magnetic Atom " + i);
                    mapTabs.put(szName, mapTabs.get(szNameTabNext));
                    mapTabs.remove(szNameTabNext);
                    mapTables.put(szName, mapTables.get(szNameTabNext));
                    mapTables.remove(szNameTabNext);
                    ((McpTable)mapTables.get(szName)).setName(szName);
                }
            }
            
            if(!mapKeys.containsKey(szName + "x"))
            {
                String szNameNext = "tab1Pan" + String.valueOf(i + 1) + "|";
                if(mapKeys.containsKey(szNameNext + "x"))
                {
                    mapKeys.put(szName + "x", mapKeys.get(szNameNext + "x"));
                    mapValues.put(szName + "x", mapValues.get(szNameNext + "x"));    
                    ((McpTextField)mapKeys.get(szName + "x")).setIniKey(szName + "x");
                    
                    mapKeys.put(szName + "y", mapKeys.get(szNameNext + "y"));
                    mapValues.put(szName + "y", mapValues.get(szNameNext + "y"));
                    ((McpTextField)mapKeys.get(szName + "y")).setIniKey(szName + "y");

                    mapKeys.put(szName + "z", mapKeys.get(szNameNext + "z"));
                    mapValues.put(szName + "z", mapValues.get(szNameNext + "z"));
                    ((McpTextField)mapKeys.get(szName + "z")).setIniKey(szName + "z");

                    mapKeys.put(szName + "nofneighbours", mapKeys.get(szNameNext + "nofneighbours"));
                    mapValues.put(szName + "nofneighbours", mapValues.get(szNameNext + "nofneighbours"));                    
                    ((McpTextField)mapKeys.get(szName + "nofneighbours")).setIniKey(szName + "nofneighbours");

                    mapKeys.put(szName + "diagonalexchange", mapKeys.get(szNameNext + "diagonalexchange"));
                    mapValues.put(szName + "diagonalexchange", mapValues.get(szNameNext + "diagonalexchange"));
                    ((McpCheckBox)mapKeys.get(szName + "diagonalexchange")).setIniKey(szName + "diagonalexchange");

                    mapKeys.put(szName + "gJ", mapKeys.get(szNameNext + "gJ"));
                    mapValues.put(szName + "gJ", mapValues.get(szNameNext + "gJ"));
                    ((McpTextField)mapKeys.get(szName + "gJ")).setIniKey(szName + "gJ");

                    mapKeys.put(szName + "cffilename", mapKeys.get(szNameNext + "cffilename"));
                    mapValues.put(szName + "cffilename", mapValues.get(szNameNext + "cffilename"));
                    ((McpFileInput)mapKeys.get(szName + "cffilename")).setIniKey(szName + "cffilename");
                    
                    mapKeys.put(szName + "addRowBtn", mapKeys.get(szNameNext + "addRowBtn"));
                    mapValues.put(szName + "addRowBtn", mapValues.get(szNameNext + "addRowBtn"));
                    ((McpButton)mapKeys.get(szName + "addRowBtn")).setIniKey(szName + "addRowBtn");

                    mapKeys.put(szName + "delRowBtn", mapKeys.get(szNameNext + "delRowBtn"));
                    mapValues.put(szName + "delRowBtn", mapValues.get(szNameNext + "delRowBtn"));
                    ((McpButton)mapKeys.get(szName + "delRowBtn")).setIniKey(szName + "delRowBtn");
                    
                    mapKeys.remove(szNameNext + "x");
                    mapValues.remove(szNameNext + "x");
                    
                    mapKeys.remove(szNameNext + "y");
                    mapValues.remove(szNameNext + "y");
                    
                    mapKeys.remove(szNameNext + "z");
                    mapValues.remove(szNameNext + "z");
                    
                    mapKeys.remove(szNameNext + "nofneighbours");
                    mapValues.remove(szNameNext + "nofneighbours");
                    
                    mapKeys.remove(szNameNext + "diagonalexchange");
                    mapValues.remove(szNameNext + "diagonalexchange");
                    
                    mapKeys.remove(szNameNext + "gJ");
                    mapValues.remove(szNameNext + "gJ");
                    
                    mapKeys.remove(szNameNext + "cffilename");
                    mapValues.remove(szNameNext + "cffilename");
                    
                    mapKeys.remove(szNameNext + "addRowBtn");
                    mapValues.remove(szNameNext + "addRowBtn");
                    
                    mapKeys.remove(szNameNext + "delRowBtn");
                    mapValues.remove(szNameNext + "delRowBtn");
                    
                }
            }
        }
    }
    
    protected void AddRow(String szTable)
    {
        McpTable table = (McpTable)mapTables.get(szTable);
        McpTableModel mod = (McpTableModel)table.getModel();
        mod.addDefaultRow("+0");
        ((McpTextField)mapKeys.get(szTable + "nofneighbours")).setValue(String.valueOf(mod.getRowCount()));
    }
    
    protected void DeleteRow(String szTable)
    {
        McpTable table = (McpTable)mapTables.get(szTable);
        McpTableModel mod = (McpTableModel)table.getModel();
//        int iCount = table.getSelectedRowCount();
        int iSelRows[] = table.getSelectedRows();
        mod.delRows(iSelRows);
        ((McpTextField)mapKeys.get(szTable + "nofneighbours")).setValue(String.valueOf(mod.getRowCount()));
    }
    
    protected void AddColumn()
    {
        ++iNumColumns;
        Object o[] = mapTables.values().toArray();
        for(int i = 0; i < o.length; ++i)
        {
            McpTable table = (McpTable)o[i];
            McpTableModel mod = (McpTableModel)table.getModel();
            mod.addDefaultColumn("+0");            
        }
    }

    protected void DeleteColumn()
    {
        --iNumColumns;
        Object o[] = mapTables.values().toArray();
        for(int i = 0; i < o.length; ++i)
        {
            McpTable table = (McpTable)o[i];
            McpTableModel mod = (McpTableModel)table.getModel();
            mod.delColumn();            
        }
        
    }
    
    private class TableListener implements TableModelListener
    {
        McpTable t;
        
        TableListener(McpTable tab) 
        {
            super();
            this.t = tab;
        }
        
        public void tableChanged(TableModelEvent e) 
        {     
            String tab = t.getName().substring(0, t.getName().length() - 1);
            int iPos = Integer.valueOf(tab.substring(7)).intValue();
            McpExplorer.LogDebug("Change in Table: " + iPos);
            RefreshTable(iPos, ((McpTableModel)t.getModel()).getDataAsFileTable());
        }
    }    
}
