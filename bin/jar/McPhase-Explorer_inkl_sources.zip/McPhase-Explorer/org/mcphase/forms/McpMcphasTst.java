/*
 * Created on 06.04.2005
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package org.mcphase.forms;

import java.awt.Dimension;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.util.Locale;
import java.util.MissingResourceException;
import java.util.ResourceBundle;
import java.util.Scanner;

import javax.swing.JLabel;
import javax.swing.JPanel;

import org.mcphase.McpCheckBox;
import org.mcphase.McpComboBox;
import org.mcphase.McpEditor;
import org.mcphase.McpExplorer;
import org.mcphase.McpForm;
import org.mcphase.McpSpin;
import org.mcphase.McpSpinCube;
import org.mcphase.McpSpinRow;
import org.mcphase.McpSpinTable;
import org.mcphase.McpTextField;

/**
 * @author Stefan
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
public class McpMcphasTst extends McpForm
{
    static 
    {
        try 
        {
            resources = ResourceBundle.getBundle("org.mcphase.resources.forms.McPhasTst", Locale.getDefault());
        } 
        catch (MissingResourceException mre) 
        {
            System.err.println("org/mcphase/resources/forms/McPhasTst not found");
            System.exit(1);
        }
    }
    
    static final long serialVersionUID = 9151041304234150694L;
    
    private McpSpinCube cub [];
    private int iSpinConfNumber = 0;
    private int iCurSpinConf = 0;
    private JPanel panNav;
    private int iVectorLength = 0;
    private int iNumComponents = 0;
    private int iNumAtoms = 0;

    public int getCurSpinConf()
    {
        return(iCurSpinConf);
    }
    
    public void setCurSpinConf(int i)
    {
        iCurSpinConf = i;
    }
    
    public McpMcphasTst(McpEditor ed)
    {
        super(ed);
        szType = "j";
    }

    public void initFromString(String szSource)
    {
        iSpinConfNumber = 0;
        cub = new McpSpinCube[iSpinConfNumber];
        iNumComponents = 0;
        iNumAtoms = 0;
        iVectorLength = 0;
        
        int iCurrSpinPos = 0;
        int iCurrRowPos = 0;
//        int iCurrTabPos = 0;
        int iNumColumns = 0;
        McpSpinRow curRow = null;
        McpSpinTable curTab = null;
        McpSpinCube curCub = null;
        boolean bInTable = false;
        Scanner scan = new Scanner(szSource);
        mapValues.clear();
        scan.useDelimiter("\n");
        while (scan.hasNext()) 
        {
            String s = scan.next().trim();
            
            // Kommentierte Zeile
            // 1. Ganz zu beginn
            // 2. Ende eines Blocks
            if(s.startsWith("#"))
            {
                // Wir befinden uns am Ende eines Blocks
                if(bInTable)
                {
                    // We got a Table -> Store it !
                    curTab.addRow(curRow);
                    curCub.addTab(curTab);
                    McpExplorer.LogDebug("NEW Cube:\n" + curCub.toOutString() + "\n");
                    McpSpinCube tmp [] = cub;
                    cub = new McpSpinCube[cub.length + 1];
                    System.arraycopy(tmp, 0, cub, 0, tmp.length);
                    cub[cub.length - 1] = curCub;
                    curRow = null;
                    curTab = null;
                    curCub = null;
                    iCurrSpinPos = 0;
                    iCurrRowPos = 0;
//                    iCurrTabPos = 0;
                    iNumColumns = 0;
                }
                bInTable = false;

                
                Object[] o = mapKeys.values().toArray();                    
                for (int i = 0; i < o.length; ++i)
                {
                    String szKey = "";
                    int iFormat = McpEditor.FORMAT_FLOAT;
                    if(o[i] instanceof McpTextField)
                    {
                        szKey = ((McpTextField)o[i]).getIniKey();
                        iFormat = ((McpTextField)o[i]).getFormat();
                    }
                    else if(o[i] instanceof McpCheckBox)
                    {
                        szKey = ((McpCheckBox)o[i]).getIniKey();
                        iFormat = McpEditor.FORMAT_INTEGER;
                    }
                    else if(o[i] instanceof McpComboBox)
                    {
                        szKey = ((McpComboBox)o[i]).getIniKey();
                        iFormat = ((McpComboBox)o[i]).getFormat();
                    }
                    else
                    {
                        
                    }
                    if(szKey.length() > 0)
                    {
                        String szValue = extract(s, szKey, iFormat);
                        if(szValue.length() > 0)
                        {
                            if(o[i] instanceof McpTextField)
                            {
                                ((McpTextField)o[i]).setText(szValue);
                                mapValues.put(szKey, szValue);
                            }
                            else if(o[i] instanceof McpCheckBox)
                            {
                                ((McpCheckBox)o[i]).setCheckBoxValue(szValue);
                                mapValues.put(szKey, szValue);
                            }
	                        else if(o[i] instanceof McpComboBox)
	                        {
	                            ((McpComboBox)o[i]).setComboBoxValue(szValue);
	                            mapValues.put(szKey, szValue);
	                        }
                            else
                            {
                                McpExplorer.LogError("Line " + i + ": " + s + "\tKEY: '" + szKey + "'\tVALUE: '" + szValue + "'\t Unkown");                                                    
                            }                            
                            if(szKey.equals("nofatoms"))
                            {
                                iNumAtoms = Integer.valueOf(szValue).intValue();
                            }
                            if(szKey.equals("nofcomponents"))
                            {
                                iNumComponents = Integer.valueOf(szValue).intValue();
                            }
                            iVectorLength = iNumAtoms * iNumComponents;
                        }
                    }
                }
            }
            else
            {
                // We reached table-data
                if(!bInTable && s.length() > 0)
                {
                    // Got a new Table
                    ++iSpinConfNumber;                    
                    iCurrSpinPos = 0;
                    iCurrRowPos = 0;
//                    iCurrTabPos = 0;
                }
                // Wir sind nur in einer echten Tabelle, wenn in einer Zeile irgendetwas steht
                if(s.length() > 0)
                {
                    bInTable = true;
                }
                
                // Jetzt haben wir eine neue Tabelle im Block erreicht
                if(s.length() == 0 && curRow != null)
                {
                    // got a new Table
                    curTab.addRow(curRow);
                    curCub.addTab(curTab);
                    curRow = null;
                    curTab = null;
                    iCurrSpinPos = 0;
                    iCurrRowPos = 0;                    
                }
                else
                {
	                String x[] = tokenize(s);
	                iNumColumns = x.length;
	                if(curTab == null)
	                {
	                    curTab = new McpSpinTable(0);
	                }
	                if(curRow == null)
	                {
	                    curRow = new McpSpinRow(iNumColumns, iNumAtoms, iNumComponents);
	                }
	                if(curCub == null)
	                {
	                    curCub = new McpSpinCube(0);
	                }
	                if(iCurrSpinPos >= iVectorLength)
	                {	                    
	                    iCurrSpinPos = 0;
	                    curTab.addRow(curRow);
	                    curRow = new McpSpinRow(iNumColumns, iNumAtoms, iNumComponents);
	                    curRow.setSpinValFromStrArray(iCurrSpinPos, x);
	                    ++iCurrSpinPos;
	                    ++iCurrRowPos;
	                }
	                else
	                {
	                    curRow.setSpinValFromStrArray(iCurrSpinPos, x);
	                    ++iCurrSpinPos;
	                }
                }                
            }
        }
        scan.close();
        scan = null;
        Object o = mapKeys.get("nospinconfiguration");
        if (o != null)
        {
            if(o instanceof McpComboBox)
            {
                ((McpComboBox)o).FillWithIntList(iSpinConfNumber);
                ((McpComboBox)o).setComboBoxValue("1");
                mapValues.put("nospinconfiguration", "1");
                setCurSpinConf(1);
            }
        }
        setCurSpinConf(0);
        setActiveCub(0);
        createNavPanel(iNumAtoms, iNumComponents, cub[0].getSpinVector(1, 1, 1));
    }

    protected void setActiveCub(int iNum)
    {
        setFieldValue("r1", String.valueOf(cub[iNum].getMaxR1()));
        setFieldValue("r2", String.valueOf(cub[iNum].getMaxR2()));
        setFieldValue("r3", String.valueOf(cub[iNum].getMaxR3()));
        setFieldValue("navr1", "1");
        setFieldValue("navr2", "1");
        setFieldValue("navr3", "1");
        this.repaint();        
    }

    protected void setFieldValue(String szKey, String szValue)
    {
        mapValues.put(szKey, szValue);
        Object o = mapKeys.get(szKey);
        if (o != null)
        {
            if(o instanceof McpComboBox)
            {
                ((McpComboBox)o).setComboBoxValue(szValue);
            }
            else if(o instanceof McpTextField)
            {
                ((McpTextField)o).setValue(szValue);
            }
        }
    }
    public void RefreshEditor()
    {
        if(activeField != null)
        {
	        if(activeField.getIniKey().startsWith("NAVVAL_"))
	        {
	            mapValues.put(activeField.getIniKey(), activeField.getText());
	            // Navigator-Value has Changed
	            cub[iCurSpinConf].setSpinVector(Integer.valueOf(mapValues.get("navr1").toString()).intValue(),
	                    Integer.valueOf(mapValues.get("navr2").toString()).intValue(),
	                    Integer.valueOf(mapValues.get("navr3").toString()).intValue(),
	                    getNavValue());
	            McpExplorer.LogDebug("Cube Changed:\n" + cub[iCurSpinConf].toOutString() + "\n");
	            // Now refresh the Editor
	            refreshEditor();
	        }
            else if(activeField.getIniKey().equalsIgnoreCase("nofatoms")
                    || activeField.getIniKey().equalsIgnoreCase("nofcomponents"))
            {
                FieldChanged(activeField.getIniKey(), mapValues.get(activeField.getIniKey()).toString(), activeField.getText());
                super.RefreshEditor();
            }
	        else
	        {
	            super.RefreshEditor();
	        }
        }
        activeField = null;
    }   
    
    protected void FieldChanged(String Key, String valueOld, String valueNew)
    {
        McpExplorer.LogInfo("FieldChange: " + Key + ": " + valueOld + " -> " + valueNew);
        if(
                Key.equalsIgnoreCase("r1")
                ||Key.equalsIgnoreCase("r2")
                ||Key.equalsIgnoreCase("r3")
                ||Key.equalsIgnoreCase("navr1")
                ||Key.equalsIgnoreCase("navr2")
                ||Key.equalsIgnoreCase("navr3")
           )
        {
            // Darf nicht kleiner als 1 sein
            Integer vNew = Integer.valueOf(valueNew);
            Integer vOld = Integer.valueOf(valueOld);
            if(vNew != null && vNew.intValue() < 1)
            {
                McpTextField tf = (McpTextField)mapKeys.get(Key);
                tf.setValue("1");
            }
            if(vNew != null && vOld != null)
            {
                if(vNew.intValue() < vOld.intValue())
                {
                    if(Key.equalsIgnoreCase("r1")
                    ||Key.equalsIgnoreCase("r2")
                    ||Key.equalsIgnoreCase("r3"))
                    {
                        String keyNav = "nav" + Key;
                        Integer vNav = Integer.valueOf(mapValues.get(keyNav).toString());
                        if(vNav != null)
                        {
                            if(vNav.intValue() > vNew.intValue())
                            {
                                McpTextField tf = (McpTextField)mapKeys.get(keyNav);
                                tf.setValue(vNew.toString());                                
                            }
                        }
                    }                    
                }                
            }
        }
        if(Key.equalsIgnoreCase("r1UpBtn"))
        {
            Integer r1Val = Integer.valueOf(mapValues.get("r1").toString());
            Integer navr1Val = Integer.valueOf(mapValues.get("navr1").toString());
            if(r1Val != null && navr1Val != null)
            {
                if(navr1Val.intValue() < r1Val.intValue())
                {
                    McpTextField tf = (McpTextField)mapKeys.get("navr1");
                    tf.setValue(String.valueOf(navr1Val.intValue() + 1));
                }
            }
        }
        
        if(Key.equalsIgnoreCase("r2UpBtn"))
        {
            Integer r2Val = Integer.valueOf(mapValues.get("r2").toString());
            Integer navr2Val = Integer.valueOf(mapValues.get("navr2").toString());
            if(r2Val != null && navr2Val != null)
            {
                if(navr2Val.intValue() < r2Val.intValue())
                {
                    McpTextField tf = (McpTextField)mapKeys.get("navr2");
                    tf.setValue(String.valueOf(navr2Val.intValue() + 1));
                }
            }
        }
        
        if(Key.equalsIgnoreCase("r3UpBtn"))
        {
            Integer r3Val = Integer.valueOf(mapValues.get("r3").toString());
            Integer navr3Val = Integer.valueOf(mapValues.get("navr3").toString());
            if(r3Val != null && navr3Val != null)
            {
                if(navr3Val.intValue() < r3Val.intValue())
                {
                    McpTextField tf = (McpTextField)mapKeys.get("navr3");
                    tf.setValue(String.valueOf(navr3Val.intValue() + 1));
                }
            }
        }
        
        if(Key.equalsIgnoreCase("r1DownBtn"))
        {
            Integer navr1Val = Integer.valueOf(mapValues.get("navr1").toString());
            if(navr1Val != null)
            {
                if(navr1Val.intValue() > 1)
                {
                    McpTextField tf = (McpTextField)mapKeys.get("navr1");
                    tf.setValue(String.valueOf(navr1Val.intValue() - 1));
                }
            }
        }
        
        if(Key.equalsIgnoreCase("r2DownBtn"))
        {
            Integer navr2Val = Integer.valueOf(mapValues.get("navr2").toString());
            if(navr2Val != null)
            {
                if(navr2Val.intValue() > 1)
                {
                    McpTextField tf = (McpTextField)mapKeys.get("navr2");
                    tf.setValue(String.valueOf(navr2Val.intValue() - 1));
                }
            }
        }
        
        if(Key.equalsIgnoreCase("r3DownBtn"))
        {
            Integer navr3Val = Integer.valueOf(mapValues.get("navr3").toString());
            if(navr3Val != null)
            {
                if(navr3Val.intValue() > 1)
                {
                    McpTextField tf = (McpTextField)mapKeys.get("navr3");
                    tf.setValue(String.valueOf(navr3Val.intValue() - 1));
                }
            }
        }

        if(Key.equalsIgnoreCase("nospinconfiguration"))
        {
            int iVal = 1;
            if(valueNew != null)
            {
	            iVal = Integer.valueOf(valueNew).intValue();                
            }
            setCurSpinConf(iVal - 1);
            setActiveCub(iVal - 1);
            setNavValue(cub[iCurSpinConf].getSpinVector((Integer.valueOf(mapValues.get("navr1").toString()).intValue()),
                    Integer.valueOf(mapValues.get("navr2").toString()).intValue(),
                    Integer.valueOf(mapValues.get("navr3").toString()).intValue()));
            McpExplorer.LogDebug("Cube Changed:\n" + cub[iCurSpinConf].toOutString() + "\n");            
        }
        
        if(Key.startsWith("NAVVAL_"))
        {
            // Navigator-Value has Changed
            cub[iCurSpinConf].setSpinVector(Integer.valueOf(mapValues.get("navr1").toString()).intValue(),
                    Integer.valueOf(mapValues.get("navr2").toString()).intValue(),
                    Integer.valueOf(mapValues.get("navr3").toString()).intValue(),
                    getNavValue());
            McpExplorer.LogDebug("Cube Changed:\n" + cub[iCurSpinConf].toOutString() + "\n");
            // Now refresh the Editor
            refreshEditor();
        }

        if(Key.startsWith("navr"))
        {
            // Navigator-Position has Changed
            setNavValue(cub[iCurSpinConf].getSpinVector((Integer.valueOf(mapValues.get("navr1").toString()).intValue()),
                    Integer.valueOf(mapValues.get("navr2").toString()).intValue(),
                    Integer.valueOf(mapValues.get("navr3").toString()).intValue()));
            McpExplorer.LogDebug("Cube Changed:\n" + cub[iCurSpinConf].toOutString() + "\n");
        }
        
        if(Key.equalsIgnoreCase("r1")
                ||Key.equalsIgnoreCase("r2")
                ||Key.equalsIgnoreCase("r3"))
        {
	        Integer vNew = Integer.valueOf(valueNew);
	        Integer vOld = Integer.valueOf(valueOld);
	        if(Key.equalsIgnoreCase("r1") && vNew.intValue() != vOld.intValue())
	        {
	            cub[iCurSpinConf].refreshR1(vNew.intValue() - vOld.intValue());
	            refreshEditor();
	        }
	        if(Key.equalsIgnoreCase("r2") && vNew.intValue() != vOld.intValue())
	        {
	            cub[iCurSpinConf].refreshR2(vNew.intValue() - vOld.intValue());
	            refreshEditor();
	        }
	        if(Key.equalsIgnoreCase("r3") && vNew.intValue() != vOld.intValue())
	        {
	            cub[iCurSpinConf].refreshR3(vNew.intValue() - vOld.intValue());
	            refreshEditor();
	        }
        }

        if(Key.equalsIgnoreCase("nofatoms")
                ||Key.equalsIgnoreCase("nofcomponents"))
        {
	        Integer vNew = Integer.valueOf(valueNew);
	        Integer vOld = Integer.valueOf(valueOld);

            // Darf nicht kleiner als 1 sein
            if(vNew != null && vNew.intValue() < 1)
            {
                McpTextField tf = (McpTextField)mapKeys.get(Key);
                tf.setValue("1");
            }
	        
	        if(Key.equalsIgnoreCase("nofatoms") && vNew.intValue() != vOld.intValue())
	        {
	            iNumAtoms = vNew.intValue();
                // Gilt f�r alle -> daher cub durchwandern
                //cub[iCurSpinConf].refreshNumAtoms(vNew.intValue() - vOld.intValue());
                for(int i = 0; i < cub.length; ++i)
                {
                    cub[i].refreshNumAtoms(vNew.intValue() - vOld.intValue());
                }
	            //refreshEditor();
                refreshAllTables();
	        }
	        if(Key.equalsIgnoreCase("nofcomponents") && vNew.intValue() != vOld.intValue())
	        {
	            iNumComponents = vNew.intValue();
                // Gilt f�r alle -> daher cub durchwandern
	            //cub[iCurSpinConf].refreshNumComps(vNew.intValue() - vOld.intValue());
                for(int i = 0; i < cub.length; ++i)
                {
                    cub[i].refreshNumComps(vNew.intValue() - vOld.intValue());
                }
                //refreshEditor();
                refreshAllTables();
	        }
	        // Navigator neu aufbauen !
	        createNavPanel(iNumAtoms, iNumComponents, cub[iCurSpinConf].getSpinVector((Integer.valueOf(mapValues.get("navr1").toString()).intValue()),
            Integer.valueOf(mapValues.get("navr2").toString()).intValue(),
            Integer.valueOf(mapValues.get("navr3").toString()).intValue()));
	        this.revalidate();
       
        }

        if(Key.equalsIgnoreCase("addspintable"))
        {
            addSpinTable();
        }
        
        if(Key.equalsIgnoreCase("delspintable"))
        {
            removeSpinTable(iCurSpinConf);
        }
        McpExplorer.bDocumentChanged = true;
    }
    
    protected void refreshEditor()
    {
        // Block-Number = iCurSpinConf + 1
        // Data in cub[iCurSpinConf]
        int iActiveBlock = iCurSpinConf;
        boolean bInBlock = false;
        boolean bFound = false;
        String szTxt = "";
        try
        {
            szTxt = edit.getDocument().getText(0, edit.getDocument().getLength());
        }
        catch(Exception ex)
        {
            
        }
        Scanner scan = new Scanner(szTxt);
        scan.useDelimiter("\n");
        int iDocPos = 0;
        int iPosStartValue = 0;
        int iLen = 0;
        while (scan.hasNext() && bFound == false) 
        {
            String s = scan.next();
            {
                int iPos = s.indexOf("#");
                if(iPos >= 0)
                {
                    if(bInBlock)
                    {
                        // This is the End-Line of a Block
                        iLen = iDocPos - iPosStartValue;
                        if(iActiveBlock < 0)
                        {
                            bFound = true;
                        }
                    }
                    bInBlock = false;
                }        
                else
                {
                    if(!bInBlock)
                    {
                        // This is the Beginning of a block
                        --iActiveBlock;
                        iPosStartValue = iDocPos;
                    }
                    bInBlock = true;
                }
            }
            iDocPos += s.length() + 1;
        }
        if (iPosStartValue > 0 && iLen == 0)
        {
            iLen = iDocPos - iPosStartValue;
        }
        try
        {
            if(iPosStartValue > 0 && iLen > 0)
            {
                edit.getDocument().remove(iPosStartValue, iLen);
                edit.getDocument().insertString(iPosStartValue, cub[iCurSpinConf].toOutString(), null);
            }
        }
        catch(Exception ex)
        {
            
        }
        scan.close();
        scan = null;
        edit.revalidate();        
        
    }
    protected void refreshAllTables()
    {
        // Block-Number = iCurSpinConf + 1
        // Data in cub[iCurSpinConf]
//        int iActiveBlock = iCurSpinConf;
//        boolean bInBlock = false;
        boolean bFound = false;
        String szTxt = "";
        try
        {
            szTxt = edit.getDocument().getText(0, edit.getDocument().getLength());
        }
        catch(Exception ex)
        {
            
        }
        Scanner scan = new Scanner(szTxt);
        scan.useDelimiter("\n");
        int iDocPos = 0;
        int iPosStartValue = 0;
        int iLen = 0;
        while (scan.hasNext() && bFound == false) 
        {
            String s = scan.next();
            {
                int iPos = s.indexOf("#");
                if(iPos < 0)
                {
                    iPosStartValue = iDocPos;
                    bFound = true;
                }
            }
            iDocPos += s.length() + 1;
        }
        if (iPosStartValue > 0 && iLen == 0)
        {
            iLen = szTxt.length() - iPosStartValue;
        }
        try
        {
            if(iPosStartValue > 0 && iLen > 0)
            {
                edit.getDocument().remove(iPosStartValue, iLen);
                // Now insert all Spin-Tables
                for(int i = 0; i < cub.length; ++i)
                {
                    String szBlock = "";
                    if(i > 0)
                    {
                        szBlock += "# new configuration\n";
                    }
                    szBlock += cub[i].toOutString() + "# end of configuration\n";
                    edit.getDocument().insertString(iPosStartValue, szBlock, null);
                    iPosStartValue += szBlock.length();
                }
            }
        }
        catch(Exception ex)
        {
            
        }
        scan.close();
        scan = null;
        edit.revalidate();                       
    }
    
    protected McpSpin getNavValue()
    {
        McpSpin ret = new McpSpin(iNumComponents, iNumAtoms);
        for(int i = 0; i < iNumAtoms; ++i)
        {
            for(int j = 0; j < iNumComponents; ++j)
            {
                String szKey = "NAVVAL_" + String.valueOf(i) + "_" + String.valueOf(j);
                ret.setValAt(i * iNumComponents + j, mapValues.get(szKey).toString());
            }
        }
        return(ret);
    }
    
    protected void setNavValue(McpSpin s)
    {
        for(int i = 0; i < iNumAtoms; ++i)
        {
            for(int j = 0; j < iNumComponents; ++j)
            {
                String szKey = "NAVVAL_" + String.valueOf(i) + "_" + String.valueOf(j);
                String szValue = s.getValAt(i * iNumComponents + j);
                mapValues.put(szKey, szValue);
                McpTextField tf = (McpTextField)mapKeys.get(szKey);
                tf.setValue(szValue);
            }
        }
        this.revalidate();
    }
    
    protected void createNavPanel(int iNumAtoms, int iNumComp, McpSpin s)    
    {        
        McpTextField tf;
        if(panNav == null)
        {
            panNav = new JPanel(new GridBagLayout());
            try
            {
                addComponent(panNav, this, 0, 10, 1, 1, GridBagConstraints.BOTH, GridBagConstraints.CENTER);
            }
            catch(Exception ex)
            {

            }
        }
        else
        {
            panNav.removeAll();
        }
        
        try
        {
	        for(int i = 0; i < iNumAtoms; ++i)
	        {
	            addComponent(new JLabel("Atom " + String.valueOf(i + 1)), panNav, 0, i * iNumComp, 1, 1, GridBagConstraints.BOTH, GridBagConstraints.CENTER);            
	            for(int j = 0; j < iNumComp; ++j)
	            {
	                String szKey = "NAVVAL_" + String.valueOf(i) + "_" + String.valueOf(j);
	                String szValue = s.getValAt(i * iNumComp + j);
	                if(!mapKeys.containsKey(szKey))
	                {
		                tf = new McpTextField(szKey, szValue, "", "Float", "", "", true, "0");
		                tf.addFocusListener(createFieldChangeListener(tf));
		                tf.addCaretListener(createFieldCaretListener(tf));
		                mapKeys.put(szKey, tf);
	                }
	                else
	                {
	                    tf = (McpTextField)mapKeys.get(szKey);
	                    tf.setValue(szValue);
	                }

	                tf.setPreferredSize(new Dimension(40,20));
	                addComponent(tf, panNav, 1, i * iNumComp + j, 1, 1, GridBagConstraints.BOTH, GridBagConstraints.CENTER);            

	                //panNav.add(tf);
	                mapValues.put(szKey, szValue);
	            }
	        }
        }
        catch(Exception ex)
        {

        }
    }
    
    private void removeSpinTable(int iPos)
    {
        if(cub.length == 1)
        {
            return;
        }
        
        McpSpinCube[] cn = cub;
        int iNumCubs = cub.length - 1;
        cub = new McpSpinCube[iNumCubs];
        if(cn != null)
        {            
            System.arraycopy(cn, 0 , cub, 0, iPos);
            System.arraycopy(cn, iPos + 1 , cub, iPos, iNumCubs - iPos);            
        }
        
        refreshAllTables();
        // Anzeige in Combobox aktualisieren
        --iSpinConfNumber;
        Object o = mapKeys.get("nospinconfiguration");
        if (o != null)
        {
            if(o instanceof McpComboBox)
            {
                ((McpComboBox)o).FillWithIntList(iSpinConfNumber);
                ((McpComboBox)o).setComboBoxValue("1");
                mapValues.put("nospinconfiguration", "1");
                setCurSpinConf(1);
            }
        }
}
    
    private void addSpinTable()
    {
        McpSpinCube[] cn = cub;
        int iNumCubs = cub.length + 1;
        cub = new McpSpinCube[iNumCubs];
        if(cn != null)
        {
            System.arraycopy(cn, 0 , cub, 0, iNumCubs - 1);
        }
        cub[iNumCubs - 1] = cub[0];
        // Editor refreshen
        refreshAllTables();
        // Anzeige in Combobox aktualisieren
        ++iSpinConfNumber;
        Object o = mapKeys.get("nospinconfiguration");
        if (o != null)
        {
            if(o instanceof McpComboBox)
            {
                ((McpComboBox)o).FillWithIntList(iSpinConfNumber);
                ((McpComboBox)o).setComboBoxValue("1");
                mapValues.put("nospinconfiguration", "1");
                setCurSpinConf(1);
            }
        }
    }
}
