/*
 * Created on 29.09.2005
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package org.mcphase;


/**
 * @author Stefan
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
public class McpSpinCube
{
    private McpSpinTable[] tabs;
    private int iNumTabs;
    
    public McpSpinCube(int i)
    {
        iNumTabs = i;
        tabs = new McpSpinTable[i];
    }
    
    public McpSpinCube(McpSpinTable [] t)
    {
        System.arraycopy(t, 0, tabs, 0, t.length);
        iNumTabs = tabs.length;
    }
    
    public void addTab(McpSpinTable t)
    {
        McpSpinTable[] tn = tabs;
        ++iNumTabs;
        tabs = new McpSpinTable[iNumTabs];
        if(tn != null)
        {
            System.arraycopy(tn, 0 , tabs, 0, iNumTabs - 1);
        }
        tabs[iNumTabs - 1] = t;
    }
    
    public void setSpinValueAt(int iTab, int iRow, int iCol, int iSpinPos, String f)
    {
        tabs[iTab].setSpinValueAt(iRow, iCol, iSpinPos, f);
    }
    
    public String toOutString()
    {
        StringBuffer sb = new StringBuffer();
        for(int i = 0; i < iNumTabs; ++i)
        {
            if(i > 0)
            {
                sb.append("\n");                
            }
            sb.append(tabs[i].toOutString());
        }
        return(sb.toString());
    }

    public int getMaxR1()
    {
        return(tabs[0].getRow(0).getNumCols());
    }

    public int getMaxR2()
    {
        return(tabs[0].getNumRows());
    }

    public int getMaxR3()
    {
        return(iNumTabs);
    }
    
    public void setSpinVector(int r1, int r2, int r3, McpSpin s)
    {
        tabs[r3 - 1].getRow(r2 - 1).setValAt(r1 - 1, s);
    }
    
    public McpSpin getSpinVector(int r1, int r2, int r3)
    {
        return(tabs[r3 - 1].getRow(r2 - 1).getValAt(r1 - 1));
    }
    
    public void refreshR1(int iDiff)
    {
        if(iDiff == 0)
        {
            return;
        }
        else if (iDiff > 0)
        {
            addR1(iDiff);
        }
        else if (iDiff < 0)
        {
            removeR1(-iDiff);
        }
    }
    
    private void addR1(int iNum)
    {
        for(int i = 0; i < iNumTabs; ++i)
        {
            tabs[i].addCols(iNum);
        }
    }

    private void removeR1(int iNum)
    {
        for(int i = 0; i < iNumTabs; ++i)
        {
            tabs[i].removeCols(iNum);
        }
    }

    public void refreshR2(int iDiff)
    {
        if(iDiff == 0)
        {
            return;
        }
        else if (iDiff > 0)
        {
            addR2(iDiff);
        }
        else if (iDiff < 0)
        {
            removeR2(-iDiff);
        }
    }
    
    private void addR2(int iNum)
    {
        for(int i = 0; i < iNumTabs; ++i)
        {
            tabs[i].addRows(iNum);
        }
    }

    private void removeR2(int iNum)
    {
        for(int i = 0; i < iNumTabs; ++i)
        {
            tabs[i].removeRows(iNum);
        }
    }

    public void refreshR3(int iDiff)
    {
        if(iDiff == 0)
        {
            return;
        }
        else if (iDiff > 0)
        {
            addR3(iDiff);
        }
        else if (iDiff < 0)
        {
            removeR3(-iDiff);
        }
    }
    
    private void addR3(int iNum)
    {
        for(int i = 0; i < iNum; ++i)
        {
            McpSpinTable t = new McpSpinTable(tabs[0].getNumRows(), tabs[0].getRow(0).getNumCols(), tabs[0].getRow(0).getValAt(0).getNumAtoms(), tabs[0].getRow(0).getValAt(0).getNumComps());
            addTab(t);
        }
    }

    private void removeR3(int iNum)
    {
        System.arraycopy(tabs, 0, tabs, 0, iNumTabs - iNum);
        iNumTabs -= iNum;        

    }

    public void refreshNumAtoms(int iDiff)
    {
        if(iDiff == 0)
        {
            return;
        }
        else if (iDiff > 0)
        {
            addNumAtoms(iDiff);
        }
        else if (iDiff < 0)
        {
            removeNumAtoms(-iDiff);
        }
    }
    
    private void addNumAtoms(int iNum)
    {
        for(int i = 0; i < iNumTabs; ++i)
        {
            tabs[i].addNumAtoms(iNum);
        }
    }

    private void removeNumAtoms(int iNum)
    {
        for(int i = 0; i < iNumTabs; ++i)
        {
            tabs[i].removeNumAtoms(iNum);
        }
    }

    public void refreshNumComps(int iDiff)
    {
        if(iDiff == 0)
        {
            return;
        }
        else if (iDiff > 0)
        {
            addNumComps(iDiff);
        }
        else if (iDiff < 0)
        {
            removeNumComps(-iDiff);
        }
    }
    
    private void addNumComps(int iNum)
    {
        for(int i = 0; i < iNumTabs; ++i)
        {
            tabs[i].addNumComps(iNum);
        }
    }

    private void removeNumComps(int iNum)
    {
        for(int i = 0; i < iNumTabs; ++i)
        {
            tabs[i].removeNumComps(iNum);
        }
    }
}
