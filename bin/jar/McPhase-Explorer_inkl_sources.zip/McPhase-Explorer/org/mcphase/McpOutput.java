/*
 * Created on 23.03.2005
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package org.mcphase;

import java.awt.Color;
import java.awt.Font;
import java.io.BufferedReader;
import java.io.File;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.StringTokenizer;
import java.util.Vector;

import javax.swing.JTextArea;
import javax.swing.SwingUtilities;
import javax.swing.text.Document;

/**
 * @author Stefan
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
public class McpOutput extends JTextArea
{
    static final long serialVersionUID = -2909432732306735158L;
    
    private Thread worker;
    private Process proc;
    private Process proc1;
    private Process proc2;
    
    public McpOutput()
    {
        super();
        setFont(new Font("monospaced", Font.PLAIN, 12));
        setEnabled(false);
        setBackground(Color.lightGray);
        setDisabledTextColor(Color.blue);
    }
    
    public void stop()
    {
        if(worker != null)
        {
            if(worker.isAlive())
            {
                worker.interrupt();
            }
        }
        if(proc != null)
        {
            proc.destroy();            
        }
        if(proc1 != null)
        {
            proc1.destroy();            
        }
        if(proc2 != null)
        {
            proc2.destroy();            
        }
    }
    
    public void start(String[] params, File dir)
    {
        
        try
        {
            String [] szJ = new String[2];        
	        szJ[0] = params[1];
	        szJ[1] = dir.getAbsolutePath();
            if(szJ[0].length() > 0)
            {
    	        ProcessBuilder pJ = new ProcessBuilder (szJ);       
    	        pJ.directory(dir);
    	        pJ.environment().put("MCPHASE_DIR", "C:\\mcphas");
    	        Process proc1 = pJ.start();
    	        McpExplorer.processes.add(proc1);
            }
        }
        catch(IOException ex)
        {
            McpExplorer.LogExc("McpOutput", "Start Process 1", "", ex);
        }
        
/*        
        try
        {
	        String [] szGv = tokenize(params[2]);
//	        szGv[0] = params[2];
	        ProcessBuilder pGv = new ProcessBuilder (szGv);       
	        pGv.directory(dir);
	        pGv.environment().put("MCPHASE_DIR", "C:\\mcphas");
	        Process proc2 = pGv.start();
	        McpExplorer.processes.add(proc2);
        }
        catch(IOException ex)
        {
            McpExplorer.LogExc("McpOutput", "Start Process 2", "", ex);
        }        
*/
        
//        String [] szM = new String[1];
        String szM[] = tokenize(params[0]);
/*        String szM[] = new String[3];
        szM[0] = params[0];
        szM[1] = "/c";
        szM[2] = "notepad.exe";
*/
  
        final ProcessBuilder pb = new ProcessBuilder (szM);
        pb.directory(dir);
        pb.redirectErrorStream(true);
        pb.environment().put("MCPHASE_DIR", "C:\\mcphas");
        
        final McpOutput o = this;        
        
        worker = new Thread()
        {
            public void run()
            {
                String szFinalMsg = "";
                try
                {
	                proc = pb.start();	
	    	        McpExplorer.processes.add(proc);
	                McpExplorer.bIsRunning = true;
	              
	                
		            //BufferedInputStream in = new BufferedInputStream( proc.getInputStream());
	                BufferedReader output = new BufferedReader(new InputStreamReader(proc.getInputStream()));
/*	                
		            InputStream in = proc.getInputStream();
					
		            byte[] buff = new byte[1];
					int nch;
					while ((nch = in.read(buff, 0, buff.length)) != -1) 
					{
					
					    final String szMsg = new String(buff, 0, nch);
*/
	                
	                String line = "";
	                while((line = output.readLine()) != null)
	                {
	                    
	                    final String szMsg = line + "\n";
	                   
					    
	                    SwingUtilities.invokeLater(new Runnable() 
				                {
				                	public void run() 
				                	{
				                	    try
				                	    {
				            				Document doc = o.getDocument();
				        				    doc.insertString(doc.getLength(), szMsg, null);			                	        
				    					    o.revalidate();
				    					    o.setCaretPosition(doc.getLength());
				                	    }
				                	    catch(Exception ex)
				                	    {
				                	        McpExplorer.LogExc("McpOutput", "RUN", "", ex);
				                	    }
				                	}
				                });
	//				    System.out.print(szMsg);
		            }

	                
	                proc.waitFor();
					szFinalMsg = "\nFinished\n";
                }
                catch(Exception e)
                {
                    McpExplorer.LogExc("McpOutput", "RUN2", "", e);
                    szFinalMsg = "EXCEPTION: " + e.getClass().getName() + ", " + e.getMessage();
                }
                final String s = szFinalMsg;
		        SwingUtilities.invokeLater(new Runnable() 
		                {
		                	public void run() 
		                	{
		                	    try
		                	    {
		            				Document doc = o.getDocument();
		        				    doc.insertString(doc.getLength(), s, null);			                	        
		    					    o.revalidate();
		    					    
		    					    
		                	    }
		                	    catch(Exception ex)
		                	    {
		                	        McpExplorer.LogExc("McpOutput", "RUN3", "", ex);
		                	    }
		                	}
		                });
		        o.revalidate();
		        McpExplorer.bIsRunning = false;
    	    }
           
        };
        worker.start();       
    }
    
    protected String[] tokenize(String input) 
    {
        Vector v = new Vector();
        StringTokenizer t = new StringTokenizer(input);
        String cmd[];

        while (t.hasMoreTokens())
        {
            v.addElement(t.nextToken());
        }
        cmd = new String[v.size()];
        for (int i = 0; i < cmd.length; i++)
	    {
            cmd[i] = (String) v.elementAt(i);
	    }

        return cmd;
    }

}
