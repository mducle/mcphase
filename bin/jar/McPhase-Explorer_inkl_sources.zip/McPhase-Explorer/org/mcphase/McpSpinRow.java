/*
 * Created on 29.09.2005
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package org.mcphase;

/**
 * @author Stefan
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
public class McpSpinRow
{
    int iNofComps;
    McpSpin fVal[];
    
    public McpSpinRow(int iCols, int iNumAtoms, int iNumComps)
    {
        iNofComps = iCols;
        fVal = new McpSpin[iCols];
        for(int i = 0; i < iCols; ++ i)
        {
            fVal[i] = new McpSpin(iNumComps, iNumAtoms);
        }
    }
    
    public McpSpinRow(McpSpin[] f)
    {
        System.arraycopy(f, 0, fVal, 0, f.length);
        iNofComps = f.length;
    }
    
    public McpSpin getValAt(int iPos)
    {
        return fVal[iPos];
    }
    
    public void setValAt(int iPos, McpSpin val)
    {
        fVal[iPos] = val;
    }   
    
    public void setSpinValFromStrArray(int iSpinPos, String [] s)
    {
        for(int i = 0; i < iNofComps; ++i)
        {
            fVal[i].setValAt(iSpinPos, s[i]);
        }
    }
    
    public void setSpinValAt(int iPos, int iSpinPos, String f)
    {
        fVal[iPos].setValAt(iSpinPos, f);
    }
    
    public String toOutString()
    {
        StringBuffer sb = new StringBuffer();
        int iNumRows = fVal[0].getVectLen();
        for(int i = 0; i < iNumRows; ++i)
        {
            for(int j = 0; j < iNofComps; ++j)
            {
                if(j > 0)
                {
                    sb.append(" ");
                }
                sb.append(fVal[j].getValAt(i));
            }
            sb.append("\n");
        }
        
        return(sb.toString());
    }
    
    public int getNumCols()
    {
        return(iNofComps);
    }
    
    public void addCols(int iNum)
    {
        McpSpin[] rn = fVal;
        iNofComps += iNum;
        fVal = new McpSpin[iNofComps];
        if(rn != null)
        {
            System.arraycopy(rn, 0 , fVal, 0, iNofComps - iNum);
        }
        int iNumComps = fVal[0].getNumComps();
        int iNumAtoms = fVal[0].getNumAtoms();
        for(int i = 0; i < iNum; ++i)
        {
            fVal[iNofComps - iNum + i] = new McpSpin(iNumComps, iNumAtoms);
        }        
    }

    public void removeCols(int iNum)
    {
        System.arraycopy(fVal, 0 , fVal, 0, iNofComps - iNum);
        iNofComps -= iNum;
    }
    
    public void addNumAtoms(int iNum)
    {
        for(int i = 0; i < iNofComps; ++i)
        {
            fVal[i].addNumAtoms(iNum);
        }        
    }
    
    public void removeNumAtoms(int iNum)
    {
        for(int i = 0; i < iNofComps; ++i)
        {
            fVal[i].removeNumAtoms(iNum);
        }        
    }
    
    public void addNumComps(int iNum)
    {
        for(int i = 0; i < iNofComps; ++i)
        {
            fVal[i].addNumComps(iNum);
        }        
    }
    
    public void removeNumComps(int iNum)
    {
        for(int i = 0; i < iNofComps; ++i)
        {
            fVal[i].removeNumComps(iNum);
        }        
    }
    
}
