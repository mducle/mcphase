/*
 * Created on 09.04.2005
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package org.mcphase;

import java.util.Arrays;
import java.util.Vector;

import javax.swing.table.AbstractTableModel;

/**
 * @author Stefan
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
public class McpTableModel extends AbstractTableModel 
{
    static final long serialVersionUID = -6425318071146635990L;
    
    Vector cache;  // will hold String[] objects . . .
    int colCount;
    String[] headers;
    Class[] types;
    private String szFormat;
    
    public McpTableModel(Vector x, String format) 
    {
      cache = x;
      colCount = ((Object[])x.elementAt(0)).length;
      setHeaderProps();
      szFormat = format;
    }
     
    public void setHeader(String h[])
    {
        for(int i = 0; i < h.length; ++i)
        {
            headers[i] = h[i];
        }
    }
    
    public String getFormat()
    {
        return(szFormat);
    }
    
    public Class getColumnClass(int c)
    {
        return(types[c]);
    }
    
    public String getColumnName(int i) 
    { 
        return headers[i]; 
    }
    
    public int getColumnCount() 
    { 
        return colCount; 
    }
    
    public int getRowCount() 
    { 
        return cache.size();
    }

    public Object getValueAt(int row, int col) 
    { 
      return ((Object[])cache.elementAt(row))[col];
    }
    
    public void setValueAt(Object value, int r, int c)
    {
        ((String[])cache.elementAt(r))[c] = value.toString();
        fireTableDataChanged();
    }
    
    public void addDefaultRow(String szDefault)
    {
        String [] s = new String[colCount];
        for(int i = 0; i < colCount; ++i)
        {
            s[i] = szDefault;
        }
        addRow(s);
    }
    
    public void addRow(String[] s)
    {
        if(s.length == colCount)
        {
            cache.add(s);
            fireTableDataChanged();
        }        
    }
    
    public void delRow(int iIndex)
    {
        cache.remove(iIndex);
        fireTableDataChanged();
    }

    public void delRows(int iIndex[])
    {
        Arrays.sort(iIndex);
        int size = getRowCount();
        for(int i = 0; i < iIndex.length && (i + 1 < size); ++i)
        {
            if(iIndex[i] - i >= 0)
            {
                cache.remove(iIndex[i] - i);
            }
        }
        fireTableDataChanged();
    }
    
    public String getDataAsFileTable()
    {
        StringBuffer sb = new StringBuffer();
        for(int i = 0; i < cache.size(); ++i)
        {
            Object o = cache.elementAt(i);
            String s [] = (String[])o;
            for(int j = 0; j < colCount; ++j)
            {
               sb.append(s[j]).append("\t");
            }
            sb.append("\n");
        }
        return(sb.toString());
    }
    
    public String [][] getDataAsStringArray()
    {
        String szRet[][] = new String[cache.size()][colCount];
        for(int r = 0; r < cache.size(); ++r)
        {
            for(int c = 0; c < colCount; ++c)
            {
                szRet[r][c] = ((String[])cache.elementAt(r))[c];
            }
        }
        return(szRet);
    }
    
    public void addDefaultColumn(String s)    
    {
        ++colCount;
        setHeaderProps();
        for(int i = 0; i < cache.size(); ++i)
        {
            String n [] = new String[colCount];
            for(int j = 0; j < colCount - 1; ++j)
            {
                n[j] = ((String[])cache.elementAt(i))[j];
            }
            n[colCount - 1] = s;
            cache.remove(i);
            cache.add(i, n);
            
        }
        fireTableStructureChanged();
        fireTableDataChanged();
    }
    
    public void delColumn()    
    {
        --colCount;
        setHeaderProps();
        for(int i = 0; i < cache.size(); ++i)
        {
            String n [] = new String[colCount];
            for(int j = 0; j < colCount; ++j)
            {
                n[j] = ((String[])cache.elementAt(i))[j];
            }
            cache.remove(i);
            cache.add(i, n);            
        }
        fireTableStructureChanged();
        fireTableDataChanged();
    }
    
    private void setHeaderProps()
    {
        headers = new String[colCount];
        types = new Class[colCount];
        for(int i=0; i< colCount; ++i)
        {
            if(i == 0)
            {
                headers[i] = "x[a]";                
            }
            else if(i == 1)
            {
                headers[i] = "y[b]";                
            }
            else if(i == 2)
            {
                headers[i] = "z[c]";                
            }
            else if(i == 3)
            {
                headers[i] = "Jaa[meV]";                
            }
            else if(i == 4)
            {
                headers[i] = "Jbb[meV]";                
            }
            else if(i == 5)
            {
                headers[i] = "Jcc[meV]";                
            }
            else
            {
                headers[i] = "col " + (i - 5);
            }
        }
        for(int i= 0; i< colCount; ++i)
        {
            types[i] = String.class;
        }              
    }
  }
