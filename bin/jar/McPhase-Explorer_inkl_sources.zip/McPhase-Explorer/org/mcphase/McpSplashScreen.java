/*
 * Created on 25.04.2005
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package org.mcphase;

/**
 * @author Stefan
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
/*
 * Created on 21.04.2005
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */

import java.awt.BorderLayout;
import java.awt.Container;
import java.awt.Cursor;
import java.awt.Frame;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URL;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JDialog;
import javax.swing.JEditorPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JViewport;
import javax.swing.SwingUtilities;
import javax.swing.event.HyperlinkEvent;
import javax.swing.event.HyperlinkListener;
import javax.swing.text.Document;

/**
 * @author Stefan
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
public class McpSplashScreen
{
    private String m_Title;
    
    private JDialog dlg;
    private HtmlPane pane;
    JCheckBox chk;
    
    
    public McpSplashScreen(Frame parent, String szTitle, ImageIcon i, URL url)
    {
        m_Title = szTitle;
        dlg = new JDialog(parent, m_Title, true);
        pane = new HtmlPane();
        dlg.add(new JScrollPane(pane), BorderLayout.CENTER);
        chk = new JCheckBox("Don't show any more");
        chk.addActionListener(new ActionListener()
                {
            		public void actionPerformed(ActionEvent ev)
            		{
            		     if(chk.isSelected())
            		     {
            		         McpExplorer.userPrefs.putBoolean("ShowSplashScreen", false);
            		     }
            		     else
            		     {
            		         McpExplorer.userPrefs.putBoolean("ShowSplashScreen", true);
            		     }
            		}
                });
        
        JButton btn = new JButton("OK");
        btn.addActionListener(new ActionListener()
                {
		    		public void actionPerformed(ActionEvent ev)
		    		{
		    		    dlg.dispose();
		    		}            
                });
        
        JPanel p = new JPanel();
        p.add(chk);
        p.add(btn);
        dlg.add(p, BorderLayout.SOUTH);
        dlg.setBounds(162, 184, 700, 400);
        showHelp(url);
        dlg.setVisible(true);
    }

    public McpSplashScreen(Frame parent, String szTitle, ImageIcon i, String szPage)
    {
        m_Title = szTitle;
        dlg = new JDialog(parent, m_Title, true);
        pane = new HtmlPane();
        dlg.add(new JScrollPane(pane), BorderLayout.CENTER);
        chk = new JCheckBox("Don't show any more");
        chk.addActionListener(new ActionListener()
                {
            		public void actionPerformed(ActionEvent ev)
            		{
            		     if(chk.isSelected())
            		     {
            		         McpExplorer.userPrefs.putBoolean("ShowSplashScreen", false);
            		     }
            		     else
            		     {
            		         McpExplorer.userPrefs.putBoolean("ShowSplashScreen", true);
            		     }
            		}
                });
        
        JButton btn = new JButton("OK");
        btn.addActionListener(new ActionListener()
                {
		    		public void actionPerformed(ActionEvent ev)
		    		{
		    		    dlg.dispose();
		    		}            
                });
        
        JPanel p = new JPanel();
        p.add(chk);
        p.add(btn);
        dlg.add(p, BorderLayout.SOUTH);
        dlg.setBounds(162, 184, 700, 400);
        showHelpPage(szPage);
        dlg.setVisible(true);
    }

    
    public void showHelp(URL url)
    {
        try
        {
            pane.setUrl(url);
        }
        catch(Exception ex)
        {
            ex.printStackTrace();
        }
    }
    
    public void showHelpPage(String szPage)
    {
        try
        {
            pane.setPage(szPage);
        }
        catch(Exception ex)
        {
            ex.printStackTrace();
        }
    }
    
    
    class HtmlPane extends JScrollPane implements HyperlinkListener 
    {
        static final long serialVersionUID = -1710630708955894574L;
        
        JEditorPane html;

        public HtmlPane() 
        {
    	    html = new JEditorPane();
    	    html.setEditable(false);
    	    html.addHyperlinkListener(this);

    	    JViewport vp = getViewport();
    	    vp.add(html);
        }

        public void setPage(String szPage)
        {
	    	try 
	    	{
            	html.setPage(szPage);
	    	}
	    	catch (MalformedURLException e) 
	    	{
	    	    System.out.println("Malformed URL: " + e);
	    	}
	    	catch (IOException e) 
	    	{
	    	    System.out.println("IOException: " + e);
	    	}	            
        }
        
        public void setUrl(URL url)
        {
	    	try 
	    	{
            	html.setPage(url);
	    	}
	    	catch (MalformedURLException e) 
	    	{
	    	    System.out.println("Malformed URL: " + e);
	    	}
	    	catch (IOException e) 
	    	{
	    	    System.out.println("IOException: " + e);
	    	}	
        }
        /**
         * Notification of a change relative to a 
         * hyperlink.
         */
        public void hyperlinkUpdate(HyperlinkEvent e) 
        {
            if (e.getEventType() == HyperlinkEvent.EventType.ACTIVATED) 
            {
                linkActivated(e.getURL());
            }
        }

        /**
         * Follows the reference in an
         * link.  The given url is the requested reference.
         * By default this calls <a href="#setPage">setPage</a>,
         * and if an exception is thrown the original previous
         * document is restored and a beep sounded.  If an 
         * attempt was made to follow a link, but it represented
         * a malformed url, this method will be called with a
         * null argument.
         *
         * @param u the URL to follow
         */
        protected void linkActivated(URL u) 
        {
            Cursor c = html.getCursor();
            Cursor waitCursor = Cursor.getPredefinedCursor(Cursor.WAIT_CURSOR);
            html.setCursor(waitCursor);
            SwingUtilities.invokeLater(new PageLoader(u, c));
        }

        /**
         * temporary class that loads synchronously (although
         * later than the request so that a cursor change
         * can be done).
         */
        class PageLoader implements Runnable 
        {
    	
            private URL url;
            private Cursor cursor;
            
            PageLoader(URL u, Cursor c) 
            {
                url = u;
                cursor = c;
            }

            public void run() 
            {
                if (url == null) 
                {
                    // restore the original cursor
                    html.setCursor(cursor);

		    		// PENDING(prinz) remove this hack when 
		    		// automatic validation is activated.
		    		Container parent = html.getParent();
		    		parent.repaint();

                } 
                else 
                {
		    		Document doc = html.getDocument();
		    		try 
		    		{
		    		    html.setPage(url);
		    		}
		    		catch (IOException ioe) 
		    		{
		    		    html.setDocument(doc);
		    		    getToolkit().beep();
		    		} 
		    		finally 
		    		{
		    		    // schedule the cursor to revert after
		    		    // the paint has happended.
		    		    url = null;
		    		    SwingUtilities.invokeLater(this);
		    		}
	    	    }
	    	}
        }
    }
}
