package org.mcphase;
import java.awt.BorderLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.prefs.PreferenceChangeEvent;
import java.util.prefs.PreferenceChangeListener;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JToolBar;
import javax.swing.JTree;
import javax.swing.Timer;
import javax.swing.event.TreeExpansionEvent;
import javax.swing.event.TreeSelectionEvent;
import javax.swing.event.TreeSelectionListener;
import javax.swing.event.TreeWillExpandListener;
import javax.swing.tree.DefaultTreeSelectionModel;
import javax.swing.tree.TreePath;
import javax.swing.tree.TreeSelectionModel;


/*
 * Created on 14.03.2005
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */

/**
 * @author Stefan
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */

public class FileSystemTree extends JPanel implements ActionListener 
{
    private static Logger log;
    private JToolBar toolbar;
    private JTree tree;
    private JLabel messageLabel;
    private FileSystemModel mod;
    
    static final long serialVersionUID = 3354388574985105552L;
    
//    private static ResourceBundle resources;

    static 
    {
        log = Logger.getLogger("org.mcphase.FileSystemTree");
/*       
        try
        {
            FileHandler fh = new FileHandler("C:\\temp\\fst.log");
            fh.setFormatter(new SimpleFormatter());            
            log.addHandler(fh);
        }
        catch(IOException ioex)
        {
            // Logging only to Console
        }
*/
/*
        try 
        {
            resources = ResourceBundle.getBundle("org.mcphase.resources.FileSystemTree", Locale.getDefault());
        } 
        catch (MissingResourceException mre) 
        {
            System.err.println("org/mcphase/resources/FileSystemTree.properties not found");
            System.exit(1);
        }
*/        
        if(McpExplorer.userPrefs.getBoolean("LogDebug", false))
        {
            log.setLevel(Level.ALL);
        }
        else
        {
            log.setLevel(Level.INFO);
        }
        
        McpExplorer.userPrefs.addPreferenceChangeListener(new PreferenceChangeListener()
                {
            		public void preferenceChange(PreferenceChangeEvent ev)
            		{
            		    String szKey = ev.getKey();
            		    if(szKey.equalsIgnoreCase("LogDebug"))
            		    {
            		        if(ev.getNewValue().equalsIgnoreCase("true"))
            		        {
            		            log.setLevel(Level.ALL);
            		        }
            		        else
            		        {
            		            log.setLevel(Level.INFO);
            		        }
            		    }
            		}
                });
    }

    public static synchronized void LogDebug(String szMsg)
    {
        Log(Level.FINE, szMsg);
    }

    public static synchronized void LogInfo(String szMsg)
    {
        Log(Level.INFO, szMsg);
    }

    public static synchronized void LogWarning(String szMsg)
    {
        Log(Level.WARNING, szMsg);
    }

    public static synchronized void LogError(String szMsg)
    {
        Log(Level.SEVERE, szMsg);
    }

    public static synchronized void LogExc(String szClass, String szMethod, String szMsg, Exception ex)
    {
        log.logp(Level.SEVERE, szClass, szMethod, szMsg, ex);
    }

    public static synchronized void Log(Level l, String szMsg)
    {
        log.log(l, szMsg);
    }

    
    public synchronized void actionPerformed(ActionEvent ae)
    {
        checkTree();
    }
    
    public FileSystemTree( String startPath ) 
    {
        LogInfo("Create with startpath: '" + startPath + "'");
        FileObject root;
        if(startPath.length() == 0)
        {
            LogDebug("No Startpath given -> Start with Roots");
            root = new FileObject(true);
        }
        else
        {
            root = new FileObject(startPath, true);            
        }
        LogDebug("STRUCT: " + root.getStructure());
        LogDebug("Create Treemodel");
        mod = new FileSystemModel(root, true);
        tree = new JTree( mod );
        tree.setEditable(false);
        if(startPath.length() == 0)
        {
            tree.setRootVisible( false );
        }
        else
        {
            tree.setRootVisible( true );
        }
            
        tree.putClientProperty( "JTree.lineStyle", "Angled" );

        // Selection Model
        LogDebug("Define Selection Model");
        DefaultTreeSelectionModel tms = new DefaultTreeSelectionModel();
        tms.setSelectionMode(TreeSelectionModel.SINGLE_TREE_SELECTION);
        tree.setSelectionModel(tms);

        // Renderer
        LogDebug("Define Renderer");
        FileTreeCellRenderer tcr = new FileTreeCellRenderer();
        tree.setCellRenderer(tcr);
        tree.addTreeWillExpandListener( new TreeWillExpandListener()
                {
            		public void treeWillExpand(TreeExpansionEvent ev)
            		{
            		    FileObject f = (FileObject)ev.getPath().getLastPathComponent();
            		    if(f.isDirectory() && !f.isSelected())
            		    {
            		        f.setSelected(true);
            		    }
//            		    System.out.println("TreeWillExpand: " + ev.getPath().getLastPathComponent());
            		}
            		public void treeWillCollapse(TreeExpansionEvent ev)
            		{
//            		    System.out.println("TreeWillCollapse: " + ev.getPath().getLastPathComponent());
            		}
                }
        );
        
        
        JScrollPane treeScroller = new JScrollPane( tree );
        setLayout( new BorderLayout() );
        add( treeScroller, BorderLayout.CENTER );
        
        LogDebug("Create Bottom Label");
        messageLabel = new JLabel("Nothing selected");
        add (messageLabel, BorderLayout.SOUTH);        
        tree.addTreeSelectionListener(new TreeSelectionListener()
                {
            		public void valueChanged(TreeSelectionEvent tse)
            		{
            		    String szMsg;            		    
            		    TreePath tp = tse.getNewLeadSelectionPath();
            		    if(tp != null)
            		    {            		        
	            		    FileObject fo = (FileObject)tp.getLastPathComponent();
	            		    if(fo.isDirectory())
	            		    {
	            		        szMsg = "DIR: ";
	            		    }
	            		    else
	            		    {
	                		    szMsg = fo.GetFileType() + " ";
	            		    }
	            		    szMsg += fo.toString();
	            		    messageLabel.setText(szMsg);
            		    }
            		}
                }
        );
        
        LogDebug("Start Refresh-Timer");
        Timer t = new Timer(1000, this);
        t.start();
    }

    public JTree getTree() 
    {
       return tree;
    }        
    
    public JToolBar getToolBar()
    {
        return toolbar;
    }
    
    public JLabel getMessageLabel()
    {
        return messageLabel;
    }
    
    // For Testing the Tree standalone
    public static void main(String args[])
    {
        FileSystemTree tt = new FileSystemTree("C:\\");
        JFrame fMain = new JFrame("TEST-Appliaction");
        fMain.setSize(400, 300);
        fMain.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        fMain.getContentPane().add(tt, BorderLayout.CENTER);
        fMain.setVisible(true);
    }
    
    private synchronized void checkTree()
    {
        LogDebug("Check Tree");
        mod.checkModel();
        LogDebug("STRUCT: " + ((FileObject)mod.getRoot()).getStructure());
    }
}

