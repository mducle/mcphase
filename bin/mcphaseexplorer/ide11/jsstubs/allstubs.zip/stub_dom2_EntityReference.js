var EntityReference = Object.extend(new Node(), {
  // This is just a stub for a builtin native JavaScript object.
});

