var AbstractView = {
  // This is just a stub for a builtin native JavaScript object.
/**
 * The source DocumentView
 * of which this is an AbstractView.
 * @type DocumentView
 */
document: undefined,
};

