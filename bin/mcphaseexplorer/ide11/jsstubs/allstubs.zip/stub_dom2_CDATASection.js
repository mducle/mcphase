var CDATASection = Object.extend(new Text(), {
  // This is just a stub for a builtin native JavaScript object.
});

