var CSSCharsetRule = Object.extend(new CSSRule(), {
  // This is just a stub for a builtin native JavaScript object.
/**
 * The encoding information used in this @charset
 * rule.
 * @type String
 */
encoding: undefined,
});

